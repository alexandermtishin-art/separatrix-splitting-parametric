"""Plot certified target regions without interpolating the flux floor."""
from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

out=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'pdf.fonttype':42})
fig, (a,b)=plt.subplots(1,2,figsize=(8,4),layout='constrained')
a.add_patch(Rectangle((70.5,1.240),7.5,.045,facecolor='#b6dded',edgecolor='#135f88',lw=1.7))
a.text(74.25,1.2625,'One setting',ha='center',va='center',color='#113f57',weight='bold')
a.set(xlim=(69,79.5),ylim=(1.229,1.297),xticks=[70.5,74.25,78.0],yticks=[1.240,1.255,1.270,1.285],
      xlabel='Second incoming share $s$ (%)',ylabel='Target area $F$ ($10^{-12}$)',title='(a) Independent targets',)
b.add_patch(Rectangle((48.5,0),3,3.8,facecolor='#f8d7a8',edgecolor='#a96115',lw=1.7))
b.add_patch(Rectangle((48.5,-1.5),3,1.5,facecolor='#eceff2',edgecolor='none'))
b.plot([48.5,51.5],[0,0],color='#663b70',lw=2)
b.text(50,1.9,'Two settings',ha='center',va='center',color='#713a00',weight='bold')
b.text(50,-.75,'No settings',ha='center',va='center',color='#3b4450',weight='bold')
b.text(50,.21,'One at zero',ha='center',va='bottom',color='#663b70',fontsize=9)
b.set(xlim=(47.8,52.2),ylim=(-1.65,4.35),xticks=[48.5,50,51.5],yticks=[-1,0,1,2,3.8],
      xlabel='Second incoming share $s$ (%)',ylabel=r'Excess $F-F_{\min}(s)$ ($10^{-15}$)',title='(b) Transport threshold')
for ax in (a,b):
 ax.spines[['top','right']].set_visible(False)
 ax.grid(True,alpha=.17)
 ax.set_axisbelow(True)
fig.savefig(out/'Fig3_Inverse_Transport.pdf')
fig.savefig(out/'Fig3_Inverse_Transport.png',dpi=600)
fig.savefig(out/'Kerr_Graphical_Abstract.png',dpi=300)
