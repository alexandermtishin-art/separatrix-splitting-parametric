"""Plot the interval enclosures of the certified Kerr lobe-count transition.

Usage:
    python plot_certified_contour.py path/to/full_contour/data [output-directory]

The inputs are the JSON files from Kerr_Closed_Transition_Contour_Audit_v2.
No contour interpolation or reduced-model fit is used.
"""

import argparse
from fractions import Fraction
import json
import math
from pathlib import Path

import matplotlib as mpl

mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PatchCollection
from matplotlib.patches import Patch, Rectangle
from matplotlib.ticker import MultipleLocator


MICRO = 10**6
FIGURE_NAME = "Kerr_Fig1_Certified_Transition"


def interval(value):
    lower, upper = value.removeprefix("[").removesuffix("]").split(",")
    return Fraction(lower.strip()), Fraction(upper.strip())


def figure_data(data_directory):
    summary = json.loads((data_directory / "closed-contour-certificate.json").read_text())
    control_panel = json.loads((data_directory / "wide-00-0.json").read_text())
    scales = tuple(map(Fraction, control_panel["scale"]))
    center = tuple(map(Fraction, summary["robust_box"]["center"]))
    if center != tuple(map(Fraction, control_panel["center"])):
        raise ValueError("The plotted tolerance must be centered at the control origin.")
    tolerance = tuple(MICRO * Fraction(width) for width in summary["robust_box"]["half_width"])
    display_limits = tuple(MICRO * scale / 2 for scale in scales)

    left, right = map(Fraction, summary["x_period"])
    boxes = []
    slab_count = 0
    for index in range(summary["panel_count"]):
        path = data_directory / f"wide-{index:02d}-certificate.json"
        panel = json.loads(path.read_text())
        for slab in panel["slabs"]:
            slab_count += 1
            xlo, xhi = interval(slab["x"])
            if xhi < left or xlo > right:
                continue
            boxes.append(tuple(tuple(MICRO * scale * endpoint for endpoint in interval(bound))
                               for scale, bound in zip(scales, slab["controls"])))
    box_count = len(boxes)
    if slab_count != summary["slab_count"] or box_count * (box_count + 1) // 2 != summary["simple_loop"]["comparisons"]:
        raise ValueError("Plotted slab selection disagrees with the certificate.")
    return boxes, tolerance, display_limits


def exact_box_artist(box):
    (xlo, xhi), (ylo, yhi) = box
    x = math.nextafter(float(xlo), -math.inf)
    y = math.nextafter(float(ylo), -math.inf)
    right = math.nextafter(float(xhi), math.inf)
    top = math.nextafter(float(yhi), math.inf)
    return Rectangle((x, y), right - x, top - y)


def draw(data_directory, output_directory):
    boxes, tolerance, display_limits = figure_data(data_directory)
    xhalf, yhalf = map(float, tolerance)
    xlim, ylim = map(float, display_limits)
    boundary_color = "#175585"
    tolerance_color = "#FFF0CD"
    tolerance_edge = "#946019"
    mpl.rcParams.update({
        "font.family": "DejaVu Sans",
        "mathtext.fontset": "dejavusans",
        "axes.labelsize": 11.5,
        "axes.linewidth": 0.8,
        "xtick.labelsize": 9.5,
        "ytick.labelsize": 9.5,
        "pdf.fonttype": 42,
        "svg.fonttype": "none",
    })
    figure = plt.figure(figsize=(6.10, 5.70), facecolor="white")
    axes = figure.add_axes((0.125, 0.360, 0.847, 0.590))
    figure.text(0.018, 0.960, "(a)", weight="bold", fontsize=10)

    axes.add_collection(PatchCollection([exact_box_artist(box) for box in boxes],
                                        facecolor=boundary_color, edgecolor="none",
                                        antialiased=False, zorder=3))
    axes.add_patch(Rectangle((-xhalf, -yhalf), 2*xhalf, 2*yhalf,
                             facecolor=tolerance_color, edgecolor=tolerance_edge,
                             linewidth=1.0, linestyle=(0, (4, 2.6)), zorder=2))
    labels = [
        axes.text(0, 0.25, "Two incoming\nlobes", ha="center", va="center",
                  multialignment="center", fontsize=11.5, linespacing=1.2,
                  weight="semibold", color="#5B3809", zorder=4),
        axes.text(-5.1, 5.8, "One incoming\nlobe", ha="center", va="center",
                  multialignment="center", fontsize=11.5, linespacing=1.2,
                  weight="semibold", color=boundary_color),
        axes.text(0.965, 0.948, r"$\epsilon=0.20,\quad\delta=0$", transform=axes.transAxes,
                  ha="right", va="top", fontsize=9.75),
    ]

    axes.set_xlim(-xlim, xlim)
    axes.set_ylim(-ylim, ylim)
    axes.xaxis.set_major_locator(MultipleLocator(2))
    axes.yaxis.set_major_locator(MultipleLocator(2))
    axes.tick_params(direction="out", length=3.1, width=0.75, pad=4)
    axes.set_xlabel(r"Amplitude-ratio offset $10^6(\rho-\rho_0)$", labelpad=7)
    axes.set_ylabel(r"Phase offset $10^6\phi$ (rad)", labelpad=7)
    axes.legend(handles=[
        Patch(facecolor=boundary_color, edgecolor="none", label="Certified contour enclosures"),
        Patch(facecolor=tolerance_color, edgecolor=tolerance_edge, linewidth=1.0,
              linestyle=(0, (4, 2.6)), label="Joint tolerance rectangle"),
    ], loc="lower center", bbox_to_anchor=(0.548, 0.192), bbox_transform=figure.transFigure,
        ncol=2, frameon=False, fontsize=9.0, handlelength=2.0, columnspacing=1.65)

    summary = json.loads((data_directory / "closed-contour-certificate.json").read_text())
    roots = figure.add_axes((0.125, 0.105, 0.847, 0.080))
    figure.text(0.018, 0.188, "(b)", weight="bold", fontsize=10)
    for level, anchor, color in [(1, "center", tolerance_edge), (0, "top", boundary_color)]:
        row = summary["anchors"][anchor]
        assert len(row["roots"]) == row["simple_crossings"]
        for left, right in row["roots"]:
            lo, hi = float(Fraction(left)), float(Fraction(right))
            roots.hlines(level, lo, hi, color=color, linewidth=2.0)
            roots.vlines([lo, hi], level-0.11, level+0.11, color=color, linewidth=0.75)
    roots.set_xlim(*map(lambda x: float(Fraction(x)), summary["q_range"]))
    roots.set_ylim(-0.33, 1.33)
    roots.set_yticks([0, 1], ["Outside", "Inside"], fontsize=9)
    roots.tick_params(axis="y", length=0, pad=5)
    roots.tick_params(axis="x", direction="out", length=3.1, width=0.75)
    roots.xaxis.set_major_locator(MultipleLocator(0.02))
    roots.set_xlabel(r"Crossing coordinate $q$", labelpad=3)
    roots.spines[["top", "right", "left"]].set_visible(False)

    figure.canvas.draw()
    renderer = figure.canvas.get_renderer()
    contour_bounds = [exact_box_artist(box).get_bbox().transformed(axes.transData) for box in boxes]
    for label in labels:
        bounds = label.get_window_extent(renderer).expanded(1.1, 1.1)
        if any(bounds.overlaps(box) for box in contour_bounds):
            raise ValueError(f"Label overlaps a certified enclosure: {label.get_text()}")

    output_directory.mkdir(parents=True, exist_ok=True)
    for extension in ("png", "pdf", "svg"):
        figure.savefig(output_directory / f"{FIGURE_NAME}.{extension}", dpi=600,
                       facecolor="white")
    plt.close(figure)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data_directory", type=Path)
    parser.add_argument("output_directory", type=Path, nargs="?", default=Path(__file__).parent)
    options = parser.parse_args()
    draw(options.data_directory, options.output_directory)
