"""Draw the journal graphic from certified boxes and check label clearance."""
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PatchCollection
from matplotlib.patches import Rectangle
from matplotlib.transforms import Bbox

def draw(data, output, figure_source):
    sys.path.insert(0,str(figure_source))
    from plot_certified_contour import figure_data, exact_box_artist
    boxes, tolerance, limits = figure_data(data)
    fig=plt.figure(figsize=(8,4),facecolor="white")
    ax=fig.add_axes((.52,.155,.445,.74))
    ax.add_collection(PatchCollection([exact_box_artist(b) for b in boxes],
                                      facecolor="#202020",edgecolor="none",antialiased=False,zorder=3))
    x,y=map(float,tolerance)
    ax.add_patch(Rectangle((-x,-y),2*x,2*y,facecolor="#d9e8e1",edgecolor="#3c5d50",
                           linestyle="--",linewidth=1.1))
    xx,yy=map(float,limits)
    ax.set(xlim=(-xx,xx),ylim=(-yy,yy),xticks=[-8,-4,0,4,8],yticks=[-8,-4,0,4,8],
           xlabel=r"$10^6(\rho-\rho_0)$",ylabel=r"$10^6\phi$ (rad)")
    ax.tick_params(labelsize=9)
    ax.set_title(r"$\epsilon=0.20,\quad\delta=0$",fontsize=11,color="black")
    labels=[ax.text(0,0,"2",fontsize=14,weight="bold",ha="center",va="center"),
            ax.text(-5.7,5.5,"1",fontsize=14,weight="bold",ha="center",va="center")]
    fig.text(.045,.845,"Separatrix transport\nin a Kerr oscillator",fontsize=17,weight="bold",linespacing=1.16,va="top")
    fig.text(.045,.575,"Two incoming lobes inside\nOne incoming lobe outside",fontsize=12,linespacing=1.43,va="top")
    fig.text(.045,.353,"Dashed box: joint tolerance",fontsize=10.5,va="top")
    fig.text(.045,.272,r"$|\rho-\rho_0|\leq 2.35\times10^{-6}$",fontsize=11,va="top")
    fig.text(.045,.186,r"$|\phi|\leq 2.65\times10^{-6}\;\mathrm{rad}$",fontsize=11,va="top")
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    bound=[Bbox(ax.transData.transform([[float(b[0][0]),float(b[1][0])],
                                        [float(b[0][1]),float(b[1][1])]])) for b in boxes]
    for label in labels:
        extent=label.get_window_extent(renderer).expanded(1.12,1.12)
        assert not any(extent.overlaps(b) for b in bound),label.get_text()
    fig.savefig(output,dpi=300)
    plt.close(fig)

if __name__=="__main__":
    draw(*map(Path,sys.argv[1:]))
