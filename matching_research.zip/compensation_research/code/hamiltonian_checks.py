"""Symbolic checks of Hamilton equations, reversal and the static correction."""
from pathlib import Path
import json
import sympy as s
q,p,t,e,r,U,d=s.symbols('q p t e r U d',real=True)
n=(q*q+p*p)/2
H=(1+d)*n+U*n*n/2+e*n*s.cos(2*t)+e/4*((1+r)*(q*q-p*p)*s.cos(2*t)-2*(1-r)*q*p*s.sin(2*t))
fq=(1+d)*p+U*n*p+(1-r)*e/2*(p*s.cos(2*t)-q*s.sin(2*t))
fp=-(1+d)*q-U*n*q-(3+r)*e/2*q*s.cos(2*t)+(1-r)*e/2*p*s.sin(2*t)
assert s.simplify(s.diff(H,p)-fq)==0
assert s.simplify(-s.diff(H,q)-fp)==0
assert s.simplify(H.subs({p:-p,t:-t},simultaneous=True)-H)==0
J,psi=s.symbols('J psi',real=True)
V=r*e*J*s.exp(2*s.I*psi)/4;Vm=r*e*J*s.exp(-2*s.I*psi)/4
br=s.diff(V,psi)*s.diff(Vm,J)-s.diff(V,J)*s.diff(Vm,psi)
k2=s.simplify(s.I*br/4)
out=dict(hamilton_equations=True,reversibility=True,static_second_order=str(k2))
(Path(__file__).resolve().parents[1]/'data'/'hamiltonian_checks.json').write_text(json.dumps(out,indent=2))
print(out)
