"""Exact evaluation of the mixed inner coefficient for U=-1.

Conditional result for the specified harmonic inner reduction, not a
matching theorem for the full oscillator. No value -1/6 is imposed.
"""
import json
from pathlib import Path
import sympy as s
import mpmath as mp

t=s.symbols('t');y,z=s.symbols('y z',positive=True);A,B=s.symbols('A B');I=s.I
xN=s.Rational(2,3)*t*A+1/(12*t**2)
xw=-s.Rational(2,3)*t*A+1/(24*t**2)
yN=-I*t*B/3+I/(6*t)+1/(12*t**2)
yw=I*t*B/3+I/(12*t)+1/(24*t**2)
fN=-2*I*xN*yw-2*I*xw*yN-yN/t-2*yw/t
fw=-2*I*xN*yw-2*I*xw*yN+4*I*xw*yw+I*xw+2*yw/t
integrand=s.expand((fN-2*fw)/(3*t))
expected=A*(-8*B*t/9+4*I/9-1/(9*t)+I/(18*t**2))+B*(-5*I/(9*t)+1/(36*t**2))-I/(4*t**3)-1/(9*t**4)
assert s.simplify(integrand-expected)==0

# Residue sums at t=0, -iy and +iz. The pole -iy contributes for y<c
# on a contour Im(t)=-c. Its omitted weighted tail vanishes as c->infinity.
Ra=s.simplify(s.diff(s.exp(2*I*t)*(s.Rational(4,9)*I-1/(9*t)+I/(18*t**2)),t,2).subs(t,-I*y)/2)
Ra0=s.simplify(-1/(9*(I*y)**3)+I/s.Integer(18)*s.diff(s.exp(2*I*t)/(t+I*y)**3,t).subs(t,0))
Rb=s.simplify(s.diff(s.exp(2*I*t)*(-5*I/(9*t)+1/(36*t**2)),t).subs(t,I*z))
Rb0=s.simplify(-5*I/(9*(-I*z)**2)+s.Rational(1,36)*s.diff(s.exp(2*I*t)/(t-I*z)**2,t).subs(t,0))
Rab=s.simplify(-s.Rational(8,9)*(s.diff(s.exp(2*I*t)*t/(t-I*z)**2,t,2).subs(t,-I*y)/2+s.diff(s.exp(2*I*t)*t/(t+I*y)**3,t).subs(t,I*z)))
R0=s.Rational(35,54)*I

# y=u*v,z=u*(1-v), including Jacobian u. Integrate v exactly.
u,v=s.symbols('u v',positive=True)
weighted=s.expand(s.simplify((s.exp(-4*y-2*z)*Rab*u).subs({y:u*v,z:u*(1-v)},simultaneous=True)))
ab_u=s.simplify(s.integrate(weighted,(v,0,1))/I)
ab_expected=s.Rational(8,9)*(s.exp(-2*u)*(1-1/(2*u**2))+s.exp(-4*u)*(1/u+1/(2*u**2)))
assert s.simplify(ab_u-ab_expected)==0

# Mellin regulator only evaluates sums convergent at zero; all poles cancel.
reg=s.symbols('reg')
termsA=[(-s.Rational(16,18),2,0),(s.Rational(4,18),2,1),(-s.Rational(2,18),2,2),(-s.Rational(2,18),2,3),(s.Rational(3,18),2,4),(-s.Rational(4,18),4,3),(-s.Rational(3,18),4,4)]
termsB=[(s.Rational(9,18),2,2),(s.Rational(1,18),2,3),(-s.Rational(20,18),4,1),(-s.Rational(11,18),4,2),(-s.Rational(1,18),4,3)]
def exact_integral(terms):
    ans=sum((s.series(c*s.gamma(1-k+reg)*a**(k-1-reg),reg,0,1).removeO() for c,a,k in terms),s.Integer(0))
    ans=s.simplify(s.expand(ans));assert not ans.has(reg)
    return ans
ia=exact_integral(termsA);ib=exact_integral(termsB)
iab=s.Rational(8,9)*(s.log(2)-s.Rational(1,2))
total=s.simplify(ia+ib+iab+R0/I)
cross=s.simplify(-2*s.pi*total);direct=4*s.pi/3
ratio=s.simplify((direct+cross)/direct)

# Independent real quadrature of residue integrals. Taylor continuation at
# zero avoids catastrophic cancellation of separately divergent terms.
mp.mp.dps=50
def numeric(expr):
    expr=s.simplify(expr)
    small=s.series(expr,u,0,55).removeO()
    fs=s.lambdify(u,small,'mpmath');fl=s.lambdify(u,expr,'mpmath')
    return mp.quad(fs,[0,mp.mpf('.125')])+mp.quad(fl,[mp.mpf('.125'),1,mp.inf])
exprA=s.simplify((s.exp(-4*y)*(Ra+Ra0)/I).subs(y,u))
exprB=s.simplify((s.exp(-2*z)*(Rb+Rb0)/I).subs(z,u))
na,nb,nab=[numeric(e) for e in (exprA,exprB,ab_u)]
out=dict(projected_source=str(integrand),residue_integrals_divided_by_i={
    'A':str(ia),'B':str(ib),'AB':str(iab),'rational':str(R0/I),'sum':str(total)},
    cross=str(cross),direct=str(direct),ratio=str(ratio),
    quadrature={k:mp.nstr(v,45) for k,v in zip(('A','B','AB'),(na,nb,nab))},
    quadrature_total=mp.nstr(na+nb+nab+mp.mpf(35)/54,45),
    status='Exact coefficient of the specified inner harmonic reduction; full-system matching is not proved.')
path=Path(__file__).resolve().parents[1]/'data'/'inner_exact.json';path.write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2),flush=True)
