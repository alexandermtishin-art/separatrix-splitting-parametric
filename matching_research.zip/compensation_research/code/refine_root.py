"""Continue a saved secant search using a scale-aware stopping criterion."""
import json
import sys
from pathlib import Path
import gmpy2 as g
from splitting_mp import Integrator

eps=sys.argv[1];base=Path(__file__).resolve().parents[1]/'data';path=base/('root_%s.json'%eps)
g.get_context().precision=180
history=json.loads(path.read_text());first=history[0]['measurement']['harmonics'][0]
ref=[g.mpfr(first[k]) for k in ('sine','cosine')];norm=g.sqrt(sum(x*x for x in ref));ref=[x/norm for x in ref]
for _ in range(3):
    a,b=history[-2:];x,y=g.mpfr(a['rho']),g.mpfr(b['rho']);fx,fy=g.mpfr(a['projected']),g.mpfr(b['projected'])
    z=y-fy*(y-x)/(fy-fx)
    it=Integrator(eps,str(z),50,44,12)
    out=it.measure(8,'1e-10');v=[g.mpfr(out['harmonics'][0][k]) for k in ('sine','cosine')]
    val=sum((x*y for x,y in zip(v,ref)),g.mpfr(0))
    history.append(dict(rho=str(z),projected=str(val),measurement=out));path.write_text(json.dumps(history,indent=2))
    print('REFINED',str(z),str(val),'W2',out['harmonics'][1]['amplitude'],flush=True)
    if abs(val)<g.mpfr(out['melnikov_reference'])*g.mpfr('1e-18'):break
