"""Checkpointed research series for selected cases; no hidden parallelism."""
import argparse
import json
from pathlib import Path
import gmpy2 as g
from splitting_mp import Integrator

base=Path(__file__).resolve().parents[1]/'data'


def case(eps,rho='6/7',label='',dps=40,order=36,steps=12,nph=8,u0='1e-10',detuning='0'):
    g.get_context().precision=int(dps*3.321928094887363)+16
    r=g.mpfr(6)/7 if rho=='6/7' else g.mpfr(rho)
    it=Integrator(str(eps),str(r),dps,order,steps,detuning)
    out=it.measure(nph,u0)
    path=base/('mp_e%s_r%s%s.json'%(str(eps).replace('.','p'),str(rho).replace('/','over'),label))
    path.write_text(json.dumps(out,indent=2))
    print('SAVED',path.name,'W',out['harmonics'][0]['amplitude'],flush=True)
    return out


def root(eps,delta=False):
    dps=45;g.get_context().precision=170
    ref=None;history=[]
    def f(r,label):
        nonlocal ref
        dt=(r*r-1)*g.mpfr(str(eps))**2/16 if delta else g.mpfr(0)
        it=Integrator(str(eps),str(r),dps,40,12,str(dt))
        out=it.measure(8,'1e-10')
        v=[g.mpfr(out['harmonics'][0][x]) for x in ('sine','cosine')]
        if ref is None:
            norm=g.sqrt(v[0]**2+v[1]**2);ref=[x/norm for x in v]
        val=v[0]*ref[0]+v[1]*ref[1]
        item=dict(rho=str(r),projected=str(val),measurement=out)
        history.append(item)
        suffix='_matched' if delta else ''
        (base/('root_%s%s.json'%(eps,suffix))).write_text(json.dumps(history,indent=2))
        print('ROOT',label,'rho',str(r),'projected',str(val),'amplitude',out['harmonics'][0]['amplitude'],flush=True)
        return val
    e=g.mpfr(str(eps))
    x=g.mpfr(6)/7-g.mpfr('.05')*e*e
    y=g.mpfr(6)/7-g.mpfr('.035')*e*e
    fx=f(x,0);fy=f(y,1)
    for k in range(4):
        z=y-fy*(y-x)/(fy-fx)
        fz=f(z,k+2)
        x,fx,y,fy=y,fy,z,fz
        scale=g.mpfr(history[-1]['measurement']['melnikov_reference'])
        if abs(fz)<scale*g.mpfr('1e-18'):break
    return y


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode');p.add_argument('eps',nargs='?',default='0.2');a=p.parse_args()
    if a.mode=='series':
        for e in ('0.16','0.10','0.06'):
            case(e)
        for r in ('0','1'):
            case('0.12',r)
    elif a.mode=='convergence':
        case('0.2',label='_stepcheck',steps=16)
        case('0.08',label='_precisioncheck',dps=50,order=44)
        case('0.12',label='_startcheck',u0='1e-12')
    elif a.mode=='root':root(a.eps)
    elif a.mode=='matched':
        g.get_context().precision=160
        r=g.mpfr(6)/7;dt=(r*r-1)*g.mpfr('.2')**2/16
        case('0.2',detuning=str(dt),label='_matched')
    else:raise ValueError(a.mode)
