"""Summarize archived calculations and draw a standalone scientific figure."""
from pathlib import Path
import json
from decimal import Decimal as D
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

base=Path(__file__).resolve().parents[1];data=base/'data';fig=base/'figures';fig.mkdir(exist_ok=True)
def read(name):return json.loads((data/name).read_text())
names=['mp_e0p06_r6over7.json','mp_e008_r6over7.json','mp_e0p10_r6over7.json',
       'mp_e012_r6over7.json','mp_e0p16_r6over7.json','mp_e020_r6over7.json']
rows=[]
for name in names:
    d=read(name);e=D(d['eps']);r=D(d['normalized_first'])
    rows.append(dict(eps=str(e),W1=d['harmonics'][0]['amplitude'],
                     normalized=str(r),normalized_over_eps2=str(r/e**2)))
original=read('lobes_e020_r1_degree56.json');tuned=read('lobes_e020_tuned_degree56.json')
pos0=[D(x) for x in original['signed_lobe_areas'] if D(x)>0]
pos1=[D(x) for x in tuned['signed_lobe_areas'] if D(x)>0]
phi0=pos0[0];phi1=pos1[0]+pos1[1]
out=dict(fixed_control_rows=rows,
    flux_original=str(phi0),flux_tuned=str(phi1),flux_reduction=str(phi0/phi1),
    lobe_area_original=str(phi0),lobe_area_tuned=str(pos1[0]),
    single_lobe_reduction=str(phi0/pos1[0]),
    positive_lobes_per_fundamental_interval=dict(original=1,tuned=2))
checks=[('step_020','mp_e020_r6over7.json','mp_e0p2_r6over7_stepcheck.json'),
        ('precision_008','mp_e008_r6over7.json','mp_e0p08_r6over7_precisioncheck.json'),
        ('start_012','mp_e012_r6over7.json','mp_e0p12_r6over7_startcheck.json')]
out['relative_checks']={k:str(abs(D(read(a)['harmonics'][0]['amplitude'])/D(read(b)['harmonics'][0]['amplitude'])-1)) for k,a,b in checks}
out['roots']={}
for e in ('0.2','0.12','0.08'):
    path=data/('root_%s.json'%e)
    if path.exists():
        hist=json.loads(path.read_text());last=hist[-1]
        out['roots'][e]=dict(rho=last['rho'],projection=last['projected'],
            first_amplitude=last['measurement']['harmonics'][0]['amplitude'],
            evaluations=len(hist),shift_over_eps2=str((D(last['rho'])-D(6)/7)/D(e)**2))
e=np.array([float(r['eps']) for r in rows]);n=np.array([float(r['normalized']) for r in rows])
fits=[]
for degree in (1,2):
    X=np.column_stack([np.ones(len(e)),np.log(e)]+[e**k for k in range(1,degree+1)])
    c=np.linalg.lstsq(X,np.log(n),rcond=None)[0]
    fits.append(dict(correction_degree=degree,exponent=float(c[1]),observations=len(e),parameters=len(c)))
out['exponent_fits_not_confidence_intervals']=fits
(data/'summary.json').write_text(json.dumps(out,indent=2))

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
    'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})
f,ax=plt.subplots(1,2,figsize=(10,3.7),gridspec_kw={'width_ratios':[1.2,1]})
ax[0].plot(e,n/e**2,'o-',color='#175a82',lw=1.6,ms=5)
ax[0].set_xlabel(r'Pump depth $\epsilon$');ax[0].set_ylabel(r'$W_1/(\epsilon^2 W_{\rm ref})$')
ax[0].set_title(r'(a) Fixed analytic control $\rho=6/7$',loc='left',fontsize=11)
ax[0].set_ylim(.043,.053);ax[0].grid(axis='y',alpha=.2)
ax[1].bar([0,1],[float(phi0),float(phi1)],color=['#577a91','#bb6f3c'],width=.53)
ax[1].set_yscale('log');ax[1].set_ylim(1e-13,3e-7)
ax[1].set_xticks([0,1],['Original pump','Tuned pump'])
ax[1].set_ylabel('Incoming lobe area per interval')
ax[1].set_title(r'(b) Geometric transport, $\epsilon=0.2$',loc='left',fontsize=11)
for x,v in enumerate([float(phi0),float(phi1)]):ax[1].text(x,v*1.8,'%.3g'%v,ha='center',fontsize=10)
ax[1].text(.5,7e-10,r'$\approx3.95\times10^4$ reduction',ha='center',fontsize=10)
ax[1].grid(axis='y',alpha=.2);ax[1].set_axisbelow(True)
f.tight_layout(w_pad=3)
f.savefig(fig/'compensation_summary.pdf',bbox_inches='tight')
f.savefig(fig/'compensation_summary.png',dpi=180,bbox_inches='tight')
print(json.dumps(out,indent=2))
