"""Aggregate the current checks without turning point checks into guarantees."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

root=Path(__file__).resolve().parents[1]
data=root/'data';fig=root/'figures';fig.mkdir(exist_ok=True)
original=4.59535522293e-8
nominal=1.164308638981e-12
def geom(name):
    d=json.loads((data/name).read_text())
    areas=[float(v) for v in d['signed_lobe_areas'] if float(v)>0]
    # Each first-harmonic dominated case has one positive lobe per interval.
    value=float(np.mean(areas))
    return dict(incoming_area_per_interval=value,reduction=original/value,
                pointcheck_error=d['interpolation_pointcheck_error'],
                positive_lobes_per_fundamental_interval=1)
out=dict(reference_incoming_area=original,
         nominal=dict(incoming_area_per_interval=nominal,reduction=original/nominal,
                      positive_lobes_per_fundamental_interval=2),
         fine_corner=geom('lobes_error_corner.json'),
         coarse_corner=geom('lobes_coarse_error_corner.json'),
         limitation='Selected parameter points and convergence checks, not uniform or interval-certified bounds.')
(data/'transport_summary.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
cases=json.loads((data/'robustness.json').read_text())
figobj,axes=plt.subplots(1,2,figsize=(10,3.8),layout='constrained')
for prefix,label in [('dr_','Amplitude error (positive)'),('phase_','Phase error (radians)')]:
    cc=[c for c in cases if c['case'].startswith(prefix)
        and not c['case'].startswith('dr_-')]
    xs=[abs(float(c['delta_rho'] if prefix=='dr_' else c['phase'])) for c in cc]
    ys=[original/c['fourier_flux_diagnostic'] for c in cc]
    axes[0].loglog(xs,ys,'o-',label=label)
axes[0].set(xlabel='Absolute channel error',ylabel='Transport reduction (Fourier diagnostic)')
axes[0].grid(alpha=.2,which='both');axes[0].legend(fontsize=8)
vals=[original,nominal,out['fine_corner']['incoming_area_per_interval'],out['coarse_corner']['incoming_area_per_interval']]
axes[1].bar(range(4),vals,color=['#888888','#2166ac','#35978f','#bf812d'])
axes[1].set_yscale('log');axes[1].set_ylabel('Geometric incoming area per interval')
axes[1].set_xticks(range(4),['Original','Tuned','Both errors\n$10^{-4}$','Both errors\n$10^{-3}$'],fontsize=8)
axes[1].grid(axis='y',alpha=.2)
figobj.savefig(fig/'robustness_transport.pdf')
figobj.savefig(fig/'robustness_transport.png',dpi=160)
