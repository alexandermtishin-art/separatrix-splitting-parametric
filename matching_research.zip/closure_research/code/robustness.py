"""Finite-depth amplitude/phase perturbations of the counter-rotating channel."""
import json
from pathlib import Path
import gmpy2 as g
import numpy as np
from splitting_mp import Integrator

g.get_context().precision=170
rho0=g.mpfr('0.855429150290891485620876648735970618556058078946733')
base=Path(__file__).resolve().parents[1]/'data'
cases=[('nominal','0','0')]
cases += [('dr_'+s,s,'0') for s in ('1e-6','-1e-6','1e-5','-1e-5','1e-4','-1e-4','1e-3','-1e-3')]
cases += [('phase_'+s,'0',s) for s in ('1e-6','1e-5','1e-4','1e-3','1e-2')]
cases += [('corner_pp','1e-4','1e-4'),('corner_mp','-1e-4','1e-4')]
cases += [('coarse_corner_pp','1e-3','1e-3'),('coarse_corner_mp','-1e-3','1e-3')]
out=[]
for name,dr,phase in cases:
    path=base/('robust_'+name+'.json')
    if path.exists():d=json.loads(path.read_text())
    else:
        r=rho0+g.mpfr(dr)
        it=Integrator('.2',str(r),40,36,12,'0',phase)
        d=it.measure(12,'1e-10',3);d.update(case=name,delta_rho=dr)
        chi=np.linspace(0,2*np.pi,32768,endpoint=False)
        kick=np.zeros(len(chi))
        for k,h in enumerate(d['harmonics'],1):kick+=float(h['sine'])*np.sin(k*chi)+float(h['cosine'])*np.cos(k*chi)
        # A diagnostic from local hF us, not an exact manifold-area formula.
        d['fourier_flux_diagnostic']=float(np.mean(np.abs(kick))*np.pi/2)
        path.write_text(json.dumps(d,indent=2))
    out.append(d)
    (base/'robustness.json').write_text(json.dumps(out,indent=2))
    print('CASE',name,'W1',d['harmonics'][0]['amplitude'],'flux_diag',d['fourier_flux_diagnostic'],flush=True)
