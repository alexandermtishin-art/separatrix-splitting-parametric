"""Exact identities: full complex chart, fluid realization, integrable benchmark.

These identities do not imply a uniform exponentially-small matching theorem.
"""
from pathlib import Path
import json
import sympy as s

x,y,t,e,r,U,d,ph=s.symbols('x y t e r U d ph',real=True)
n=(x*x+y*y)/2
H=(1+d)*n+U*n*n/2+e*n*s.cos(2*t)+e/4*((x*x-y*y)*s.cos(2*t)-2*x*y*s.sin(2*t))
H+=r*e/4*((x*x-y*y)*s.cos(2*t+ph)+2*x*y*s.sin(2*t+ph))
u=s.diff(H,y);v=-s.diff(H,x)
assert s.simplify(s.diff(u,x)+s.diff(v,y))==0
assert s.trigsimp(H.subs({y:-y,t:-t,ph:-ph},simultaneous=True)-H)==0
zeta=s.simplify(s.diff(v,x)-s.diff(u,y))
zeta_expected=-2*(1+d+e*s.cos(2*t))-2*U*(x*x+y*y)
assert s.simplify(zeta-zeta_expected)==0
nu=s.symbols('nu',nonnegative=True)
pressure=-(u*u+v*v)/2
force=s.Matrix([s.diff(u,t),s.diff(v,t)])+zeta*s.Matrix([s.diff(H,x),s.diff(H,y)])
force-=nu*s.Matrix([s.diff(u,x,2)+s.diff(u,y,2),s.diff(v,x,2)+s.diff(v,y,2)])
for vel,fi in zip((u,v),force):
    j=0 if vel==u else 1
    gradp=s.diff(pressure,(x,y)[j])
    residual=s.diff(vel,t)+u*s.diff(vel,x)+v*s.diff(vel,y)+gradp-nu*(s.diff(vel,x,2)+s.diff(vel,y,2))-fi
    assert s.simplify(residual)==0

J,w=s.symbols('J w');V=s.symbols('V');E=s.symbols('E',nonzero=True)
K=U*J*J/2+d*J+J*(w+e*e/(16*w))
K+=r*J*(w*E+e*e/(16*w*E))+e*J*s.cos(2*t)
JN=s.simplify(-2*s.I*w*s.diff(K,w))
ww=s.simplify(2*s.I*w*s.diff(K,J))
J0=-2*s.I*J*w*(1+r*E)
w0=2*s.I*w*(U*J+w*(1+r*E)+e*s.cos(2*t))
RN=s.simplify(JN-J0);Rw=s.simplify(ww-w0)
assert s.simplify(RN-s.I*e*e*J*(1+r/E)/(8*w))==0
assert s.simplify(Rw-(2*s.I*d*w+s.I*e*e*(1+r/E)/8))==0

# Exact rotating-frame benchmark: chi'=1+eps cos 2t cancels the trace pump.
psi=s.symbols('psi',real=True)
chi=t+e*s.sin(2*t)/2
Hbench=(1+d+e*s.cos(2*t))*J+U*J*J/2+e*J*s.cos(2*psi)/2
Kbench=s.simplify(Hbench-s.diff(chi,t)*J)
assert s.simplify(Kbench-(d*J+U*J*J/2+e*J*s.cos(2*psi)/2))==0

# Independent I/Q quadratic controls, an exact channel specification.
IC=e*(s.cos(2*t)+r*s.cos(2*t+ph))/2
QC=e*(s.sin(2*t)-r*s.sin(2*t+ph))/2
Hchannels=(1+d+e*s.cos(2*t))*n+U*n*n/2+IC*(x*x-y*y)/2-QC*x*y
assert s.trigsimp(Hchannels-H)==0

out=dict(hamiltonian=str(H),fluid_velocity=[str(u),str(v)],vorticity=str(zeta),
    navier_stokes_pressure=str(pressure),force_formula='f = d_t velocity + vorticity * grad(H) - nu * laplacian(velocity)',
    fluid_divergence_zero=True,forced_navier_stokes_identity=True,opposite_phase_reversal=True,
    exact_complex_hamiltonian=str(K),inner_omitted_J=str(RN),inner_omitted_w=str(Rw),
    integrable_benchmark_angle=str(chi),integrable_benchmark_K=str(Kbench),
    quadratic_I_channel=str(IC),quadratic_Q_channel=str(QC),
    status='Exact algebraic/model identities; no assertion of experimental realization or full-system exponential matching.')
p=Path(__file__).resolve().parents[1]/'data'/'exact_identities.json';p.write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
