"""Independent geometric lobe area from stable/unstable manifold graphs.

For phase phi, reversibility gives Ws(phi)=R Wu(-phi) at t=0,
where R(q,p)=(q,-p). At phi=0 this reduces to Ws=R Wu.
We interpolate the corresponding outgoing and returning arcs, then integrate
p_out(q)+p_return(q) between adjacent intersections. This does not
use a fitted kick or a separatrix map. Chebyshev error must be checked.
"""
import argparse
import json
import time
from pathlib import Path
import gmpy2 as g
from splitting_mp import Integrator


def fmt(x):return format(x,'.38g')


def coefficients(vals,pi):
    n=len(vals)-1;out=[]
    for k in range(n+1):
        v=(vals[0]+(-1)**k*vals[-1])/2
        v+=sum((vals[j]*g.cos(pi*k*j/n) for j in range(1,n)),g.mpfr(0))
        v*=g.mpfr(2)/n
        if k in (0,n):v/=2
        out.append(v)
    return out


def evaluate(co,x):
    t0=g.mpfr(1);t1=x;d0=g.mpfr(0);d1=g.mpfr(1)
    v=co[0]+co[1]*t1;dv=co[1]
    for c in co[2:]:
        t2=2*x*t1-t0;d2=2*t1+2*x*d1-d0
        v+=c*t2;dv+=c*d2
        t0,t1,d0,d1=t1,t2,d1,d2
    return v,dv


def trace(it,eu,lnlu,u0,s,ks):
    uu=u0*g.exp(lnlu*s);q,p=uu*eu[0],uu*eu[1];out={}
    for k in range(1,max(ks)+1):
        q,p=it.strobe(q,p);q,p=-q,-p
        if k in ks:out[k]=(q,p)
    return out


def compute(eps,rho,degree=40,dps=50,span='2',qtarget='.3',detuning='0',validate=True,phase='0'):
    start=time.time();it=Integrator(eps,rho,dps,44,12,detuning,phase)
    # For nonzero phase, R maps Wu(-phase) to Ws(+phase).
    itminus=Integrator(eps,rho,dps,44,12,detuning,str(-g.mpfr(phase)))
    eu,es,lu,hf,det=it.floquet();lnlu=g.log(abs(lu));u0=g.mpfr('1e-10')
    q,p=u0*eu[0],u0*eu[1];hist=[q];up=down=None;target=g.mpfr(qtarget)
    for k in range(1,1000):
        q,p=it.strobe(q,p);q,p=-q,-p
        hist.append(q)
        if up is None and hist[-2]<target<=q:up=k
        elif up is not None and hist[-2]>target>=q:down=k;break
    if down is None:raise RuntimeError('No graph crossings')
    if g.mpfr(phase)!=0:
        eum,esm,lum,hfm,detm=itminus.floquet();lnlum=g.log(abs(lum))
        q,p=u0*eum[0],u0*eum[1];last=q;seen=False
        for k in range(1,1000):
            q,p=itminus.strobe(q,p);q,p=-q,-p
            if q>target:seen=True
            if seen and last>target>=q:down=k;break
            last=q
    else:eum=eu;lnlum=lnlu
    # Distinct keys allow both arcs to use the same iteration count.
    ks=[up,down];span=g.mpfr(span);data={0:[[],[]],1:[[],[]]}
    for j in range(degree+1):
        s=span*g.cos(it.pi*j/degree)
        if g.mpfr(phase)==0:
            z=trace(it,eu,lnlu,u0,s,ks);points=[z[up],z[down]]
        else:
            points=[trace(it,eu,lnlu,u0,s,[up])[up],trace(itminus,eum,lnlum,u0,s,[down])[down]]
        for k in (0,1):
            for c in (0,1):data[k][c].append(points[k][c])
        if j%8==0:print('NODE',j,'/',degree,'seconds',round(time.time()-start,1),flush=True)
    co={k:[coefficients(v,it.pi) for v in data[k]] for k in (0,1)}
    err=g.mpfr(0)
    if validate:
        for x in ('-.83','-.37','.19','.71'):
            x=g.mpfr(x)
            if g.mpfr(phase)==0:
                z=trace(it,eu,lnlu,u0,span*x,ks);points=[z[up],z[down]]
            else:points=[trace(it,eu,lnlu,u0,span*x,[up])[up],trace(itminus,eum,lnlum,u0,span*x,[down])[down]]
            for k in (0,1):
                for c in (0,1):err=max(err,abs(evaluate(co[k][c],x)[0]-points[k][c]))
    def limits(k):return sorted([evaluate(co[k][0],g.mpfr(-1))[0],evaluate(co[k][0],g.mpfr(1))[0]])
    lows,highs=zip(*(limits(k) for k in (0,1)));lo=max(lows);hi=min(highs)
    if hi<=lo:raise RuntimeError('No overlap')
    def p_on(k,q):
        qleft=evaluate(co[k][0],g.mpfr(-1))[0]
        qright=evaluate(co[k][0],g.mpfr(1))[0]
        x=-1+2*(q-qleft)/(qright-qleft)
        for _ in range(24):
            v,d=evaluate(co[k][0],x);dx=(v-q)/d;x-=dx
            if abs(dx)<g.mpfr('1e-43'):break
        else:raise RuntimeError('Interpolation inverse failed')
        return evaluate(co[k][1],x)[0]
    def gap(q):return p_on(0,q)+p_on(1,q)
    grid=[lo+(hi-lo)*j/400 for j in range(401)];v=[gap(q) for q in grid]
    roots=[]
    for j in range(400):
        if v[j]*v[j+1]>=0:continue
        a,b=grid[j],grid[j+1];fa=v[j]
        for _ in range(150):
            m=(a+b)/2;fm=gap(m)
            if fa*fm<=0:b=m
            else:a=m;fa=fm
            if b-a<g.mpfr('1e-40'):break
        roots.append((a+b)/2)
    import mpmath as mp
    mp.mp.dps=dps
    nodes,weights=mp.gauss_quadrature(40,'legendre')
    nodes=[g.mpfr(str(x)) for x in nodes];weights=[g.mpfr(str(x)) for x in weights]
    areas=[]
    for a,b in zip(roots[:-1],roots[1:]):
        mid=(a+b)/2;half=(b-a)/2
        area=half*sum((w*gap(mid+half*x) for x,w in zip(nodes,weights)),g.mpfr(0))
        areas.append(area)
    return dict(eps=eps,rho=rho,detuning=detuning,phase=phase,degree=degree,dps=dps,
                span=fmt(span),periods=ks,q_overlap=[fmt(lo),fmt(hi)],
                interpolation_pointcheck_error=fmt(err),roots=[fmt(x) for x in roots],
                signed_lobe_areas=[fmt(x) for x in areas],max_sampled_gap=fmt(max(abs(x) for x in v)),
                elapsed_seconds=time.time()-start,
                interpolation_coefficients={str(k):[[fmt(c) for c in cs] for cs in co[k]] for k in (0,1)})


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('eps');p.add_argument('rho')
    p.add_argument('--degree',type=int,default=40);p.add_argument('--dps',type=int,default=50)
    p.add_argument('--output',required=True);p.add_argument('--detuning',default='0');p.add_argument('--phase',default='0');a=p.parse_args()
    r=compute(a.eps,a.rho,a.degree,a.dps,detuning=a.detuning,phase=a.phase)
    Path(a.output).write_text(json.dumps(r,indent=2))
    print('RESULT',json.dumps({k:v for k,v in r.items() if k!='interpolation_coefficients'}),flush=True)
