"""Keep the new small-depth root and its numerical qualifications together."""
import json
from pathlib import Path
from decimal import Decimal,getcontext
getcontext().prec=70
root=Path(__file__).resolve().parents[1];workspace=root.parent
rows=[]
for eps in ['0.04','0.08','0.12','0.2']:
 p=root/'data/deep_root004.json' if eps=='0.04' else workspace/'compensation_research/data'/('root_'+eps+'.json')
 item=json.loads(p.read_text())[-1];rho=Decimal(item['rho'])
 rows.append(dict(eps=eps,rho=str(rho),scaled_shift=str((rho-Decimal(6)/7)/Decimal(eps)**2),source=str(p.relative_to(workspace))))
check=json.loads((root/'data/refined_point004.json').read_text())
out=dict(rows=rows,refined_sample_relative_change=check['relative_change'],
 scope='Roots of a signed projection of a local Fourier diagnostic; not zeros of an invariantly constructed splitting function, interval certificates, or an asymptotic proof.')
(root/'data/branch_summary.json').write_text(json.dumps(out,indent=2))
lines=['ЧИСЛЕННАЯ ВЕТВЬ КОМПЕНСАЦИИ: НОВАЯ ТОЧКА epsilon=0.04','8 ноября 2026','',
 'epsilon | rho (округлено) | (rho-6/7)/epsilon^2']
for row in rows:
 lines.append('%s | %.16f | %.10f'%(row['eps'],float(row['rho']),float(row['scaled_shift'])))
lines += ['',
 'Это нули знаковой проекции первой гармоники локальной диагностики hF*u*s. Их нельзя объявлять доказанными нулями инвариантной функции расщепления.',
 '',
 'Новый расчёт: 85 десятичных знаков плюс защитные биты, порядок Тейлора 56, 16 шагов на период, 4 фазы, стартовая амплитуда 1e-16. При epsilon=0.04 высшие гармоники ожидаются гораздо меньше первой на исходных точках; отдельного интервального контроля алиасинга четырёхфазной выборки нет.',
 'Настройка искалась по двум точкам с противоположными знаками и двум секущим уточнениям. Полные значения и невязки сохранены в data/deep_root004.json. Невязка секущего поиска не является оценкой полной ошибки.',
 '',
 'Проверка одной исходной точки: 100 десятичных знаков плюс защитные биты, порядок 64, 20 шагов на период, стартовая амплитуда около 1.02e-18. Начальная фаза согласована целым числом периодов через множитель Флоке, чтобы сравнивать один и тот же фазовый отсчёт.',
 'Относительное изменение этого отсчёта: '+check['relative_change']+'.',
 'Это сильная проверка сходимости одного отсчёта, но не интервальный сертификат и не проверка всей функции по параметрам.',
 '',
 'Новая точка поддерживает предел rho -> 6/7 и сдвиг порядка epsilon^2. Она не доказывает отсутствие логарифмических поправок и не превращает коэффициент сдвига в точную рациональную константу. Для этого остаётся нужна равномерная теорема согласования.',
 '',
 'Предыдущие точки взяты из неизменённого пакета v2, включающего исходные JSON пакета v1.']
(root/'NUMERICAL_BRANCH_RU.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps(out,indent=2))
