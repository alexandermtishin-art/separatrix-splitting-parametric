"""Exact scaled Hamiltonian and homoclinic used in the averaging corollary."""
import json
from pathlib import Path
import sympy as s
Q,P,u,t,eps,r,phi,d=s.symbols('Q P u t epsilon rho phi d',real=True)
I=(Q**2+P**2)/2
H0=-I**2/2+(Q**2-P**2)/4
q=s.sqrt(eps)*(Q*s.cos(t)+P*s.sin(t))
p=s.sqrt(eps)*(-Q*s.sin(t)+P*s.cos(t))
n=(q*q+p*p)/2
H=(1+d*eps**2)*n-n*n/2+eps*n*s.cos(2*t)
H+=eps*((q*q-p*p)*s.cos(2*t)-2*q*p*s.sin(2*t))/4
H+=r*eps*((q*q-p*p)*s.cos(2*t+phi)+2*q*p*s.sin(2*t+phi))/4
scaled=H0+I*s.cos(2*t)+r*((Q**2-P**2)*s.cos(4*t+phi)+2*Q*P*s.sin(4*t+phi))/4+d*eps*I
assert s.trigsimp(s.expand_trig(H-n-eps**2*scaled))==0
Q0=s.sqrt(2)*s.cosh(u/2)/s.cosh(u)
P0=s.sqrt(2)*s.sinh(u/2)/s.cosh(u)
sub={Q:Q0,P:P0}
for expr in (H0.subs(sub),s.diff(Q0,u)-s.diff(H0,P).subs(sub),s.diff(P0,u)+s.diff(H0,Q).subs(sub)):
 assert s.simplify(expr.rewrite(s.exp))==0
out=dict(scaled_hamiltonian=str(scaled),averaged_hamiltonian=str(H0),
 exact_homoclinic=[str(Q0),str(P0)],
 nearest_poles_imaginary_time='+/- pi/2',fast_phase='s=2t',
 averaging_small_parameter='h=epsilon/2',
 physical_length_scale='sqrt(epsilon)',physical_area_scale='epsilon',
 uniform_full_system_bound='For each eta in (0,pi): gap <= C_eta sqrt(epsilon) exp(-(pi-eta)/epsilon) on fixed regular arcs, at sufficiently small epsilon.',
 status='Symbolic checks supporting the application of Treschev Theorem 1; no cancellation-prefactor matching.')
path=Path(__file__).resolve().parents[1]/'data/scaled_homoclinic.json';path.write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
