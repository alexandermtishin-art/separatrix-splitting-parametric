"""A free matching datum already present in the unforced inner subsystem."""
from pathlib import Path
import json
import sympy as s
t,U=s.symbols('tau U',nonzero=True)
kappa=s.symbols('kappa')
M=s.Matrix([[-1,2/U],[U,0]])
b=s.Matrix([-s.I/(4*U),s.I/8])
v=s.Matrix([1,U])
assert (M*v-v)==s.zeros(2,1)
part=t*b/3
X=part+kappa*t*v
assert s.simplify(s.diff(X,t)-M*X/t-b)==s.zeros(2,1)
N0=s.I/(U*t);w0=-s.I/(2*t)
N2,w2=X
# Energy H=U N^2/2+N(w+epsilon^2/(16w)) at order epsilon^2.
energy2=s.simplify(U*N0*N2+N2*w0+N0*w2+N0/(16*w0))
chosen=s.solve(energy2,kappa)[0]
assert chosen==-s.I/(12*U)
eps=s.symbols('epsilon')
Ne=s.I*eps/(U*s.sinh(eps*t))
we=-s.I*eps*s.coth(eps*t/2)/4
resN=s.diff(Ne,t)+2*s.I*Ne*we-s.I*eps**2*Ne/(8*we)
resw=s.diff(we,t)-2*s.I*we*(U*Ne+we)-s.I*eps**2/8
assert s.simplify(resN.rewrite(s.exp))==0
assert s.simplify(resw.rewrite(s.exp))==0
assert s.simplify((U*Ne**2/2+Ne*(we+eps**2/(16*we))).rewrite(s.exp))==0
out=dict(linear_operator=str(M),omitted_inverse_term_source=str(b),
 second_order_general_solution=[str(x) for x in X],
 energy_at_second_order=str(energy2),zero_energy_choice=str(chosen),
 zero_energy_second_order=[str(s.simplify(x.subs(kappa,chosen))) for x in X],
 exact_zero_energy_solution=[str(Ne),str(we)],
 interpretation='The leading pole does not select the growing homogeneous second-order mode. The outer separatrix condition selects it even in an integrable benchmark.',
 scope='rho=0 and no epsilon*cos(2s) trace drive; the inverse-w terms are retained. This is a benchmark subsystem, not the full controlled model.')
p=Path(__file__).resolve().parents[1]/'data/zero_mode.json';p.write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
