"""Convergence check of one signed Fourier sample at matched launch phase."""
import json,time
from pathlib import Path
import gmpy2 as g
from splitting_mp import Integrator

base=Path(__file__).resolve().parents[1]/'data'
d=json.loads((base/'root004_case_0.json').read_text())
it=Integrator('.04',d['rho'],100,64,20)
eu,es,lu,hf,det=it.floquet()
uold=g.mpfr('1e-16')
m=int(g.rint(g.log(100)/g.log(abs(lu))))
u0=uold/abs(lu)**m
q,p=u0*eu[0],u0*eu[1]
left=False;prev2=prev=None;start=time.time()
for k in range(5000):
 q,p=it.strobe(q,p);rr=q*q+p*p
 if rr>g.mpfr('.04'):left=True
 if left:
  uu=q*es[1]-p*es[0];ss=eu[0]*p-eu[1]*q
  item=(rr,uu*ss)
  if prev2 is not None and prev[0]<prev2[0] and prev[0]<rr and prev[0]<g.mpfr('.0009'):
   value=hf*prev[1];break
  prev2,prev=prev,item
else:raise RuntimeError('No return')
old=g.mpfr(d['values'][0])
out=dict(eps='.04',rho=d['rho'],dps=100,order=64,steps=20,
 old_u0='1e-16',new_u0=str(u0),integer_phase_shift=m,
 old_sample=str(old),refined_sample=str(value),relative_change=str(abs((value-old)/old)),
 elapsed_seconds=time.time()-start,
 scope='One sample at Floquet-aligned launch phase; not interval verification.')
(base/'refined_point004.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2),flush=True)
