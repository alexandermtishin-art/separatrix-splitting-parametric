"""Deeper small-depth check, not a rigorous matching certificate."""
import json
from pathlib import Path
import gmpy2 as g
from splitting_mp import Integrator

g.get_context().precision=330
eps=g.mpfr('.04');rstar=g.mpfr(6)/7
base=Path(__file__).resolve().parents[1]/'data'
history=[];ref=None
def run(r):
    global ref
    fn=base/('root004_case_%d.json'%len(history))
    if fn.exists():d=json.loads(fn.read_text())
    else:
        it=Integrator(str(eps),str(r),85,56,16)
        d=it.measure(4,'1e-16',1)
        fn.write_text(json.dumps(d,indent=2))
    v=[g.mpfr(d['harmonics'][0][k]) for k in ('sine','cosine')]
    if ref is None:
        norm=g.sqrt(sum(x*x for x in v));ref=[x/norm for x in v]
    val=sum(x*y for x,y in zip(v,ref))
    item=dict(rho=str(r),signed_projection=str(val),measurement=d)
    history.append(item)
    (base/'deep_root004.json').write_text(json.dumps(history,indent=2))
    print('ROOT',len(history),str(r),str(val),'shift_scaled',str((r-rstar)/eps**2),flush=True)
    return val
x=rstar-g.mpfr('.045')*eps**2;y=rstar-g.mpfr('.042')*eps**2
fx=run(x);fy=run(y)
for _ in range(2):
    z=y-fy*(y-x)/(fy-fx);fz=run(z)
    x,fx,y,fy=y,fy,z,fz
print('FINAL',str(y),'scaled_shift',str((y-rstar)/eps**2),flush=True)
