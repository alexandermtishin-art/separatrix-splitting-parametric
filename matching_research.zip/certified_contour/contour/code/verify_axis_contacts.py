"""Prove two distinct cubic homoclinic contacts on phase-zero sections."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path

from run_axis_contacts import AXES, RX, RR
from verify_two_controls import evaluate, UNIT
from continue_branches import approximant, pos, BINARY_PAD
from verify_charts import ONE, ZERO, point

RU = F(".000002")
RV = F(".5")


def prove(panel):
    name,x0,rho0,_=next(a for a in AXES if a[0]==panel["section"])
    assert F(panel["x_center"])==x0 and F(panel["rho_center"])==rho0
    assert F(panel["x_radius"])==RX and F(panel["rho_radius"])==RR
    X,V=panel["x_degree"],panel["v_degree"]
    basis=[(u,v,0) for v in range(V+1) for u in range(X+1)]
    def parse(row):
        assert len(row)==len(basis)
        return {key:point(s)+abs(point(s))*BINARY_PAD*UNIT for key,s in zip(basis,row)}
    q,p=map(parse,panel["coefficients"])
    qu={(u-1,v,0):a*u for (u,v,_),a in q.items() if u}
    e=point(panel["end_error"]).b
    scales=list(map(point,(RU,RV)))
    box=(scales[0]*UNIT,scales[1]*UNIT,ZERO)
    radii=[ONE-abs(x).b for x in box]
    derivs=((1,0,0),(0,1,0))
    def derivative(poly, error, order, at=box):
        for n,r in zip(order,radii):
            for j in range(1,n+1):
                error*=j/r
        return evaluate(poly,at,order)+error*UNIT

    center=(ZERO,)*3
    raw=[p,qu]
    errors=[e,e/radii[0]]
    jac=[[point(approximant(evaluate(poly,center,k)*s)) for k,s in zip(derivs,scales)] for poly in raw]
    a,b,c,d=(a for row in jac for a in row)
    det=a*d-b*c
    pre=[[point(approximant(y/det)) for y in row] for row in [[d,-b],[-c,a]]]
    mapped=[]
    for i,row in enumerate(pre):
        keys=set(p)|set(qu)
        coeff={k:row[0]*p.get(k,ZERO)+row[1]*qu.get(k,ZERO) for k in keys}
        mapped.append((coeff,sum((abs(m)*err for m,err in zip(row,errors)),ZERO)))
    row_norms=[]
    for i,(poly,error) in enumerate(mapped):
        row_norms.append(sum((abs(point(int(i==j))-derivative(poly,error,k)*scales[j])
                              for j,k in enumerate(derivs)),ZERO).b)
    contract=max(row_norms)
    correction=max(abs(derivative(poly,error,(0,0,0),center)).b for poly,error in mapped)
    assert contract<1 and (contract+correction).b<1,(name,contract,correction,e)

    # A fixed point also satisfies |z| <= |T(0)| + L |z|.
    radius=F("0.00005")
    assert (correction/(ONE-contract)).b<point(radius).a
    tight=tuple(point(s)*point(radius)*UNIT for s in (RU,RV))+(ZERO,)
    rx,rr=point(RX),point(RR)
    px=derivative(p,e,(1,0,0),tight)/rx
    pxx=derivative(p,e,(2,0,0),tight)/rx**2
    pr=derivative(p,e,(0,1,0),tight)/rr
    qxx=derivative(q,e,(2,0,0),tight)/rx**2
    qxxx=derivative(q,e,(3,0,0),tight)/rx**3
    qxr=derivative(q,e,(1,1,0),tight)/(rx*rr)
    assert px.a>0
    cubic=2*(qxxx-3*qxx*pxx/px)/px**3
    assert cubic.a>0,(name,cubic)
    speed=2*(px*qxr-qxx*pr)/px**2
    assert speed.b<0 if name=="half-period" else speed.a>0
    return dict(section=name, original_phase="0",
                rho=list(map(str,(rho0-RR*RV*radius,rho0+RR*RV*radius))),
                x=list(map(str,(x0-RX*RU*radius,x0+RX*RU*radius))),
                cubic_gap_derivative=str(cubic), control_crossing_derivative=str(speed),
                contraction=pos(contract), normalized_image_radius=pos(contract+correction),
                root_radius_normalized=str(radius))


if __name__=="__main__":
    cli=argparse.ArgumentParser()
    cli.add_argument("panels",type=Path)
    cli.add_argument("output",type=Path)
    args=cli.parse_args()
    raw=args.panels.read_bytes()
    data=json.loads(raw)
    assert [p["section"] for p in data]==[a[0] for a in AXES]
    record=dict(panels_sha256=sha256(raw).hexdigest(),contacts=list(map(prove,data)))
    out=json.dumps(record,indent=2)+"\n"
    args.output.write_text(out)
    print(out,end="")
