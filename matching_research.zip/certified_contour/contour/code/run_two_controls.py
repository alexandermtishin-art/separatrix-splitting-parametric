"""Construct exact polydisk enclosures in one branch and two control coordinates."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
from itertools import product
from math import factorial
from pathlib import Path
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1]
sys.path[:0] = [str(BASE/"code"), str(BASE/"boundary/private")]
from mpmath import iv
from continue_branches import T, M, K, R, GROWTH, SLOPE_GROWTH, BINARY_PAD, approximant, abs_distance, compose, linear_data, local_chart, pos
from run_joint_panel import case_at, lagrange, matrix_change
from verify_charts import Gap, ZERO, ONE, point

CENTER = tuple(map(F,(".85543159924427",".00000278154772")))
SCALE = (F("4e-10"),F("4e-10"))
Q0 = F(".258850854")
RX = F(".0040")
RV = 500000
X, V = 10, 2
SKIP = 65


def support(degree):
    return [(n-w,w) for n in range(degree+1) for w in range(n+1)]


def prove_launch(case, center, slopes, x0):
    # Both parameters vary independently on a complex polydisk. The same
    # perturbation bound applies as on a single diagonal because it uses
    # absolute bounds for the two separate coordinate changes.
    base = case_at(case,center,slopes,0)
    lam, nu, A = linear_data(base)
    a,b=A[0]
    t=a+A[1][1]
    root=2*lam-t
    dd=matrix_change(center,slopes,RV)
    A0=point(".3")+abs(point(center[0]))*point(".1")*iv.sqrt(2)
    assert (A0+dd).b<point(".43").a
    matrix=(iv.pi*iv.exp((A0+dd)*iv.pi)*dd).b
    dt=2*matrix
    disc=(2*abs(t)*dt+dt**2).b
    assert disc<(root**2).a and root.a>0
    dl=((dt+disc/root)/2).b
    lo,hi=(lam-dl).a,(lam+dl).b
    assert lo>point("1.35").b and hi<point("1.38").a
    stable=(ONE/lam-a)/b
    assert abs(b).a>matrix
    ds=(dl+matrix+abs(nu)*matrix)/(abs(b)-matrix)
    dt=(dl/(lam*lo)+matrix+abs(stable)*matrix)/(abs(b)-matrix)
    assert (abs(nu)+abs(stable)+ds+dt).b<3
    separation=(abs(stable-nu)-ds-dt).a
    assert separation>0 and ((ONE+abs(nu)+ds)/separation).b<3
    assert ((ONE+abs(stable)+dt)/separation).b<3
    assert (abs(1+nu**2)-(2*abs(nu)+ds)*ds).a>1
    assert (K/lo**2+GROWTH*(1+K*R**2)**3/lo**3).b<K
    pre=R/lo*(1+K*(R/lo)**2)
    assert pre.b<point(".003").a
    assert (ONE/lo**2+SLOPE_GROWTH*pre**2/lo**3).b<point(".70").a
    assert -1<x0-RX<x0+RX<F(".5")
    power=iv.sqrt(hi) if x0+RX<=F(".25") else hi
    u=point(case["launch"])*hi**SKIP*power*iv.exp(2*point(RX)*dl/lo)
    assert u.b<R.a
    assert (6*u*(ONE+K*u**2)).b<point(".012").a


def sample(job):
    case,center,slopes,x0,periods,v,w = job
    exact={**case, "rho":str(center[0]+slopes[0]*v), "phase":str(center[1]+slopes[1]*w)}
    c,n,e=compose(local_chart(exact),x0,RX,point(case["span"]),case["launch"],periods,X,fixed_skip=SKIP)
    assert n==periods-SKIP
    return c,pos(e)


def launch_model(case, center, slopes, x0, periods, pool):
    prove_launch(case,center,slopes,x0)
    nodes = list(map(F,(-5,-3,-1,1,3,5)))
    weights = [lagrange(nodes,i) for i in range(len(nodes))]
    coeff = [{(v,w):[ZERO]*(X+1) for v,w in product(range(len(nodes)),repeat=2)} for _ in range(2)]
    jobs = [(case,center,slopes,x0,periods,v,w) for v,w in product(nodes,repeat=2)]
    error=ZERO
    for (i,j),(c,e) in zip(product(range(len(nodes)),repeat=2),pool.map(sample,jobs)):
        a,b=weights[i],weights[j]
        error+=point(e)*point(sum(map(abs,a))*sum(map(abs,b)))
        for v,w in product(range(len(nodes)),repeat=2):
            weight=point(a[v]*b[w])
            for z,row in enumerate(c):
                for k,value in enumerate(row):
                    coeff[z][v,w][k]+=weight*point(value)
    # On the unit complex disk one interpolation remainder has norm delta.
    # Apply the error one variable at a time, with the other in its outer
    # disk. The second interpolation has operator norm at most 1+delta.
    delta=point(RV)/(RV-1)*(point(6)/(RV-5))**len(nodes)
    error+=point(".024")*delta*(2+delta)
    strings=[]
    for c in coeff:
        retained=[p for v,w in support(V) for p in c[v,w]]
        strings.extend(map(approximant,retained))
        error+=sum((abs(p) for (v,w),row in c.items() if v+w>V for p in row),ZERO)
        error+=sum((abs_distance(v,s) for v,s in zip(retained,strings[-len(retained):])),ZERO)
    return strings,error


def coefficients(center, slopes):
    h=iv.pi/M
    a=point(".1")
    b,bv=(point(x)/10 for x in (center[0],slopes[0]))
    ph,pw=map(point,(center[1],slopes[1]))
    records=[]
    error=ZERO
    for j in range(M):
        c,s=iv.cos(2*j*h),iv.sin(2*j*h)
        cp,sp=[iv.cos(4*j*h+ph)],[iv.sin(4*j*h+ph)]
        for i in range(V):
            cp.append(-pw*sp[i]/(i+1))
            sp.append(pw*cp[i]/(i+1))
        for k in range(T+1):
            diag,upper,lower,anti=[],[],[],[]
            for v,w in support(V):
                factor=b if v==0 else bv if v==1 else ZERO
                const=a if (v,w,k)==(0,0,0) else ZERO
                drive=point(".2")*c if v==w==0 else ZERO
                diag.append(h*factor*sp[w])
                upper.append(h*(drive-factor*cp[w]-const))
                lower.append(h*(-drive-factor*cp[w]-const))
                anti.append(-diag[-1])
            for row in (diag,upper,lower,anti):
                strings=list(map(approximant,row))
                records.extend(strings)
                error+=sum((abs_distance(x,y) for x,y in zip(row,strings)),ZERO)
            c,s=-2*h*s/(k+1),2*h*c/(k+1)
            cp,sp=[-4*h*x/(k+1) for x in sp],[4*h*x/(k+1) for x in cp]
    time_tail=h*(point(".2")*(2*h)**(T+1)+2*(abs(b)+abs(bv))*iv.exp(abs(pw))*(4*h)**(T+1))/factorial(T+1)
    control_tail=2*h*iv.exp(4*h+abs(pw))*(abs(b)*abs(pw)**(V+1)/factorial(V+1)+abs(bv)*abs(pw)**V/factorial(V))
    hstr=approximant(h)
    return [hstr,pos(abs_distance(h,hstr)),pos(error+time_tail+control_tail),
            pos(a+abs(b)+2*matrix_change(center,slopes,1))], records


def run(arc, case, pool):
    s=1 if arc==0 else -1
    center=(CENTER[0],s*CENTER[1])
    scales=(SCALE[0],s*SCALE[1])
    seed=Gap(case).arcs[arc].inverse(Q0)
    x0=F(round(float(seed.mid)*1000000),1000000)
    periods=case["periods"][arc]
    linear_head,linear=coefficients(center,scales)
    start,error=launch_model(case,center,scales,x0,periods,pool)
    print("launch",arc,x0,pos(error),flush=True)
    msg=f"{X} {V} {periods-SKIP}\n"+" ".join(linear_head+[pos(error)]+linear+start)+"\n"
    p=subprocess.run([HERE.parent/"build/transport_two_controls"],input=msg,text=True,check=True,capture_output=True)
    lines=p.stdout.splitlines()
    e,df=lines[0].split()
    return dict(arc=arc,x_center=str(x0),x_radius=str(RX),x_degree=X,control_degree=V,
                center=list(map(str,CENTER)),scale=list(map(str,SCALE)),
                end_error=pos(point(e)*(ONE+BINARY_PAD)),defect=df,
                coefficients=[line.split() for line in lines[1:]])


if __name__=="__main__":
    cli=argparse.ArgumentParser()
    cli.add_argument("output",type=Path)
    cli.add_argument("--workers",type=int,default=8)
    args=cli.parse_args()
    case=json.loads((BASE/"boundary/data/diagonal_0998_refined.json").read_text())
    assert tuple(F(case[k]) for k in ("eps","detuning","span","launch"))==(F("0.2"),0,2,F("1e-12"))
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        panels=[]
        for arc in (0,1):
            panels.append(run(arc,case,pool))
            print("integrated",arc,panels[-1]["end_error"],flush=True)
            args.output.write_text(json.dumps(panels,indent=2)+"\n")
