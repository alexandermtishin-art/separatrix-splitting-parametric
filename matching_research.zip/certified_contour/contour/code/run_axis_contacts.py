"""Validate primary arcs on the two time-reversal sections at phase zero."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
from pathlib import Path
import json
import subprocess

from run_two_controls import HERE, BASE
from continue_branches import BINARY_PAD, M, pos
from run_joint_panel import launch_model, linear_coefficients
from verify_charts import ONE, point

AXES = [
    ("half-period", F("-.72165193961210"), F(".855422223908029"), M//2),
    ("stroboscopic", F("-.47165517691992"), F(".855436076757126"), 0),
]
RX, RR = F(".004"), F("2e-8")
X,V=10,3


def run(axis):
    name,x,rho,extra=axis
    case={"eps":"0.2","detuning":"0","launch":"1e-12","span":"2","rho":str(rho),"phase":"0"}
    center,slope=(rho,F(0)),(RR,F(0))
    periods,skip=89,65
    h,linear=linear_coefficients(center,slope,V)
    start,error=launch_model(case,center,slope,x,RX,periods,X,V,skip)
    print("launch",name,pos(error),flush=True)
    msg=f"{X} {V} {periods-skip}\n"+" ".join(h+[pos(error)]+linear+start+[str(extra)])+"\n"
    p=subprocess.run([HERE.parent/"build/transport_axis"],input=msg,text=True,check=True,capture_output=True)
    lines=p.stdout.splitlines()
    e,df=lines[0].split()
    return dict(section=name,x_center=str(x),rho_center=str(rho),x_radius=str(RX),rho_radius=str(RR),
                x_degree=X,v_degree=V,end_error=pos(point(e)*(ONE+BINARY_PAD)),
                defect=df,coefficients=[row.split() for row in lines[1:]])


if __name__=="__main__":
    cli=argparse.ArgumentParser()
    cli.add_argument("output",type=Path)
    args=cli.parse_args()
    with ProcessPoolExecutor(max_workers=2) as pool:
        data=list(pool.map(run,AXES))
    args.output.write_text(json.dumps(data,indent=2)+"\n")
