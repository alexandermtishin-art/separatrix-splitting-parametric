"""Interval verification of the fold curve in an independent two-control box."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path

from run_two_controls import CENTER, SCALE, Q0, support
from verify_charts import point, interval, ZERO, ONE
from continue_branches import BINARY_PAD, approximant, pos

RQ = F(".00035")
REAL_Q = F(".00000032")
DEG_Q, DEG_C = 11, 2
UNIT = interval(-1,1)


class Taylor:
    def __init__(self, coefficients, error=ZERO):
        self.p={key: value for key,value in coefficients.items() if value!=0}
        self.error=error.b
        self.norm=sum((abs(value) for value in self.p.values()),ZERO).b

    def __add__(self, other):
        coefficients=dict(self.p)
        for key,value in other.p.items():
            coefficients[key]=coefficients.get(key,ZERO)+value
        return Taylor(coefficients,self.error+other.error)

    def scale(self, a):
        return Taylor({key:a*value for key,value in self.p.items()},abs(a)*self.error)

    def __mul__(self, other):
        kept,dropped={},{}
        for (i,v,w),a in self.p.items():
            for (j,r,s),b in other.p.items():
                key=i+j,v+r,w+s
                out=kept if key[0]<=DEG_Q and key[1]+key[2]<=DEG_C else dropped
                out[key]=out.get(key,ZERO)+a*b
        tail=sum((abs(a) for a in dropped.values()),ZERO)
        return Taylor(kept,self.error*(other.norm+other.error)+other.error*self.norm+tail)


def evaluate(p, box, orders=(0,0,0)):
    out=ZERO
    for powers,a in p.items():
        if any(i<j for i,j in zip(powers,orders)):
            continue
        for x,i,j in zip(box,powers,orders):
            for n in range(i-j+1,i+1):
                a*=n
            a*=x**(i-j)
        out+=a
    return out


def compose(p, z):
    groups={}
    for (i,v,w),a in p.items():
        groups.setdefault(i,{})[0,v,w]=a
    result=Taylor({})
    for i in range(max(groups),-1,-1):
        result=result*z+Taylor(groups.get(i,{}))
    return result


def chart(panel):
    X,V=panel["x_degree"],panel["control_degree"]
    basis=[(i,v,w) for v,w in support(V) for i in range(X+1)]
    def parse(row):
        assert len(row)==len(basis)
        return {key:point(s)+abs(point(s))*BINARY_PAD*UNIT for key,s in zip(basis,row)}
    q,p=map(parse,panel["coefficients"])
    e=point(panel["end_error"]).b
    r=point(".65")
    slope=q[1,0,0]
    m=abs(slope).a
    variation=sum((i*abs(a)*r**(i-1) for (i,v,w),a in q.items()
                   if i and (i,v,w)!=(1,0,0)),ZERO)+e/(ONE-r)
    contraction=(variation/m).b
    offset=abs(q[0,0,0]-point(Q0))+sum((abs(a) for (i,v,w),a in q.items() if not i and v+w),ZERO)
    assert contraction<point(".2").a
    assert ((offset+point(RQ)+e)/m+contraction*r).b<r.a
    target=Taylor({(0,0,0):point(Q0),(1,0,0):point(RQ)})
    inv=Taylor({})
    for _ in range(12):
        residual=compose(q,inv)+target.scale(-ONE)
        trial=inv+residual.scale(-ONE/slope)
        inv=Taylor({key:point(approximant(a)) for key,a in trial.p.items()})
    assert inv.norm<r.a
    residual=compose(q,inv)+target.scale(-ONE)
    inverse_error=(residual.norm+residual.error+e)/(m*(ONE-contraction))
    pmod=compose(p,inv)
    p_slope=sum((i*abs(a)*r**(i-1) for (i,v,w),a in p.items() if i),ZERO)
    err=(pmod.error+p_slope*inverse_error+e).b
    return Taylor(pmod.p,err),dict(inverse_contraction=pos(contraction),graph_error=pos(err),
                                   inverse_error=pos(inverse_error))


def prove(panels):
    assert [p["arc"] for p in panels]==[0,1]
    for p in panels:
        assert tuple(map(F,p["center"]))==CENTER and tuple(map(F,p["scale"]))==SCALE
    graphs=list(map(chart,panels))
    d=graphs[0][0]+graphs[1][0]
    q=point(REAL_Q/RQ)*UNIT
    c=UNIT/2
    center=(q,ZERO,ZERO)
    box=(q,c,c)
    # Cauchy on the unit polydisk for the graph model errors. The first
    # coordinate here is normalized physical q, not a launch parameter.
    def derivative(box, order):
        err=d.error
        for i in order:
            if i==1:
                err*=2
            if i==2:
                err*=8
        return evaluate(d.p,box,order)+err*UNIT

    f_orders=((0,0,0),(1,0,0))
    j_orders=(((0,1,0),(0,0,1)),((1,1,0),(1,0,1)))
    jacobian=[[derivative(box,order) for order in row] for row in j_orders]
    a,b,c0,z=(a for row in jacobian for a in row)
    determinant=a*z-b*c0
    assert determinant.a>0 or determinant.b<0
    center_jac=[[point(approximant(derivative((ZERO,)*3,order))) for order in row] for row in j_orders]
    a,b,c0,z=(a for row in center_jac for a in row)
    det=a*z-b*c0
    m=[[point(approximant(x/det)) for x in row] for row in [[z,-b],[-c0,a]]]
    residual_matrix=[[point(int(i==j))-sum((m[i][k]*jacobian[k][j] for k in (0,1)),ZERO)
                      for j in (0,1)] for i in (0,1)]
    contraction=max(sum((abs(x) for x in row),ZERO).b for row in residual_matrix)
    f=[derivative(center,order) for order in f_orders]
    correction=[sum((m[i][k]*f[k] for k in (0,1)),ZERO) for i in (0,1)]
    inclusion=max((abs(x)+contraction/2).b for x in correction)
    curvature=derivative(box,(2,0,0))/point(RQ)**2
    assert contraction<1 and inclusion<point(".5").a, (inclusion,contraction,correction,curvature)
    assert curvature.a>0
    def fmt(a):
        return str(a)
    return dict(graphs=[g[1] for g in graphs], gap_error=pos(d.error),
                real_q=list(map(str,(Q0-REAL_Q,Q0+REAL_Q))),
                real_rho=list(map(str,(CENTER[0]-SCALE[0]/2,CENTER[0]+SCALE[0]/2))),
                real_phi=list(map(str,(CENTER[1]-SCALE[1]/2,CENTER[1]+SCALE[1]/2))),
                control_jacobian_det_unscaled=fmt(determinant/point(RQ*SCALE[0]*SCALE[1])),
                inverse_contraction=pos(contraction), normalized_control_image_radius=pos(inclusion),
                dqq=fmt(curvature))


if __name__=="__main__":
    cli=argparse.ArgumentParser()
    cli.add_argument("panels",type=Path)
    cli.add_argument("output",type=Path)
    args=cli.parse_args()
    raw=args.panels.read_bytes()
    data=prove(json.loads(raw))
    data["panels_sha256"]=sha256(raw).hexdigest()
    out=json.dumps(data,indent=2)+"\n"
    args.output.write_text(out)
    print(out,end="")
