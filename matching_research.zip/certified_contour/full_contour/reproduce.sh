#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
: "${PYTHON:=python3}"
: "${CXX:=g++}"
: "${WORKERS:=8}"
src=full_contour/code
build=full_contour/build
mkdir -p build contour/build "$build"
if [ "${FULL:-0}" = 1 ]; then
    "$CXX" -O3 -std=gnu++17 -ffp-contract=off code/transport_polynomial.cpp -lquadmath -o build/transport_polynomial
    "$CXX" -O3 -std=gnu++17 -ffp-contract=off contour/code/transport_two_controls.cpp -lquadmath -o contour/build/transport_two_controls
    "$CXX" -O3 -std=gnu++17 -ffp-contract=off boundary/private/transport_bivariate.cpp -lquadmath -o contour/build/transport_axis
    "$CXX" -O3 -std=gnu++17 -mfma -ffp-contract=off -DFAST_TWO_FOLD -DSPARSE_SPACE "$src/transport_wide.cpp" -lquadmath -o "$build/transport_wide_sparse"
    "$CXX" -O3 -std=gnu++17 -mfma -ffp-contract=off -DFAST_TWO_FOLD "$src/transport_wide.cpp" -lquadmath -o "$build/transport_wide_fast"
    "$PYTHON" "$src/wide_launch.py"
    "$PYTHON" "$src/wide_panels.py" --workers "$WORKERS"
    "$PYTHON" contour/code/run_axis_contacts.py contour/data/axis_panels.json
    for name in phase-positive amplitude-lower amplitude-upper; do
        "$PYTHON" "$src/contact_panels.py" "$name"
    done
fi
"$PYTHON" contour/code/verify_axis_contacts.py contour/data/axis_panels.json contour/data/axis_certificate.json
"$PYTHON" "$src/verify_contacts.py" phase-positive
"$PYTHON" "$src/verify_axis_unfolding.py" amplitude-lower
"$PYTHON" "$src/verify_axis_unfolding.py" amplitude-upper
"$PYTHON" "$src/verify_wide.py" --workers "$WORKERS"
"$PYTHON" "$src/stitch.py"
