"""Stitch verified chart overlaps, classify all vertices, and verify the seam."""
from fractions import Fraction as F
from hashlib import sha256
import json

from verify_wide import CENTER, HERE, Q_CENTERS, SCALES
from verify_charts import point, interval
from continue_branches import approximant, pos


def frac_box(s):
    return tuple(map(F,s))


def signed_blocks(slabs,sign,slope,q):
    assert sign(slabs[0]) and sign(slabs[-1])
    roots=[]
    k=1
    while k<len(slabs):
        left=sign(slabs[k-1])
        assert left
        if sign(slabs[k]):
            assert sign(slabs[k])==left
            k+=1
            continue
        i=k
        while not sign(slabs[k]):
            k+=1
        block=slabs[i:k]
        direction=slope(block[0])
        assert direction and all(slope(row)==direction for row in block)
        right=sign(slabs[k])
        if right!=left:
            assert left==-direction and right==direction
            roots.append(([q(block[0])[0],q(block[-1])[1]],direction))
        k+=1
    return roots


def intersects(a,b):
    return not (a.b<b.a or b.b<a.a)


def prove_simple_loop(slabs,vertices):
    # Every overlapping pair of control boxes must lie on a short arc
    # where either the contact normal or its orthogonal projection is
    # confined to an open half-plane, with at most one cusp on that arc.
    q=[tuple(map(F,s["physical_q"])) for s in slabs]
    controls=[list(map(point,s["controls"])) for s in slabs]
    normals=[list(map(point,s["normal"])) for s in slabs]
    angles=[point(s["angle_det"]).a for s in slabs]
    assert min(angles)>0
    cusp_boxes=[tuple(map(F,r["q"])) for r in vertices]
    n=len(slabs)
    pending=0
    longest=0
    for i in range(n):
        for j in range(i,n):
            if not all(intersects(a,b) for a,b in zip(controls[i],controls[j])):
                continue
            pending+=1
            if j-i<=n-(j-i):
                chain=list(range(i,j+1))
                ranges=[(q[i][0],q[j][1])]
            else:
                chain=list(range(j,n))+list(range(i+1))
                ranges=[(q[j][0],q[-1][1]),(q[0][0],q[i][1])]
            assert sum(any(l<=b and a<=r for l,r in ranges) for a,b in cusp_boxes)<=1
            reference=[point(approximant(x)) for x in normals[chain[len(chain)//2]]]
            assert all(sum(a*b for a,b in zip(reference,normals[k])).a>0 for k in chain), (i,j)
            longest=max(longest,len(chain))
    return dict(comparisons=n*(n+1)//2,overlapping_pairs=pending,max_local_chain=longest,
                strict_normal_rotation_lower=pos(min(angles)))


def prove():
    data=HERE.parent/"data"
    panels=[json.loads((data/f"wide-{i:02d}-certificate.json").read_text()) for i in range(len(Q_CENTERS))]
    for i,p in enumerate(panels):
        assert p["index"]==i
        assert p["panel_sha256"]==[sha256((data/f"wide-{i:02d}-{a}.json").read_bytes()).hexdigest()
                                   for a in (0,1)]
        slabs=p["slabs"]
        assert slabs[0]["physical_q"][0]==p["q_range"][0]
        assert slabs[-1]["physical_q"][1]==p["q_range"][1]
        for a,b in zip(slabs,slabs[1:]):
            assert F(a["physical_q"][1])==F(b["physical_q"][0])
    for a,b in zip(panels,panels[1:]):
        assert F(a["q_range"][1])==F(b["q_range"][0])
        for x,y in zip(a["x_ranges"],b["x_ranges"]):
            xa,xb=frac_box(x)
            ya,yb=frac_box(y)
            assert max(xa,ya)<min(xb,yb)
    # Each exact arc has a signed nonzero q derivative on each x range.
    # Overlap makes the two real inverses identical on the common q boundary.
    left,right=panels[0],panels[-1]
    assert left["boundary"] and right["boundary"]
    assert left["slabs"][0]["x_lo_sign"] and right["slabs"][-1]["x_hi_sign"]
    yfirst=interval(*frac_box(left["x_ranges"][1]))
    ylast=interval(*frac_box(right["x_ranges"][1]))
    stable_left=point(left["boundary"]["stable_launch_at_seam"])
    stable_right=point(right["boundary"]["stable_launch_at_seam"])
    image=stable_left-point(".5")
    preimage=stable_right+point(".5")
    assert ylast.a<image.a and image.b<ylast.b
    assert yfirst.a<preimage.a and preimage.b<yfirst.b
    # At a common intersection T shifts unstable x by +.5 and stable y by -.5.
    # T preserves contact multiplicity. The image is in the last primary chart,
    # so uniqueness and monotonic x along the curve identify its other endpoint.
    slabs=[s for p in panels for s in p["slabs"]]
    regions=[dict(q=q,sign_of_dqq_along_curve_derivative=s) for q,s in signed_blocks(
        slabs,lambda r:r["signs"][0],lambda r:r["signs"][1],lambda r:r["physical_q"])]
    assert len(regions)==4
    # All four uncertain-curvature bands are strictly inside the seam.
    source_q=point(left["boundary"]["physical_q_for_launch_seam"])
    target_q=point(right["boundary"]["physical_q_for_launch_seam"])
    assert point(regions[0]["q"][0]).a>source_q.b
    assert point(regions[-1]["q"][1]).b<target_q.a
    fundamental=interval("-.88","-.38")
    active=[s for s in slabs if intersects(point(s["x"]),fundamental)]
    assert active
    shape=prove_simple_loop(active,regions)
    # Reflection exchanges x and y, up to period shifts. The reflected y
    # after moving its outgoing x into the fundamental strip lies in the
    # same single monotone stable chart.
    stable_domain=interval(frac_box(right["x_ranges"][1])[0],frac_box(left["x_ranges"][1])[1])
    for s in active:
        reflected_y=point(s["x"])+point(s["y"])-fundamental
        assert stable_domain.a<reflected_y.a and reflected_y.b<stable_domain.b
    anchors={}
    for name,want in (("center",4),("top",2)):
        roots=signed_blocks([s for p in panels for s in p["anchors"][name]],
                            lambda r:r["sign"],lambda r:r["slope"],lambda r:r["q"])
        qa=point(left["boundary"][name])
        qb=point(right["boundary"][name])
        boxes=[]
        for q,_ in roots:
            box=interval(*map(F,q))
            if box.b<qa.a or box.a>qb.b:
                continue
            assert qa.b<box.a and box.b<qb.a
            boxes.append(q)
        assert len(boxes)==want,(name,roots,qa,qb)
        anchors[name]=dict(simple_crossings=len(boxes),incoming_lobes=len(boxes)//2,roots=boxes)
    tolerance=F("2.35e-6"),F("2.65e-6")
    radii=[point(r/s) for r,s in zip(tolerance,SCALES)]
    clearance=min(max((abs(point(box)).a-r).a for box,r in zip(row["controls"],radii))
                  for row in slabs)
    assert clearance>point("4e-4").b
    # The tolerance rectangle contains the interior anchor and cannot meet
    # the closed transition contour, so it lies in the same component.
    robust_box=dict(center=list(map(str,CENTER)),half_width=["2.35e-6","2.65e-6"],
                    normalized_separation_lower="4e-4",incoming_lobes=2)
    return dict(scope="primary arc pair on one fundamental segment",
                q_range=[left["q_range"][0],right["q_range"][1]],
                x_period=["-22/25","-19/50"], panel_count=len(panels), slab_count=len(slabs),
                max_contraction=pos(max(point(row["contraction"]).b for row in slabs)),
                closed_seam=True, all_cubic_vertices=regions,simple_loop=shape,
                phase_reflection=True, anchors=anchors, robust_box=robust_box)


if __name__=="__main__":
    result=prove()
    out=json.dumps(result,indent=2)+"\n"
    (HERE.parent/"data"/"closed-contour-certificate.json").write_text(out)
    print(out,end="")
