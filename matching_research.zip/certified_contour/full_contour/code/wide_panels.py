"""Validated primary arcs on a common rectangle of independent controls."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
from itertools import product
import json
import os
from pathlib import Path
import subprocess

from wide_launch import HERE, ROOT, CASE, CENTER, SCALES, OUTER, NODES, SKIP, V, base, cb
from verify_charts import Gap, ZERO, ONE, point

X=16
RX=F(".065")
Q_CENTERS=tuple(F(".200")+F(".007")*i for i in range(14))
CACHE=HERE.parent/"build/wide_launch_cache.json"
REFERENCE=ROOT/"boundary/data/diagonal_0998_refined.json"
DENSE_PANELS={(1,0),(1,1),(2,0),(3,0),(3,1)}


def charts_load():
    raw=json.loads(CACHE.read_text())
    def iv(x):
        return base.iv.make_mpf(tuple(map(tuple,x)))
    return [{**{k:iv(row[k]) for k in ("lambda","slope","chart_error")},
             "poly":[[iv(a) for a in r] for r in row["poly"]]} for row in raw]


def launch(charts,x0,periods):
    assert -1<=x0-RX<x0+RX<=F(".5")
    assert RX<=F(".08")
    nodes=NODES
    L=len(nodes)
    weights=[base.lagrange(nodes,i) for i in range(L)]
    norm=[sum(map(abs,w)) for w in weights]
    retained=base.support(V)
    coeff=[{k:[ZERO]*(X+1) for k in retained} for _ in range(2)]
    error=ZERO
    # Separable interval interpolation, first in the phase coordinate.
    samples=[]
    for i,j in product(range(L),repeat=2):
        row,n,e=cb.compose(charts[i*L+j],x0,RX,point(CASE["span"]),CASE["launch"],periods,X,fixed_skip=SKIP)
        assert n==periods-SKIP
        samples.append([[point(a) for a in r] for r in row])
        error+=e*point(norm[i]*norm[j])
    inner=[]
    for i in range(L):
        result=[[[ZERO]*(X+1) for _ in range(L)] for _ in range(2)]
        for j in range(L):
            for w,t in enumerate(weights[j]):
                t=point(t)
                for z in (0,1):
                    for k in range(X+1):
                        result[z][w][k]+=t*samples[i*L+j][z][k]
        inner.append(result)
    for z in (0,1):
        for v,w in product(range(L),repeat=2):
            total=[ZERO]*(X+1)
            for i in range(L):
                a=point(weights[i][v])
                for k in range(X+1):
                    total[k]+=a*inner[i][z][w][k]
            if (v,w) in coeff[z]:
                coeff[z][v,w]=total
            else:
                error+=sum(map(abs,total),ZERO)
    radius=point(OUTER/max(SCALES))
    size=point(max(map(abs,nodes)))
    delta=radius/(radius-1)*((ONE+size)/(radius-size))**L
    error+=point(".024")*delta*(2+delta)
    txt=[]
    for c in coeff:
        for v,w in retained:
            vals=c[v,w]
            printed=list(map(cb.approximant,vals))
            txt.extend(printed)
            error+=sum((cb.abs_distance(a,b) for a,b in zip(vals,printed)),ZERO)
    return txt,error


PERIODS=(86,92)


def run(job):
    i,arc=job
    qc=Q_CENTERS[i]
    reference=json.loads(REFERENCE.read_text())
    period=PERIODS[arc]
    x0=F(round(float(Gap(reference).arcs[arc].inverse(qc).mid)*10**6),10**6)-F(arc,2)
    charts=charts_load()
    if arc:
        L=len(NODES)
        charts=[charts[i*L+(L-1-j)] for i,j in product(range(L),repeat=2)]
    base.V=V
    scale=(SCALES[0],SCALES[1]*(1-2*arc))
    h,linear=base.coefficients(CENTER,scale)
    start,e=launch(charts,x0,period)
    print("launch",i,arc,str(x0),cb.pos(e),flush=True)
    msg=f"{X} {V} {period-SKIP}\n"+" ".join(h+[cb.pos(e)]+linear+start)+"\n"
    default="transport_wide_fast" if job in DENSE_PANELS else "transport_wide_sparse"
    exe=HERE.parent/"build"/os.environ.get("KERR_WIDE_EXE",default)
    proc=subprocess.run([exe],input=msg,text=True,check=True,capture_output=True)
    lines=proc.stdout.splitlines()
    error,defect=lines[0].split()
    out=dict(index=i,arc=arc,period=period,q_center=str(qc),x_center=str(x0),
             x_radius=str(RX),x_degree=X,control_degree=V,
             center=list(map(str,CENTER)),scale=list(map(str,SCALES)),
             end_error=cb.pos(point(error)*(ONE+cb.BINARY_PAD)),defect=defect,
             coefficients=[row.split() for row in lines[1:]])
    path=HERE.parent/"data"/f"wide-{i:02d}-{arc}.json"
    path.write_text(json.dumps(out,indent=2)+"\n")
    print("integrated",i,arc,out["end_error"],flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("panels",type=int,nargs="*")
    p.add_argument("--workers",type=int,default=8)
    p.add_argument("--resume",action="store_true")
    args=p.parse_args()
    panels=args.panels or list(range(len(Q_CENTERS)))
    jobs=[(i,a) for i in panels for a in (0,1)]
    if args.resume:
        jobs=[(i,a) for i,a in jobs if not (HERE.parent/"data"/f"wide-{i:02d}-{a}.json").is_file()]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        list(pool.map(run,jobs))
