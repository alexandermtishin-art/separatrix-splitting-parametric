"""Verify two-control unfolding at the independently enclosed axial contacts."""
from fractions import Fraction as F
from hashlib import sha256
import argparse
import json

from contact_panels import ROOT, HERE, CONTACTS, RHO_RADIUS, PHI_RADIUS
from verify_contacts import RQ, derivative
from verify_charts import ZERO, point, interval
from continue_branches import BINARY_PAD
import verify_two_controls as tm


def verify(name):
    q0,rho0,_,*_=map(F,CONTACTS[name])
    source=ROOT/"contour/data/axis_certificate.json"
    old=json.loads(source.read_text())
    contact=old["contacts"][0 if name=="amplitude-lower" else 1]
    x=interval(*map(F,contact["x"]))
    y=x+point(1 if name=="amplitude-lower" else ".5")
    rho=interval(*map(F,contact["rho"]))
    paths=[HERE.parent/"data"/f"{name}-{i}.json" for i in (0,1)]
    raw=[p.read_bytes() for p in paths]
    panels=list(map(json.loads,raw))
    tm.Q0,tm.RQ=q0,RQ
    for i,p in enumerate(panels):
        assert p["arc"]==i and tuple(map(F,p["center"]))==(rho0,0)
        assert tuple(map(F,p["scale"]))==(RHO_RADIUS,PHI_RADIUS)
        assert abs(((x,y)[i]-point(p["x_center"]))/point(p["x_radius"])).b<point(".65").a
    d=tm.chart(panels[0])[0]+tm.chart(panels[1])[0]
    out=panels[0]
    X,V=out["x_degree"],out["control_degree"]
    basis=[(i,v,w) for v,w in tm.support(V) for i in range(X+1)]
    qout=tm.Taylor({key:point(s)+abs(point(s))*BINARY_PAD*tm.UNIT for key,s in zip(basis,out["coefficients"][0])},
                  point(out["end_error"]))
    v=(rho-point(rho0))/point(RHO_RADIUS)
    u=(x-point(out["x_center"]))/point(out["x_radius"])
    q=derivative(qout,(0,0,0),(u,v,ZERO))
    z=(q-point(q0))/point(RQ)
    assert abs(z).b<point(".01").a
    box=(z,v,ZERO)
    a,b=derivative(d,(0,1,0),box),derivative(d,(0,0,1),box)
    c,e=derivative(d,(1,1,0),box),derivative(d,(1,0,1),box)
    det=(a*e-b*c)/point(RQ*RHO_RADIUS*PHI_RADIUS)
    cubic=derivative(d,(3,0,0),box)/point(RQ**3)
    assert det.a>0 and (cubic.a>0 or cubic.b<0),(name,det,cubic)
    return dict(contact=name,rho=contact["rho"],phi="0",q=str(q),control_jacobian=str(det),dqqq=str(cubic),
                source_sha256=sha256(source.read_bytes()).hexdigest(),
                panel_sha256=[sha256(s).hexdigest() for s in raw])


if __name__=="__main__":
    cli=argparse.ArgumentParser()
    cli.add_argument("name",choices=("amplitude-lower","amplitude-upper"))
    name=cli.parse_args().name
    out=json.dumps(verify(name),indent=2)+"\n"
    (HERE.parent/"data"/f"{name}-unfolding.json").write_text(out)
    print(out,end="")
