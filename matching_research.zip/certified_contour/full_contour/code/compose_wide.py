"""Complex-disk polynomial composition with a coefficient-norm error bound."""
from itertools import product
import numpy as np

from verify_charts import point, ZERO, ONE
from continue_branches import approximant
from run_two_controls import support

LONG=np.longdouble
U64=point("1e-19")
ADD_PAD=point("1e-18")
PROD_PAD=point("1e-15")
NORM_PAD=point("1e-16")
TINY=point("1e-300")


def ivnum(x):
    return point(np.format_float_scientific(x,unique=True,trim="k"))


def norm(a):
    return (ivnum(np.sum(np.abs(a),dtype=LONG))*(ONE+NORM_PAD)+TINY).b


class Algebra:
    def __init__(self,n,v):
        assert np.finfo(LONG).nmant>=63 and n<=20 and v<=4
        self.n,self.v=n,v
        self.support=support(v)
        self.pairs=list(product(self.support,repeat=2))
        self.shape=(v+1,v+1,n+1)

    def from_poly(self,p):
        a=np.zeros(self.shape,dtype=LONG)
        error=ZERO
        for (i,v,w),x in p.items():
            a[v,w,i]=LONG(approximant(x))
            s=ivnum(a[v,w,i])
            error+=abs(x-s)+abs(s)*U64
        return a,error.b

    def product(self,x,y):
        a,ea=x
        b,eb=y
        kept=np.zeros(self.shape,dtype=LONG)
        # Nonnegative summation majorizes the l1 norm of discarded monomials.
        tail=ZERO
        ac=[bool(np.any(a[v,w])) for v,w in self.support]
        bc=[bool(np.any(b[v,w])) for v,w in self.support]
        for (ia,(v,w)),(ib,(r,s)) in product(enumerate(self.support),repeat=2):
            if not (ac[ia] and bc[ib]):
                continue
            terms=np.convolve(a[v,w],b[r,s])
            if v+w+r+s<=self.v:
                kept[v+r,w+s]+=terms[:self.n+1]
                tail+=norm(terms[self.n+1:])
            else:
                tail+=norm(terms)
        na,nb=norm(a),norm(b)
        # Each coefficient is a sum of fewer than 10000 products. The
        # allowance also covers errors in evaluating the discarded sums.
        error=ea*(nb+eb)+eb*na+tail+PROD_PAD*na*nb+TINY
        return kept,error.b

    def plus(self,x,y):
        a,ea=x
        b,eb=y
        return a+b,(ea+eb+ADD_PAD*(norm(a)+norm(b))+TINY).b

    def compose(self, p, z):
        groups={}
        for (i,v,w),a in p.items():
            groups.setdefault(i,{})[0,v,w]=a
        zz=self.from_poly(z)
        result=(np.zeros(self.shape,dtype=LONG),ZERO)
        for i in range(max(groups),-1,-1):
            result=self.plus(self.product(result,zz),self.from_poly(groups.get(i,{})))
        return result

    def export(self,x):
        a,e=x
        p={}
        for v,w in self.support:
            for i,value in enumerate(a[v,w]):
                if value:
                    x=ivnum(value)
                    p[i,v,w]=x
                    e+=abs(x)*U64
        return p,e.b
