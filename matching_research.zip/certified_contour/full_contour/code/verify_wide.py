"""Verify existence, uniqueness, and curvature along the entire transition curve."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path

import numpy as np

from wide_panels import HERE, Q_CENTERS, CENTER, SCALES, X, V, RX, PERIODS, base, cb
from verify_charts import point, interval, ZERO, ONE
from verify_contacts import cauchy, jet, shift
from compose_wide import Algebra
import verify_two_controls as tm

RQ=F(".0052")
Q_HALF=F(".0035")
CONTROL=F(".5")
REAL_X=F(".70")
N=18
SUBDIVISIONS=44
DIRS=((0,1,0),(0,0,1))
ORDERS=((0,0,0),(1,0,0))
DZZ=(2,0,0)


def array_coefficients(p):
    a=np.zeros((V+1,V+1,N+1),dtype=np.longdouble)
    for (i,v,w),x in p.items():
        a[v,w,i]=np.longdouble(cb.approximant(x))
    return a


def inverse_candidate(q,slope,q0):
    # This approximate iteration only proposes coefficients. An independent
    # complex residual verifies the proposal, including its rounding errors.
    support=base.support(V)
    inputs=array_coefficients(q)
    target=np.zeros_like(inputs)
    target[0,0,0]=np.longdouble(cb.approximant(point(q0)))
    target[0,0,1]=np.longdouble(cb.approximant(point(RQ)))
    p=np.zeros_like(inputs)
    slope0=np.longdouble(cb.approximant(slope))
    pairs=[(a,b,c,d) for (a,b),(c,d) in product(support,repeat=2) if a+b+c+d<=V]
    for _ in range(19):
        out=np.zeros_like(p)
        for i in range(X,-1,-1):
            previous=out
            out=np.zeros_like(p)
            for a,b,c,d in pairs:
                if np.any(p[c,d]) and np.any(previous[a,b]):
                    out[a+c,b+d]+=np.convolve(previous[a,b],p[c,d])[:N+1]
            out[:,:,0]+=inputs[:,:,i]
        p+=(target-out)/slope0
    return tm.Taylor({(i,v,w):point(str(a)) for v,w in support
                      for i,a in enumerate(p[v,w]) if a!=0})


def chart(panel):
    tm.DEG_Q,tm.DEG_C=N,V
    q0=F(panel["q_center"])
    basis=[(i,v,w) for v,w in base.support(V) for i in range(X+1)]
    def parse(row):
        assert len(row)==len(basis)
        return {key:point(s)+abs(point(s))*cb.BINARY_PAD*tm.UNIT for key,s in zip(basis,row)}
    q,p=map(parse,panel["coefficients"])
    err=point(panel["end_error"]).b
    rad=point(REAL_X)
    slope=q[1,0,0]
    assert ((1-2*panel["arc"])*slope).a>0
    m=abs(slope).a
    vary=sum((i*abs(a)*rad**(i-1) for (i,v,w),a in q.items()
              if i and (i,v,w)!=(1,0,0)),ZERO)+err/(ONE-rad)
    contraction=(vary/m).b
    offset=abs(q[0,0,0]-point(q0))+sum((abs(a) for (i,v,w),a in q.items() if not i and v+w),ZERO)
    assert contraction<point(".2").a
    assert ((offset+point(RQ)+err)/m+contraction*rad).b<rad.a,(q0,panel["arc"],slope,offset,vary)
    candidate=inverse_candidate(q,slope,q0)
    assert candidate.norm<rad.a
    algebra=Algebra(N,V)
    res=algebra.plus(algebra.compose(q,candidate.p),
                     algebra.from_poly({(0,0,0):-point(q0),(1,0,0):-point(RQ)}))
    residual=tm.Taylor(*algebra.export(res))
    ie=(residual.norm+residual.error+err)/(m*(ONE-contraction))
    pmod=tm.Taylor(*algebra.export(algebra.compose(p,candidate.p)))
    pprime=sum((i*abs(a)*rad**(i-1) for (i,v,w),a in p.items() if i),ZERO)
    e=(pmod.error+pprime*ie+err).b
    kept={}
    for key,a in pmod.p.items():
        if abs(a).b<point("1e-24").a:
            e+=abs(a)
        else:
            kept[key]=a
    return tm.Taylor(kept,e), tm.Taylor(candidate.p,ie), tm.Taylor(q,err), panel


def evaluate(p,box,orders=(0,0,0)):
    u,v,w=box
    a,b,c=orders
    from math import factorial
    powers=[[x**j*point(factorial(j+n)//factorial(j)) for j in range(k+1-n)]
            for x,n,k in zip((u,v,w),(a,b,c),(N,V,V))]
    px,pv,pw=powers
    return sum((coeff*px[i-a]*pv[j-b]*pw[k-c] for (i,j,k),coeff in p.items()
                if i>=a and j>=b and k>=c),ZERO)


def derivative(d,order,box):
    return evaluate(d.p,box,order)+cauchy(d.error,order,box)*tm.UNIT


def invert2(a,b,c,d):
    det=a*d-b*c
    return [[point(cb.approximant(x/det)) for x in row] for row in [[d,-b],[-c,a]]]


def interval_matrix(j):
    a,b=j[0]
    c,d=j[1]
    det=a*d-b*c
    assert det.a>0,(a,b,c,d,det)
    return [[d/det,-b/det],[-c/det,a/det]], det


def precondition(d,inv):
    models=[]
    for row in inv:
        out={}
        for a,order in zip(row,ORDERS):
            for key,coeff in jet(d,order).items():
                out[key]=out.get(key,ZERO)+a*coeff
        models.append(out)
    return models


def real_interval(c,r):
    return point(c)+point(r)*tm.UNIT


def prove_slab(d, outgoing, returning, qbox, qc):
    candidate=[ZERO,ZERO]
    # A few unconstrained polynomial Newton steps provide a box center.
    for _ in range(3):
        b=(qc,*candidate)
        j=[[evaluate(d.p,b,shift(order,direction)) for direction in DIRS] for order in ORDERS]
        inv=invert2(*j[0],*j[1])
        values=[evaluate(d.p,b,order) for order in ORDERS]
        candidate=[point(cb.approximant(x-sum((a*f for a,f in zip(row,values)),ZERO)))
                   for x,row in zip(candidate,inv)]
    models=precondition(d,inv)
    full=(qbox,real_interval(0,CONTROL),real_interval(0,CONTROL))
    local=(qbox,*candidate)
    contraction=ZERO
    correction=ZERO
    for i,(row,model) in enumerate(zip(inv,models)):
        measure=ZERO
        for j,direction in enumerate(DIRS):
            err=sum((abs(a)*cauchy(d.error,shift(order,direction),full)
                     for a,order in zip(row,ORDERS)),ZERO)
            value=evaluate(model,full,direction)+err*tm.UNIT
            measure+=abs(point(int(i==j))-value)
        contraction=max(contraction,measure.b)
        err=sum((abs(a)*cauchy(d.error,order,local) for a,order in zip(row,ORDERS)),ZERO)
        correction=max(correction,(abs(evaluate(model,local))+err).b)
    assert contraction<1,(contraction,d.error)
    radius=(correction/(ONE-contraction)).b
    assert max((abs(x)+radius).b for x in candidate)<point(CONTROL).a,(
        candidate,radius,contraction,d.error)
    box=(qbox,*(c+radius*tm.UNIT for c in candidate))
    j=[[derivative(d,shift(order,direction),box) for direction in DIRS] for order in ORDERS]
    ji,det=interval_matrix(j)
    dzz=derivative(d,DZZ,box)
    dc=[-row[1]*dzz for row in ji]
    g=j[0]
    dg=[j[1][i]+sum((derivative(d,shift(DIRS[i],direction),box)*vel
                     for direction,vel in zip(DIRS,dc)),ZERO) for i in range(2)]
    angle_det=g[0]*dg[1]-g[1]*dg[0]
    assert angle_det.a>0
    dzzz=derivative(d,(3,0,0),box)
    bend=dzzz+sum((derivative(d,shift(DZZ,dirn),box)*vel for dirn,vel in zip(DIRS,dc)),ZERO)
    _,xi,qout,panel=outgoing
    u=derivative(xi,(0,0,0),box)
    pos_x=point(panel["x_center"])+point(RX)*u
    _,eta,_,rp=returning
    pos_y=point(rp["x_center"])+point(RX)*derivative(eta,(0,0,0),box)
    partial=[derivative(qout,dirn,(u,*box[1:])) for dirn in DIRS]
    assert (point(RQ)-sum((a*b for a,b in zip(partial,dc)),ZERO)).a>0
    return dict(contraction=cb.pos(contraction),control_radius=cb.pos(radius), x=str(pos_x), y=str(pos_y),
                det=str(det/point(RQ*SCALES[0]*SCALES[1])),
                curvature=str(dzz/point(RQ**2)), curvature_derivative=str(bend/point(RQ**3)),
                q=str(qbox), controls=list(map(str,box[1:])), normal=list(map(str,g)),
                angle_det=cb.pos(point(".999999")*angle_det.a),
                signs=[int(dzz.a>0)-int(dzz.b<0),int(bend.a>0)-int(bend.b<0)],
                x_lo_sign=int(pos_x.b<point("-.88").a),x_hi_sign=int(pos_x.a>point("-.38").b))


def panel_proof(index,subdivisions):
    paths=[HERE.parent/"data"/f"wide-{index:02d}-{a}.json" for a in (0,1)]
    raw=[p.read_bytes() for p in paths]
    panels=list(map(json.loads,raw))
    q0=Q_CENTERS[index]
    for a,p in enumerate(panels):
        assert p["index"]==index and p["arc"]==a and F(p["q_center"])==q0
        assert p["period"]==PERIODS[a]
        assert tuple(map(F,p["center"]))==CENTER and tuple(map(F,p["scale"]))==SCALES
        assert F(p["x_radius"])==RX and p["x_degree"]==X and p["control_degree"]==V
    out,ret=map(chart,panels)
    d=out[0]+ret[0]
    print("graph",index,cb.pos(d.error),flush=True)
    b=Q_HALF/RQ
    slabs=[]
    anchor_records={name:[] for name in ("center","top")}
    for i in range(subdivisions):
        a,z=-b+2*b*F(i,subdivisions),-b+2*b*F(i+1,subdivisions)
        try:
            record=prove_slab(d,out,ret,interval(a,z),point((a+z)/2))
        except AssertionError as e:
            raise AssertionError(index,i,e) from e
        record["physical_q"]=list(map(str,(q0+RQ*a,q0+RQ*z)))
        slabs.append(record)
        for name,w in (("center",ZERO),("top",point(CONTROL))):
            box=(interval(a,z),ZERO,w)
            value=derivative(d,(0,0,0),box)
            slope=derivative(d,(1,0,0),box)
            anchor_records[name].append(dict(q=record["physical_q"],
                 sign=int(value.a>0)-int(value.b<0), slope=int(slope.a>0)-int(slope.b<0)))
    x_seam=F("-.88") if index==0 else F("-.38")
    boundary={}
    if index in (0,len(Q_CENTERS)-1):
        u0=point((x_seam-F(out[3]["x_center"]))/RX)
        assert abs(u0).b<point(REAL_X).a
        full=(u0,real_interval(0,CONTROL),real_interval(0,CONTROL))
        qb=derivative(out[2],(0,0,0),full)
        assert qb.a>point(q0-Q_HALF).b and qb.b<point(q0+Q_HALF).a
        boundary["physical_q_for_launch_seam"]=str(qb)
        ret0=derivative(ret[1],(0,0,0),((qb-point(q0))/point(RQ),*full[1:]))
        boundary["stable_launch_at_seam"]=str(point(ret[3]["x_center"])+point(RX)*ret0)
        for name,w in (("center",ZERO),("top",point(CONTROL))):
            boundary[name]=str(derivative(out[2],(0,0,0),(u0,ZERO,w)))
    data=dict(index=index,boundary=boundary,anchors=anchor_records,graph_error=cb.pos(d.error),q_range=list(map(str,(q0-Q_HALF,q0+Q_HALF))),
              x_ranges=[list(map(str,(F(p["x_center"])-RX*REAL_X,F(p["x_center"])+RX*REAL_X)))
                        for p in panels],panel_sha256=[sha256(r).hexdigest() for r in raw],slabs=slabs)
    path=HERE.parent/"data"/f"wide-{index:02d}-certificate.json"
    path.write_text(json.dumps(data,indent=2)+"\n")
    print("verified",index,cb.pos(d.error),flush=True)
    return data


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("panels",type=int,nargs="*")
    parser.add_argument("--subdivisions",type=int,default=SUBDIVISIONS)
    parser.add_argument("--workers",type=int,default=4)
    args=parser.parse_args()
    panels=args.panels or list(range(len(Q_CENTERS)))
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        list(pool.map(panel_proof,panels,[args.subdivisions]*len(panels)))
