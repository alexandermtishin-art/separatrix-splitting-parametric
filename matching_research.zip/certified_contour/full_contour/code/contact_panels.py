"""Two-control polydisks near the three non-equivalent contact candidates."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
from pathlib import Path
import json
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/"contour/code"))
import run_two_controls as base
from continue_branches import BINARY_PAD, pos
from verify_charts import ONE, point
from wide_launch import cb, fast_linear

# Proposed centers only. Proof uses interval tests independent of these seeds.
CONTACTS={
    "phase-positive": (".247418021",".85542915029090",".000007867680607","-.596653",".153346"),
    "amplitude-lower": (".226180318",".855422223908029","0","-.721652",".278348"),
    "amplitude-upper": (".270855828",".855436076757126","0","-.471655",".028345"),
}
RHO_RADIUS,PHI_RADIUS=F("4e-10"),F("4e-10")
X_RADIUS=F(".005")
CASE={"eps":"0.2","detuning":"0","launch":"1e-12","span":"2"}


def run_job(job):
    name,arc,workers=job
    _,rho,phi,x,y=map(F,CONTACTS[name])
    s=1 if arc==0 else -1
    center=(rho,s*phi)
    slopes=(RHO_RADIUS,s*PHI_RADIUS)
    x0=(x,y)[arc]
    periods=(86,91)[arc]
    base.RX=X_RADIUS
    if name!="phase-positive":
        cb.linear_data=base.linear_data=fast_linear
    # The graph centers with positive launch coordinate are still below .5.
    # The corresponding uniform launch bound uses hi, not sqrt(hi).
    h,linear=base.coefficients(center,slopes)
    with ProcessPoolExecutor(max_workers=workers) as pool:
        start,error=base.launch_model(CASE,center,slopes,x0,periods,pool)
    print("launch",name,arc,pos(error),flush=True)
    msg=f"{base.X} {base.V} {periods-base.SKIP}\n"+" ".join(h+[pos(error)]+linear+start)+"\n"
    exe=ROOT/"contour/build/transport_two_controls"
    proc=subprocess.run([exe],input=msg,text=True,check=True,capture_output=True)
    lines=proc.stdout.splitlines()
    e,df=lines[0].split()
    result=dict(arc=arc,x_center=str(x0),x_radius=str(X_RADIUS),x_degree=base.X,
                control_degree=base.V,center=[str(rho),str(phi)],
                scale=list(map(str,(RHO_RADIUS,PHI_RADIUS))),
                end_error=pos(point(e)*(ONE+BINARY_PAD)),defect=df,
                coefficients=[row.split() for row in lines[1:]])
    print("integrated",name,arc,result["end_error"],flush=True)
    (HERE.parent/"data"/f"{name}-{arc}.json").write_text(json.dumps(result,indent=2)+"\n")


if __name__=="__main__":
    cli=argparse.ArgumentParser()
    cli.add_argument("name",choices=list(CONTACTS))
    cli.add_argument("--workers",type=int,default=4)
    args=cli.parse_args()
    with ProcessPoolExecutor(max_workers=2) as pool:
        list(pool.map(run_job,[(args.name,arc,args.workers) for arc in (0,1)]))
