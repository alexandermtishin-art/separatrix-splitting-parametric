"""Interval enclosure and transverse two-control unfolding of cubic contacts."""
from fractions import Fraction as F
from hashlib import sha256
from math import factorial
import argparse
import json
from pathlib import Path

from contact_panels import HERE, CONTACTS, RHO_RADIUS, PHI_RADIUS
import verify_two_controls as tm
from continue_branches import approximant, pos
from verify_charts import ZERO, ONE, point

RQ=F(".00043")
DOMAIN=(F(".00000045")/RQ,F(".5"),F(".5"))
ORDERS=((0,0,0),(1,0,0),(2,0,0))
DIRS=((1,0,0),(0,1,0),(0,0,1))


def cauchy(error, order, box):
    for n,x in zip(order,box):
        if n:
            error*=factorial(n)/(ONE-abs(x).b)**n
    return error.b


def derivative(d, order, box):
    return tm.evaluate(d.p,box,order)+cauchy(d.error,order,box)*tm.UNIT


def shift(order,direction):
    return tuple(a+b for a,b in zip(order,direction))


def jet(d, order):
    p={}
    for powers,a in d.p.items():
        if all(i>=n for i,n in zip(powers,order)):
            for i,n in zip(powers,order):
                a*=factorial(i)//factorial(i-n)
            p[tuple(i-n for i,n in zip(powers,order))]=a
    return p


def inverse3(a):
    from mpmath import mp
    from continue_branches import midpoint, decimal
    m=mp.inverse(mp.matrix([[midpoint(y) for y in row] for row in a]))
    return [[point(decimal(m[i,j])) for j in range(3)] for i in range(3)]


def certify(name,panels):
    q0,rho,phi,*_=map(F,CONTACTS[name])
    tm.Q0,tm.RQ=q0,RQ
    for i,p in enumerate(panels):
        assert p["arc"]==i and tuple(map(F,p["center"]))==(rho,phi)
        assert tuple(map(F,p["scale"]))==(RHO_RADIUS,PHI_RADIUS)
    graphs=[tm.chart(p) for p in panels]
    d=graphs[0][0]+graphs[1][0]
    zero=(ZERO,)*3
    box=tuple(point(s)*tm.UNIT for s in DOMAIN)
    j=[[tm.evaluate(d.p,zero,shift(order,direction))*point(s)
        for direction,s in zip(DIRS,DOMAIN)] for order in ORDERS]
    inv=inverse3(j)
    models=[]
    for row in inv:
        out={}
        for value,order in zip(row,ORDERS):
            for key,coeff in jet(d,order).items():
                out[key]=out.get(key,ZERO)+value*coeff
        models.append(out)
    contraction=ZERO
    correction=ZERO
    for i,(row,poly) in enumerate(zip(inv,models)):
        measure=ZERO
        for k,(direction,s) in enumerate(zip(DIRS,DOMAIN)):
            err=sum((abs(a)*cauchy(d.error,shift(order,direction),box)
                     for a,order in zip(row,ORDERS)),ZERO)
            ji=(tm.evaluate(poly,box,direction)+err*tm.UNIT)*point(s)
            measure+=abs(point(int(i==k))-ji)
        contraction=max(contraction,measure.b)
        err=sum((abs(a)*cauchy(d.error,order,zero) for a,order in zip(row,ORDERS)),ZERO)
        correction=max(correction,(abs(tm.evaluate(poly,zero))+err).b)
    assert (contraction+correction).b<1,(name,contraction,correction,d.error)
    small=(correction/(ONE-contraction)).b
    box=tuple(x*small for x in box)
    a,b=derivative(d,(0,1,0),box),derivative(d,(0,0,1),box)
    c,e=derivative(d,(1,1,0),box),derivative(d,(1,0,1),box)
    det=(a*e-b*c)/point(RQ*RHO_RADIUS*PHI_RADIUS)
    cubic=derivative(d,(3,0,0),box)/point(RQ**3)
    assert det.a>0 and (cubic.a>0 or cubic.b<0),(name,det,cubic)
    coordinates=[point(x)+b0*point(s) for x,b0,s in zip((q0,rho,phi),box,(RQ,RHO_RADIUS,PHI_RADIUS))]
    return dict(contact=name,graph_errors=[r[1] for r in graphs],
                q=str(coordinates[0]),rho=str(coordinates[1]),phi=str(coordinates[2]),
                control_jacobian=str(det),dqqq=str(cubic),
                contraction=pos(contraction),correction=pos(correction))


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("name",choices=CONTACTS)
    args=parser.parse_args()
    paths=[HERE.parent/"data"/f"{args.name}-{i}.json" for i in (0,1)]
    raw=[p.read_bytes() for p in paths]
    result=certify(args.name,list(map(json.loads,raw)))
    result["panel_sha256"]=[sha256(x).hexdigest() for x in raw]
    out=json.dumps(result,indent=2)+"\n"
    (HERE.parent/"data"/f"{args.name}-certificate.json").write_text(out)
    print(out,end="")
