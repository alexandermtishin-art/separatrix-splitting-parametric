#pragma once

#include <quadmath.h>
#include <cmath>
#include <limits>

struct Twofold {
    double hi, lo;
    constexpr Twofold(double h=0, double l=0):hi(h),lo(l){}
    static Twofold from_quad(__float128 q){const double h=static_cast<double>(q);return {h,static_cast<double>(q-h)};}
    __float128 binary128() const { return static_cast<__float128>(hi)+lo; }

    static Twofold sum(double a,double b) {
        const double s=a+b;
        const double v=s-a;
        return {s,(a-(s-v))+(b-v)};
    }
    friend Twofold operator-(Twofold a) { return {-a.hi,-a.lo}; }
    friend Twofold operator+(Twofold a,Twofold b) {
        Twofold s=sum(a.hi,b.hi);
        return sum(s.hi,s.lo+(a.lo+b.lo));
    }
    friend Twofold operator-(Twofold a,Twofold b) {return a+(-b);}
    friend Twofold operator*(Twofold a,Twofold b) {
        const double p=a.hi*b.hi;
        double r=std::fma(a.hi,b.hi,-p);
        r=std::fma(a.hi,b.lo,r);
        r=std::fma(a.lo,b.hi,r);
        return sum(p,r);
    }
    friend Twofold operator/(Twofold a,Twofold b) {
        const double d=a.hi/b.hi;
        const Twofold r=a-b*Twofold(d);
        return sum(d,(r.hi+r.lo)/b.hi);
    }
    Twofold& operator+=(Twofold b){return *this=*this+b;}
    Twofold& operator-=(Twofold b){return *this=*this-b;}
    Twofold& operator*=(Twofold b){return *this=*this*b;}
    Twofold& operator/=(Twofold b){return *this=*this/b;}
    friend bool operator<(Twofold a,Twofold b){
        return a.hi<b.hi || (a.hi==b.hi && a.lo<b.lo);
    }
    friend bool operator>=(Twofold a,Twofold b){return !(a<b);}
};
inline Twofold fabsq(Twofold a){return a.hi<0 ? -a : a;}
inline Twofold fmaxq(Twofold a,Twofold b){return a<b ? b : a;}
inline Twofold sqrtq(Twofold a){return Twofold::from_quad(sqrtq(a.binary128()));}
inline bool finiteq(Twofold a){return std::isfinite(a.hi)&&std::isfinite(a.lo);}
