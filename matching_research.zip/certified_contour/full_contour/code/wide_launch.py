"""Reusable validated launches on a common rectangle of controls."""
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/"contour/code"))
import run_two_controls as base
import continue_branches as cb
from verify_charts import ZERO, ONE, point

CENTER=(F(".85542915029090"),F(0))
SCALES=(F(".000017"),F(".000019"))
OUTER=F(".015")
NODES=tuple(F(n,3) for n in (-12,-11,-9,-6,-2,2,6,9,11,12))
X,V=12,4
SKIP=67
CASE={"eps":"0.2","detuning":"0","launch":"1e-12","span":"2"}
SOLVER=ROOT/"contour/build/transport_two_controls"


def fixed_case(rho,phi):
    return {**CASE,"rho":str(rho),"phase":str(phi)}


def matrix_entry(s,error):
    return point(s)+cb.abs_distance(point(s),s)*base.iv.mpf([-1,1])+error*base.iv.mpf([-1,1])


def fast_linear(case):
    flow=cb.TaylorFlow(case)
    r=point("1e-14")
    columns=[]
    for n in (0,1):
        p=[[ZERO,r if i==n else ZERO] for i in (0,1)]
        p=[[cb.approximant(a) for a in row] for row in p]
        out,e,_=flow.evaluate(p,1,cb.abs_distance(r,"1e-14"))
        columns.append([matrix_entry(row[1],e)/r for row in out])
    a,c=columns[0]
    b,d=columns[1]
    tr=a+d
    lam=(tr+base.iv.sqrt(tr**2-4))/2
    slope=(lam-a)/b
    other=(ONE/lam-a)/b
    assert cb.inside(lam,cb.interval("1.36","1.38"))
    assert (abs(slope)+abs(other)).b<3
    assert ((ONE+abs(other))/abs(slope-other)).b<3
    assert ((ONE+abs(slope))/abs(slope-other)).b<3
    return lam,slope,[[a,b],[c,d]]


def wide_monodromy():
    base.V=4
    h,linear=base.coefficients(CENTER,(OUTER,OUTER))
    out=[]
    for j in (0,1):
        rows=[["0"]*30 for _ in range(2)]
        rows[j][1]="1e-14"
        msg="1 4 1\n"+" ".join(h+[cb.pos(cb.abs_distance(point("1e-14"),"1e-14"))]+linear+rows[0]+rows[1])+"\n"
        proc=subprocess.run([SOLVER],input=msg,text=True,check=True,capture_output=True)
        header,a,b=proc.stdout.splitlines()
        err=point(header.split()[0]).b*(ONE+cb.BINARY_PAD)
        out.append([([matrix_entry(s,ZERO)/point("1e-14") for s in row.split()[1::2]],err/point("1e-14")) for row in (a,b)])
    return out


def prove_wide_disk():
    cols=wide_monodromy()
    a,c=cols[0]
    b,d=cols[1]
    # Each bound is uniform on the physical complex bidisk of radius OUTER.
    central=fast_linear(fixed_case(*CENTER))
    lam,nu,A=central
    t=A[0][0]+A[1][1]
    root=2*lam-t
    def vary(entry,value):
        coeff,error=entry
        return abs(coeff[0]-value)+sum(map(abs,coeff[1:]),ZERO)+error
    dv=[[vary(a,A[0][0]),vary(b,A[0][1])],
        [vary(c,A[1][0]),vary(d,A[1][1])]]
    dt=dv[0][0]+dv[1][1]
    disc=2*abs(t)*dt+dt**2
    assert disc.b<(root**2).a
    dl=(dt+disc/root)/2
    lo,hi=(lam-dl).a,(lam+dl).b
    s=(ONE/lam-A[0][0])/A[0][1]
    db=dv[0][1]
    ds=(dl+dv[0][0]+abs(nu)*db)/(abs(A[0][1])-db)
    ds0=(dl/(lam*lo)+dv[0][0]+abs(s)*db)/(abs(A[0][1])-db)
    assert (abs(s)+abs(nu)+ds+ds0).b<3
    sep=(abs(s-nu)-ds-ds0).a
    assert sep>0 and lo>1 and (abs(A[0][1])-db).a>0
    assert ((ONE+abs(s)+ds0)/sep).b<3 and ((ONE+abs(nu)+ds)/sep).b<3
    assert (abs(ONE+nu**2)-(2*abs(nu)+ds)*ds).a>1
    assert (point(".3")+point(CENTER[0])*point(".1")*base.iv.sqrt(2)
            +base.matrix_change(CENTER,(OUTER,OUTER),1)).b<point(".43").a
    assert (cb.K/lo**2+cb.GROWTH*(1+cb.K*cb.R**2)**3/lo**3).b<cb.K
    pre=cb.R/lo*(1+cb.K*(cb.R/lo)**2)
    assert pre.b<point(".003").a
    assert (ONE/lo**2+cb.SLOPE_GROWTH*pre**2/lo**3).b<point(".70").a
    # This launch estimate applies for -1 <= Re x <= .5, |Im x| <= .08.
    launch=point(CASE["launch"])*hi**(SKIP+1)*base.iv.exp(point(".16")*dl/lo)
    assert launch.b<cb.R.a
    assert (6*launch*(1+cb.K*launch**2)).b<point(".012").a
    print("wide monodromy",cb.pos(dl),cb.pos(launch),flush=True)


def chart_job(nodes):
    v,w=nodes
    case=fixed_case(CENTER[0]+SCALES[0]*v,CENTER[1]+SCALES[1]*w)
    cb.linear_data=fast_linear
    c=cb.local_chart(case)
    # Compose needs only these fields, which avoid serializing the flow object.
    return {**{k:c[k]._mpi_ for k in ("lambda","slope","chart_error")},
            "poly":[[z._mpi_ for z in row] for row in c["poly"]]}


def produce(path,workers):
    prove_wide_disk()
    with ProcessPoolExecutor(max_workers=workers) as pool:
        charts=list(pool.map(chart_job,product(NODES,repeat=2)))
    path.write_text(json.dumps(charts)+"\n")
    print("validated launch samples",len(charts),flush=True)


if __name__=="__main__":
    produce(HERE.parent/"build/wide_launch_cache.json",7)
