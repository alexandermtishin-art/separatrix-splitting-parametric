"""Enclose one exact iterate of -P from a proposed manifold-intersection box."""
import argparse
from fractions import Fraction
import json
from pathlib import Path

from mpmath import iv
from verify_charts import ZERO, interval, inside, point, poly_value, proof, span


def coefficient_product(a, b, k):
    return sum((a[j]*b[k-j] for j in range(k+1)), ZERO)


class Flow:
    def __init__(self, case, steps=48, order=22, linear_only=False):
        self.a = point(case["eps"])/2
        self.b = point(case["rho"])*self.a
        self.w = 1+point(case["detuning"])
        self.phase = point(case["phase"])
        self.steps, self.order = steps, order
        self.h = iv.pi/steps
        self.linear_only = linear_only

    def linear(self, time):
        c, s = iv.cos(2*time), iv.sin(2*time)
        cp, sp = iv.cos(2*time+self.phase), iv.sin(2*time+self.phase)
        b11, b22 = -self.a*s+self.b*sp, self.a*s-self.b*sp
        return (b11, self.w+self.a*c-self.b*cp,
                -self.w-3*self.a*c-self.b*cp, b22)

    def field(self, x, time):
        q, p = x
        l11, l12, l21, l22 = self.linear(time)
        n = ZERO if self.linear_only else (q**2+p**2)/2
        return l11*q+(l12-n)*p, (l21+n)*q+l22*p

    def trajectory_box(self, x, time):
        hspan = span(ZERO, self.h)
        box = list(x)
        for _ in range(24):
            reach = [u+hspan*v for u, v in zip(x, self.field(box, time))]
            if all(inside(a, b) for a, b in zip(reach, box)):
                return box
            enlarged = [span(a, b) for a, b in zip(box, reach)]
            box = [a + (a.b-a.a)/8 * interval(-1, 1) for a in enlarged]
        raise ArithmeticError("Could not verify the step enclosure")

    def jets(self, x, t, degree):
        c, s = [iv.cos(2*t)], [iv.sin(2*t)]
        cp, sp = [iv.cos(2*t+self.phase)], [iv.sin(2*t+self.phase)]
        for k in range(degree-1):
            c.append(-2*s[k]/(k+1))
            s.append(2*c[k]/(k+1))
            cp.append(-2*sp[k]/(k+1))
            sp.append(2*cp[k]/(k+1))
        l11 = [-self.a*x+self.b*y for x, y in zip(s, sp)]
        l12 = [self.a*x-self.b*y for x, y in zip(c, cp)]
        l21 = [-3*self.a*x-self.b*y for x, y in zip(c, cp)]
        l22 = [-x for x in l11]
        l12[0] += self.w
        l21[0] -= self.w
        q, p, n = [x[0]], [x[1]], []
        for k in range(degree):
            if self.linear_only:
                cubic_q = cubic_p = ZERO
            else:
                n.append((coefficient_product(q, q, k)+coefficient_product(p, p, k))/2)
                cubic_q = coefficient_product(n, q, k)
                cubic_p = coefficient_product(n, p, k)
            q.append((coefficient_product(l11, q, k)+coefficient_product(l12, p, k)
                      -cubic_p)/(k+1))
            p.append((coefficient_product(l21, q, k)+coefficient_product(l22, p, k)
                      +cubic_q)/(k+1))
        return q, p

    def iterate(self, x):
        for k in range(self.steps):
            t = self.h*k
            time = span(t, self.h*(k+1))
            box = self.trajectory_box(x, time)
            center = self.jets(x, t, self.order)
            remainder = self.jets(box, time, self.order+1)
            x = [poly_value(a+[b[-1]], self.h) for a, b in zip(center, remainder)]
        return [-v for v in x]


def outward_decimals(value):
    # Bounds printed at a fixed decimal scale, rounded out.
    factor = 10**16
    endpoints = [mpf_tuple for mpf_tuple in (value*factor)._mpi_]
    result = []
    for k, (sign, man, exponent, _) in enumerate(endpoints):
        exact = Fraction((-1)**sign*man) * Fraction(2)**exponent
        result.append(str(Fraction((exact.numerator//exact.denominator) if not k
                                   else -(-exact.numerator//exact.denominator), factor)))
    return result


def pair(case, gap, boxes):
    source = next(Fraction(q) for q in case["roots"] if Fraction(q) > Fraction("0.20"))
    mid = Fraction(round(source*10**8), 10**8)
    radius = Fraction("0.000003")
    start = mid-radius, mid+radius
    gap_budget, graph_budget = point("3e-14"), point("2e-14")
    assert gap.at(start[0]).a > gap_budget
    assert gap.at(start[1]).b < -gap_budget
    outgoing = gap.arcs[0]
    initial_p = poly_value(outgoing.p.coefficients,
                           span(outgoing.inverse(start[0]), outgoing.inverse(start[1])))
    initial_p += graph_budget*interval(-1, 1)
    image = Flow(case).iterate((interval(*start), initial_p))
    candidates = [i for i, b in enumerate(boxes) if inside(image[0], interval(*b))]
    assert len(candidates) == 1, (image, candidates)
    return {
        "strict_gap_error_budget_for_source_box": "3e-14",
        "outgoing_graph_p_error_budget": "2e-14",
        "source_q_box": [str(x) for x in start],
        "source_p_box": outward_decimals(initial_p),
        "minus_strobe_q_enclosure": outward_decimals(image[0]),
        "minus_strobe_p_enclosure": outward_decimals(image[1]),
        "image_root_box_index_zero_based": candidates[0],
        "claim_scope": "Rigorous map enclosure for initial box. Transfer to manifold pairing needs verified graph errors and branch identification.",
    }


if __name__ == "__main__":
    args = argparse.ArgumentParser()
    args.add_argument("input", type=Path)
    args.add_argument("--output", type=Path)
    config = args.parse_args()
    case = json.loads(config.input.read_text())
    gap, boxes, result = proof(case)
    result["map"] = pair(case, gap, boxes)
    output = json.dumps(result, indent=2) + "\n"
    if config.output:
        config.output.write_text(output)
    print(output, end="")
