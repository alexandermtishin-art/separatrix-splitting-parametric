"""Validate a local polynomial chart, then propagate complex parameter disks."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
import json
from math import factorial
from pathlib import Path
import subprocess

from mpmath import iv, mp
from verify_charts import point, interval, inside, ZERO, ONE, Polynomial
from verify_pairing import Flow


M, T = 24, 24
R = point(".002")
K = 35000
GROWTH = 20000
SLOPE_GROWTH = 60000
BINARY_PAD = point("1e-32")
ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "build" / "transport_polynomial"


def up(x):
    return x.b if hasattr(x, "b") else point(x).b


def midpoint(x):
    return mp.make_mpf(x.mid._mpi_[0])


def decimal(x):
    return mp.nstr(x, 47, min_fixed=0, max_fixed=0)


def pos(x):
    # Positive upper bound rounded comfortably above the interval endpoint.
    return decimal(mp.make_mpf(up(x)._mpi_[1])*(1+mp.mpf("1e-31"))+mp.mpf("1e-1000"))


def symmetric_enclosure(x):
    return max(abs(x).b, ZERO)


def approximant(x):
    return decimal(midpoint(x))


def abs_distance(value, center):
    # Decimal input -> nearest binary128.  The binary unit roundoff is below
    # the allowance used here, including the case of nonzero small values.
    c = point(center)
    return abs(value-c)+BINARY_PAD*abs(c)


class TaylorFlow:
    def __init__(self, case):
        h = iv.pi/M
        ep, rho, phase, det = (point(case[k]) for k in ("eps", "rho", "phase", "detuning"))
        a, b = ep/2, ep*rho/2
        coeff = []
        bounds = []
        for j in range(M):
            t0 = j*h
            c, s = iv.cos(2*t0), iv.sin(2*t0)
            cp, sp = iv.cos(4*t0+phase), iv.sin(4*t0+phase)
            errors = []
            for k in range(T+1):
                delta = det if k == 0 else ZERO
                m = h*b*sp
                out = [m, h*(delta+ep*c-b*cp-(a if k == 0 else ZERO)),
                       h*(-delta-ep*c-b*cp-(a if k == 0 else ZERO)), -m]
                numbers = [approximant(x) for x in out]
                coeff.extend(numbers)
                e = [abs_distance(x,y) for x,y in zip(out,numbers)]
                errors.append(max(up(e[0]+e[1]),up(e[2]+e[3])))
                c,s = -2*h*s/(k+1),2*h*c/(k+1)
                cp,sp = -4*h*sp/(k+1),4*h*cp/(k+1)
            # Time Taylor remainders for cos/sin on a real step of length h.
            tail = h*(ep*(2*h)**(T+1)+2*abs(b)*(4*h)**(T+1))/factorial(T+1)
            bounds.append(up(sum(errors,ZERO)+tail))
        self.h=approximant(h)
        self.header = " ".join([self.h,pos(abs_distance(h,self.h)),pos(max(bounds)),
                               pos(a+abs(b))])
        self.coefficients = " ".join(coeff)

    def evaluate(self, p, periods, error=ZERO, rigorous=True):
        degree=len(p[0])-1
        strings = [[v if isinstance(v,str) else decimal(v) for v in row] for row in p]
        msg=f"{degree} {periods} {int(rigorous)} {self.header} {pos(error)}\n"
        msg+=self.coefficients+"\n"+" ".join(s for row in strings for s in row)+"\n"
        output=subprocess.run([str(EXE)],input=msg,text=True,check=True,capture_output=True).stdout.splitlines()
        bound,defect=output[0].split()
        return [x.split() for x in output[1:]], (point(bound)*(1+BINARY_PAD)).b, (point(defect)*(1+BINARY_PAD)).b


def linear_data(case):
    f=Flow(case,steps=48,order=34,linear_only=True)
    a,c=f.iterate((ONE,ZERO))
    b,d=f.iterate((ZERO,ONE))
    tr=a+d
    determinant=a*d-b*c
    assert determinant.a<=1<=determinant.b
    root=iv.sqrt(tr**2-4*determinant)
    lam,stable=(tr+root)/2,(tr-root)/2
    slope,v=(lam-a)/b,(stable-a)/b
    assert inside(lam,interval("1.36","1.38"))
    assert (abs(slope)+abs(v)).b < 3
    assert ((abs(v)+1)/abs(v-slope)).b < 3
    assert ((abs(slope)+1)/abs(v-slope)).b < 3
    # Exact determinant one follows from the trace-zero variational system.
    return lam,slope,[[a,b],[c,d]]


def local_chart(case, degree=17):
    lam, slope, A=linear_data(case)
    mid=midpoint(lam)
    mat=mp.matrix([[midpoint(x) for x in row] for row in A])
    flow=TaylorFlow(case)
    r=midpoint(R)
    poly=[[r]+[mp.mpf(0)]*degree,[r*midpoint(slope)]+[mp.mpf(0)]*degree]
    for row in poly:
        row[0],row[1]=row[1],row[0]
    # Triangular Newton in polynomial degree. The approximate solves only
    # propose coefficients. A separate disk defect validates the result.
    for _ in range((degree-1)//2+1):
        initial=[[v/mid**j for j,v in enumerate(row)] for row in poly]
        out,_,_=flow.evaluate(initial,1,rigorous=False)
        for j in range(3,degree+1,2):
            update=mp.lu_solve(mp.eye(2)-mat/mid**j,
                mp.matrix([mp.mpf(out[k][j])-poly[k][j] for k in (0,1)]))
            for k in (0,1):
                poly[k][j]+=update[k]
    result=[[decimal(v) for v in row] for row in poly]
    exact=[[point(v) for v in row] for row in result]
    exact[0][1],exact[1][1]=R,R*slope
    initial=[[value/lam**j for j,value in enumerate(row)] for row in exact]
    string=[[approximant(v) for v in row] for row in initial]
    startup=sum((abs_distance(v,s) for row,txt in zip(initial,string) for v,s in zip(row,txt)),ZERO)
    out,err,defect=flow.evaluate(string,1,startup)
    defect=max(up(sum((abs_distance(v,o) for o,v in zip(row,ref)),ZERO))
               for row,ref in zip(out,exact))+err

    # In rotating coordinates ||A(t)||_inf < .43. On an adapted ball of
    # radius .003 the trajectory is bounded by 12 times the initial adapted
    # radius; the corresponding variational norm in rotating coordinates
    # is bounded by 4. Duhamel gives the two cubic/derivative constants.
    assert (point(".3")+point(case["rho"])*point(".1")*iv.sqrt(2)).b<point(".43").a
    assert iv.exp(point(".434")*iv.pi).b<4
    assert (point(".43")+3*point(".036")**2).b<point(".434").a
    assert (iv.pi*4**3*3**4).b<GROWTH
    assert (iv.pi*4**3*3**5).b<SLOPE_GROWTH
    assert (3*max(up(sum((abs(v) for v in row[2:]),ZERO)) for row in exact)).b < (K*R**3).a
    assert (K/lam**2+GROWTH*(1+K*R**2)**3/lam**3).b<(point(K)).a
    local_r=R/lam*(1+K*(R/lam)**2)
    assert local_r.b<point(".003").a
    contraction=(1/lam**2+SLOPE_GROWTH*local_r**2/lam**3).b
    assert contraction < point(".70").a
    error=(15*defect/(1-contraction)).b
    assert error<point("1e-20").a,(error,defect)
    return {
        "lambda":lam,"slope":slope,"flow":flow,"poly":exact,
        "chart_error":error,"contraction":contraction,"map_defect":defect,
    }


def compose(chart, center, radius, span, launch, periods, degree, fixed_skip=None):
    lam,slope=chart["lambda"],chart["slope"]
    loglam=iv.ln(lam)
    scale=point(launch)/iv.sqrt(1+slope**2)
    skip=(int(mp.floor(mp.log(mp.mpf(".00060")/midpoint(scale))/midpoint(loglam)))
          if fixed_skip is None else fixed_skip)
    assert 0<skip<periods
    base=scale*iv.exp(loglam*(skip+span*point(center)))/R
    width=loglam*span*point(radius)
    maximum=base*iv.exp(abs(width))
    assert maximum.b<1
    coefficients=[]
    error=chart["chart_error"]*maximum**3
    for row in chart["poly"]:
        factors=[v*base**j for j,v in enumerate(row)]
        p=[sum((v*(j*width)**k for j,v in enumerate(factors)),ZERO)/factorial(k)
           for k in range(degree+1)]
        strings=[approximant(v) for v in p]
        coefficients.append(strings)
        error+=sum((abs_distance(v,s) for v,s in zip(p,strings)),ZERO)
        error+=sum((abs(v)*iv.exp(j*abs(width))*(j*abs(width))**(degree+1)/factorial(degree+1)
                    for j,v in enumerate(factors)),ZERO)
    return coefficients,periods-skip,error


def reexpress(poly, center, radius):
    # Archived polynomials are exact finite decimals.
    c,r=point(center),point(radius)
    from math import comb
    return [sum((v*comb(j,k)*c**(j-k) for j,v in enumerate(poly.coefficients) if j>=k),ZERO)*r**k
            for k in range(len(poly.coefficients))]


@lru_cache
def prepare(path,arc):
    raw=Path(path).read_bytes()
    case=json.loads(raw)
    local=local_chart(case if arc==0 else {**case,"phase":"-"+case["phase"]})
    archived=[Polynomial(data) for data in case["interpolation_coefficients"][str(arc)]]
    return case,local,archived,sha256(raw).hexdigest()


def run_panel(job):
    path,arc,center,radius,degree=job
    case,chart,archived,digest=prepare(path,arc)
    initial,periods,e0=compose(chart,center,radius,point(case["span"]),case["launch"],case["periods"][arc],degree)
    out,error,defect=chart["flow"].evaluate(initial,periods,e0)
    errors=[]
    for row,poly in zip(out,archived):
        reference=reexpress(poly,center,radius)
        # The printed binary128 coefficients are contained within this bound
        # (39 decimal digits; the printing error is much smaller than 1e-32).
        p=[point(o)+abs(point(o))*BINARY_PAD*interval(-1,1) for o in row]
        discrepancy=sum((abs(x-y) for x,y in zip(p,reference)),ZERO)+sum((abs(x) for x in reference[len(p):]),ZERO)
        errors.append((discrepancy+error).b)
    result={
        "case_sha256":digest,
        "arc":arc,"center":str(center),"complex_radius":str(radius),
        "degree":degree,"propagated_periods":periods,
        "local_chart_error":pos(chart["chart_error"]),
        "launch_error":pos(e0),"propagation_error":pos(error),
        "maximum_step_defect":pos(defect),
        "archived_q_error":pos(errors[0]),"archived_p_error":pos(errors[1]),
        "archived_q_derivative_error_on_half_disk":pos(2*errors[0]/point(radius)),
        "archived_p_derivative_error_on_half_disk":pos(2*errors[1]/point(radius)),
    }
    return result


if __name__=="__main__":
    cli=argparse.ArgumentParser()
    cli.add_argument("input",type=Path)
    cli.add_argument("--pilot",action="store_true")
    cli.add_argument("--local-only",action="store_true")
    cli.add_argument("--degree",type=int,default=14)
    cli.add_argument("--workers",type=int,default=8)
    cli.add_argument("--output",type=Path)
    args=cli.parse_args()
    path=str(args.input.resolve())
    if args.local_only:
        for arc in (0,1):
            _,chart,_,_=prepare(path,arc)
            print(arc,pos(chart["chart_error"]),pos(chart["map_defect"]),pos(chart["contraction"]),flush=True)
        raise SystemExit
    jobs=[]
    for arc in (0,1):
        if args.pilot:
            centers=[Fraction("-.65"),Fraction(".0")]
        else:
            # Cover the x region containing the inverses of q=[.20,.35]
            # and the source/image parameters. Real half-width .025.
            centers=[Fraction(i,40) for i in (
                range(-35,-4,2) if arc==0 else range(-13,20,2)
            )]
        for center in centers:
            jobs.append((path,arc,center,Fraction(".05"),args.degree))
    results=[]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for r in pool.map(run_panel,jobs):
            print(json.dumps(r),flush=True)
            results.append(r)
    if args.output:
        args.output.write_text(json.dumps(results,indent=2)+"\n")
