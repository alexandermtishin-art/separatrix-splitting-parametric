"""Interval proof for archived polynomial graph gaps, with a conditional flow check.

Input coefficient decimals define exact polynomials. No assumption is made here
that the original invariant manifolds satisfy the printed graph error budgets.
"""
import argparse
from fractions import Fraction
import json
from math import comb
from pathlib import Path

from mpmath import iv, mp


if not __debug__:
    raise RuntimeError("Run the verifier with assertions enabled")

iv.dps = 68
mp.dps = 64
ZERO = iv.mpf(0)
ONE = iv.mpf(1)
UNIT = iv.mpf([0, 1])
DEGREE = 6


def point(value):
    return iv.mpf(str(value))


def interval(left, right):
    return iv.mpf([point(left).a, point(right).b])


def exact_coefficient(value):
    return iv.mpf(value.numerator) / value.denominator


def span(a, b):
    return iv.mpf([min(a.a, b.a), max(a.b, b.b)])


def inside(a, b):
    return a.a > b.a and a.b < b.b


def lower_text(x):
    return str(x.a)


def interval_text(x):
    return [str(x.a), str(x.b)]


def poly_value(poly, x):
    value = poly[-1]
    for coefficient in reversed(poly[:-1]):
        value = value * x + coefficient
    return value


def polynomial(chebyshev):
    # The conversion itself is exact, including the finite decimal inputs.
    t0, t1 = [1], [0, 1]
    powers = [Fraction(0)] * len(chebyshev)
    for index, value in enumerate(map(Fraction, chebyshev)):
        for j, entry in enumerate(t0):
            powers[j] += value * entry
        if index < len(chebyshev) - 1:
            t2 = [0] + [2 * c for c in t1]
            for j, entry in enumerate(t0):
                t2[j] -= entry
            t0, t1 = t1, t2
    return powers


def convolution(a, b, length):
    out = [ZERO] * length
    for i, value in enumerate(a[:length]):
        for j, coefficient in enumerate(b[:length-i]):
            out[i+j] = out[i+j] + value * coefficient
    return out


class Polynomial:
    def __init__(self, data):
        powers = polynomial(data)
        self.point_coefficients = [mp.mpf(v.numerator) / v.denominator for v in powers]
        self.coefficients = [exact_coefficient(v) for v in powers]
        self.jets = [
            [exact_coefficient(comb(j, k) * powers[j]) for j in range(k, len(powers))]
            for k in range(DEGREE+2)
        ]

    def bounds(self, x, count):
        return [poly_value(p, x) for p in self.jets[:count]]


class Graph:
    def __init__(self, data):
        self.q, self.p = [Polynomial(d) for d in data]
        self.inverses = {}
        self.sign = 1 if poly_value(self.q.point_coefficients, 1) > poly_value(
            self.q.point_coefficients, -1) else -1
        for i in range(180):
            x = interval(Fraction(i-90, 100), Fraction(i-89, 100))
            assert (self.sign * poly_value(self.q.jets[1], x)).a > 0, (i, x)

    def inverse(self, q):
        if q in self.inverses:
            return self.inverses[q]
        v = mp.mpf(q.numerator) / q.denominator
        coeff = self.q.point_coefficients
        deriv = [j * y for j, y in enumerate(coeff)][1:]
        left, right = mp.mpf("-.9"), mp.mpf(".9")
        # An approximate inverse is just a proposal. The bracket below proves it.
        for _ in range(56):
            mid = (left + right)/2
            if self.sign * (poly_value(coeff, mid) - v) < 0:
                left = mid
            else:
                right = mid
        x = (left + right)/2
        for _ in range(4):
            x -= (poly_value(coeff, x) - v) / poly_value(deriv, x)
        width = mp.mpf("1e-47")
        left, right = [point(mp.nstr(k, 62)) for k in (x-width, x+width)]
        assert inside(span(left, right), interval("-.9", ".9")), q
        target = point(q)
        assert (self.sign * (poly_value(self.q.coefficients, left)-target)).b < 0, q
        assert (self.sign * (poly_value(self.q.coefficients, right)-target)).a > 0, q
        self.inverses[q] = span(left, right)
        return self.inverses[q]

    def jet(self, x, degree):
        q, p = self.q.bounds(x, degree+1), self.p.bounds(x, degree+1)
        assert (self.sign*q[1]).a > 0
        # Lagrange inversion for the coefficient of h**k in p(x(q+h)).
        # A(t)=(q(x+t)-q(x))/t. Its reciprocal has the recurrence below.
        inv = [ONE/q[1]]
        for k in range(1, degree):
            inv.append(-sum((q[j+1]*inv[k-j] for j in range(1, k+1)), ZERO)/q[1])
        power, result = [ONE], [p[0]]
        for k in range(1, degree+1):
            power = convolution(power, inv, degree)
            result.append(sum((j*p[j]*power[k-j] for j in range(1, k+1)), ZERO)/k)
        return result


class Gap:
    def __init__(self, case):
        self.arcs = [Graph(case["interpolation_coefficients"][str(i)]) for i in (0, 1)]

    def at(self, q):
        return sum((poly_value(g.p.coefficients, g.inverse(q)) for g in self.arcs), ZERO)

    def bounds(self, left, right, derivative):
        center = (left+right)/2
        jets = [
            g.jet(g.inverse(center), DEGREE) for g in self.arcs
        ]
        remainder = sum(
            (g.jet(span(g.inverse(left), g.inverse(right)), DEGREE+1)[-1] for g in self.arcs),
            ZERO,
        )
        series = [a+b for a, b in zip(*jets)] + [remainder]
        if derivative:
            series = [k * value for k, value in enumerate(series) if k]
        h = interval(left-center, right-center)
        return poly_value(series, h)


def cover(gap, left, right, derivative, tolerance, max_depth=16):
    result = gap.bounds(left, right, derivative)
    if result.a > tolerance:
        return 1, 1
    if result.b < -tolerance:
        return -1, 1
    assert max_depth, (left, right, derivative, result)
    mid = (left+right)/2
    first = cover(gap, left, mid, derivative, tolerance, max_depth-1)
    second = cover(gap, mid, right, derivative, tolerance, max_depth-1)
    assert first[0] == second[0], (left, right, derivative)
    return first[0], first[1]+second[1]


def proof(case, halfwidth=Fraction("0.0006"), gap_limit="1e-13", slope_limit="1e-9"):
    gap = Gap(case)
    domain = (Fraction("0.20"), Fraction("0.35"))
    gap_budget, slope_budget = point(gap_limit), point(slope_limit)
    roots = [Fraction(x) for x in case["roots"] if domain[0] < Fraction(x) < domain[1]]
    centers = [Fraction(round(r*10**5), 10**5) for r in roots]
    boxes = [(x-halfwidth, x+halfwidth) for x in centers]
    sections = list(zip([domain[0], *[b for _, b in boxes]], [*[a for a, _ in boxes], domain[1]]))
    complement = [cover(gap, a, b, False, gap_budget) for a, b in sections]
    slopes = [cover(gap, a, b, True, slope_budget) for a, b in boxes]
    for i, (a, b) in enumerate(boxes):
        signs = [complement[i][0], complement[i+1][0]]
        assert signs == [-slopes[i][0], slopes[i][0]]
        assert (signs[0]*gap.at(a)).a > gap_budget and (signs[1]*gap.at(b)).a > gap_budget
    return gap, boxes, {
        "parameters": {k: case[k] for k in ("eps", "rho", "phase", "detuning")},
        "chart": [str(q) for q in domain],
        "root_boxes": [[str(a), str(b)] for a, b in boxes],
        "simple_proxy_roots": len(boxes),
        "complement_signs": [n for n, _ in complement],
        "root_slope_signs": [n for n, _ in slopes],
        "minimum_absolute_proxy_gap_on_complement_strict": gap_limit,
        "minimum_absolute_proxy_slope_in_root_boxes_strict": slope_limit,
        "cells_complement": sum(k for _, k in complement),
        "cells_root_boxes": sum(k for _, k in slopes),
    }


if __name__ == "__main__":
    args = argparse.ArgumentParser()
    args.add_argument("input", type=Path)
    args.add_argument("--output", type=Path)
    config = args.parse_args()
    case = json.loads(config.input.read_text())
    _, _, result = proof(case)
    output = json.dumps(result, indent=2) + "\n"
    if config.output:
        config.output.write_text(output)
    print(output, end="")
