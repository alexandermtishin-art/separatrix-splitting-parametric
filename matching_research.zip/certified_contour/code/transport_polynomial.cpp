// Binary128 polynomial continuation with a posteriori defect bounds.
// Build with g++ -O3 -std=gnu++17 -ffp-contract=off transport_polynomial.cpp -lquadmath.
#include <quadmath.h>
#include <array>
#include <cassert>
#include <cfenv>
#include <iostream>
#include <string>
#include <vector>

using Q = __float128;
constexpr int T=24, M=24, DMAX=24;
using V=std::array<Q,DMAX+1>;
using Space=std::array<V,2>;
using Time=std::array<Space,T+1>;
using Linear=std::array<std::array<std::array<Q,4>,T+1>,M>;
constexpr Q pad=1e-25Q, arithmetic=1e-27Q;

Q norm(Q a,Q b) {
    const Q s=a*a+b*b;
    const Q result=sqrtq(s)*(1+pad);
    assert(finiteq(s) && result*result >= s*(1+pad));
    return result;
}
Q read() { std::string x; assert(bool(std::cin>>x)); return strtoflt128(x.c_str(),nullptr); }
void print(Q x) { char b[110]; quadmath_snprintf(b,sizeof(b),"%.39Qe",x); std::cout<<b; }

Q l1(const V& p,int d,int lo=0) {
    Q s=0;
    for(int i=lo;i<=d;++i) s+=fabsq(p[i]);
    return s;
}

struct Step { Space output; Q error; Q defect; };

Step step(const Space& input,int d,int k,Q h,Q h_error,Q a_error,Q sym,
          Q error,const Linear& coeff,bool rigorous) {
    Time x{}; x[0]=input;
    std::array<std::array<Q,2*DMAX+1>,T+1> density{};
    Q defect_q=0,defect_p=0;
    int end = rigorous ? T : T-1;
    for(int j=0;j<=end;++j) {
        const int nmax=rigorous ? 2*d : d;
        const int fmax=rigorous ? 3*d : d;
        for(int a=0;a<=j;++a) {
            const int b=j-a;
            for(int u=0;u<=d;++u) for(int v=0;v<=d && u+v<=nmax;++v)
                density[j][u+v]+=(x[a][0][u]*x[b][0][v]+x[a][1][u]*x[b][1][v])/2;
        }
        std::array<Q,3*DMAX+1> q{},p{};
        for(int a=0;a<=j;++a) {
            const int b=j-a;
            const auto& A=coeff[k][a];
            for(int w=0;w<=d;++w) {
                q[w]+=A[0]*x[b][0][w]+A[1]*x[b][1][w];
                p[w]+=A[2]*x[b][0][w]+A[3]*x[b][1][w];
            }
            for(int u=0;u<=nmax;++u) {
                const Q h_n=h*density[a][u];
                for(int v=0;v<=d && u+v<=fmax;++v) {
                    q[u+v]-=h_n*x[b][1][v];
                    p[u+v]+=h_n*x[b][0][v];
                }
            }
        }
        if(j<T) for(int w=0;w<=d;++w) {
            x[j+1][0][w]=q[w]/(j+1);
            x[j+1][1][w]=p[w]/(j+1);
        }
        if(rigorous) for(int w=(j<T?d+1:0);w<=3*d;++w) {
            defect_q+=fabsq(q[w]); defect_p+=fabsq(p[w]);
        }
    }
    Space output{};
    for(int j=0;j<=T;++j) for(int w=0;w<=d;++w) {
        output[0][w]+=x[j][0][w]; output[1][w]+=x[j][1][w];
    }
    if(!rigorous) return {output,0,0};
    std::array<Q,T+1> size{}, sizeA{};
    Q total=0, totalA=0, linear_tail=0, cubic_tail=0, center=0, variation=0;
    for(int j=0;j<=T;++j) {
        size[j]=fmaxq(l1(x[j][0],d),l1(x[j][1],d));
        const auto& A=coeff[k][j];
        sizeA[j]=fmaxq(fabsq(A[0])+fabsq(A[1]),fabsq(A[2])+fabsq(A[3]));
        total+=size[j]; totalA+=sizeA[j];
        center+=norm(x[j][0][0],x[j][1][0]);
        for(int w=1;w<=d;++w) variation+=norm(x[j][0][w],x[j][1][w]);
    }
    for(int a=0;a<=T;++a) for(int b=0;b<=T;++b) {
        if(a+b>T) linear_tail+=sizeA[a]*size[b];
        for(int c=std::max(0,T+1-a-b);c<=T;++c)
            cubic_tail+=size[a]*size[b]*size[c];
    }
    Q cubic=total*total*total;
    // Total allowance covers coefficient arithmetic and the end-of-step sum.
    // Each elementary expression is a sum/product of fewer than 10^6 terms
    // of bounded absolute majorant, with binary128 unit roundoff 2^-113.
    Q guard=arithmetic*(total+totalA*total+cubic)+1e-1000Q;
    Q defect=(defect_q+defect_p+2*(linear_tail+h*cubic_tail+a_error*total
                               +h_error*cubic+guard))*(1+pad);
    constexpr Q cap=1e-7Q;
    Q near=(variation+cap)*(1+pad);
    // Hermitian logarithmic norm of the cubic vector field on the tube
    // around the real w=0 polynomial trajectory.
    Q rate=((h+h_error)*(sym+center*center/2+1.5Q*(2*center+near)*near))*(1+pad);
    assert(rate<0.5Q);
    Q bound=((error+defect)/(1-rate))*(1+pad);
    assert(bound<cap && finiteq(bound));
    return {output,bound,defect};
}

int main() {
    static_assert(FLT128_MANT_DIG==113);
    assert(std::fegetround()==FE_TONEAREST);
    int degree,periods,rigorous;
    assert(bool(std::cin>>degree>>periods>>rigorous));
    assert(degree>0 && degree<=DMAX && periods>=1);
    Q h=read(), h_error=read(), a_error=read(), sym=read(), error=read();
    Linear A{};
    for(auto& time:A) for(auto& row:time) for(auto& value:row) value=read();
    Space x{};
    for(auto& p:x) for(int j=0;j<=degree;++j) p[j]=read();
    Q maxdefect=0;
    for(int n=0;n<periods;++n) for(int k=0;k<M;++k) {
        auto result=step(x,degree,k,h,h_error,a_error,sym,error,A,rigorous);
        x=result.output; error=result.error; maxdefect=fmaxq(maxdefect,result.defect);
    }
    print(error); std::cout<<" "; print(maxdefect); std::cout<<"\n";
    for(auto& p:x) {
        for(int j=0;j<=degree;++j) { print(p[j]); std::cout<<" "; }
        std::cout<<"\n";
    }
}
