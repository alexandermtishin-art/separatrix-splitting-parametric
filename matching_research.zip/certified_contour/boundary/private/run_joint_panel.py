"""Validated manifold disks in launch and diagonal-control coordinates."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
from hashlib import sha256
from math import factorial
from pathlib import Path
import json
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent.parent/"code"))

from mpmath import iv
from continue_branches import (
    T,M,R,K,GROWTH,SLOPE_GROWTH,BINARY_PAD,approximant,abs_distance,compose,
    linear_data,local_chart,pos,up,
)
from verify_charts import Gap,point,ZERO,ONE


def polynomial_product(a,b):
    out=[Fraction(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            out[i+j]+=x*y
    return out


def lagrange(nodes,i):
    out=[Fraction(1)]
    for j,x in enumerate(nodes):
        if i!=j:
            out=polynomial_product(out,[-x/(nodes[i]-x),1/(nodes[i]-x)])
    return out


def parameters(left,right,arc):
    rho0,phi0,rho1,phi1=(Fraction(r[k]) for r in (left,right) for k in ("rho","phase"))
    s=1 if arc==0 else -1
    center=((rho0+rho1)/2,s*(phi0+phi1)/2)
    slope=(rho1-rho0,s*(phi1-phi0))
    return center,slope


def case_at(case,center,slope,v):
    rho,phi=(a+b*v for a,b in zip(center,slope))
    return {**case,"rho":str(rho),"phase":str(phi)}


def matrix_change(center,slope,radius):
    b=abs(point(center[0]))/10
    db=abs(point(slope[0]))*radius/10
    ph=abs(point(slope[1]))*radius
    return (2*iv.exp(ph)*(db+b*ph)).b


def analytic_launch(case,center,slope,x0,rx,skip):
    # The exact Floquet eigenpair, local fixed point and launch are analytic
    # jointly in the small launch disk and the much larger control disk.
    rv=10000
    base=case_at(case,center,slope,0)
    lam,nu,A=linear_data(base)
    a,b=A[0]
    t=a+A[1][1]
    root=2*lam-t
    dd=matrix_change(center,slope,rv)
    A0=point(".3")+abs(point(center[0]))*point(".1")*iv.sqrt(2)
    assert (A0+dd).b<point(".43").a
    matrix=(iv.pi*iv.exp((A0+dd)*iv.pi)*dd).b
    dt=2*matrix
    disc=(2*abs(t)*dt+dt**2).b
    assert disc<(root**2).a and root.a>0
    dl=((dt+disc/root)/2).b
    lo=(lam-dl).a
    hi=(lam+dl).b
    assert lo>point("1.35").b and hi<point("1.38").a
    nu_s=(ONE/lam-a)/b
    assert abs(b).a>matrix
    shift=(dl+matrix+abs(nu)*matrix)/(abs(b)-matrix)
    shift_s=(dl/(lam*lo)+matrix+abs(nu_s)*matrix)/(abs(b)-matrix)
    assert (abs(nu)+abs(nu_s)+shift+shift_s).b<3
    separation=(abs(nu_s-nu)-shift-shift_s).a
    assert separation>0 and ((ONE+abs(nu)+shift)/separation).b<3
    assert ((ONE+abs(nu_s)+shift_s)/separation).b<3
    assert (abs(1+nu**2)-(2*abs(nu)+shift)*shift).a>1
    # The one-period nonlinear and derivative estimates are uniform in v.
    assert (K/lo**2+GROWTH*(1+K*R**2)**3/lo**3).b<K
    pre=R/lo*(1+K*(R/lo)**2)
    assert pre.b<point(".003").a
    assert (ONE/lo**2+SLOPE_GROWTH*pre**2/lo**3).b<point(".70").a
    assert -1<=x0-rx<x0+rx<=Fraction(".25") and 2*rx<=Fraction(".1")
    argument=dl/lo
    u=point(case["launch"])*hi**skip*iv.sqrt(hi)*iv.exp(point(".1")*argument)
    assert u.b<R.a
    assert (6*u*(ONE+K*u**2)).b<point(".012").a
    return rv


def launch_model(case,center,slope,x0,rx,periods,X,V,skip):
    rv=analytic_launch(case,center,slope,x0,rx,skip)
    nodes=[Fraction(i,3) for i in range(-3,4)]
    coeff=[[[ZERO]*(X+1) for _ in nodes] for _ in (0,1)]
    error=ZERO
    for i,v in enumerate(nodes):
        exact=case_at(case,center,slope,v)
        chart=local_chart(exact)
        candidate,n,e=compose(chart,x0,rx,point(case["span"]),case["launch"],periods,X,fixed_skip=skip)
        assert n==periods-skip
        ell=lagrange(nodes,i)
        error+=e*point(sum(map(abs,ell)))
        for c,row in enumerate(candidate):
            for j,m in enumerate(ell):
                for k,p in enumerate(row):
                    p0=point(p)
                    coeff[c][j][k]+=point(m)*p0
    error+=point(".012")*rv/(rv-1)*(point(2)/(rv-1))**len(nodes)
    text=[]
    for component in coeff:
        retained=[p for row in component[:V+1] for p in row]
        omitted=[p for row in component[V+1:] for p in row]
        strings=[approximant(p) for p in retained]
        error+=sum((abs(p) for p in omitted),ZERO)
        error+=sum((abs_distance(p,s) for p,s in zip(retained,strings)),ZERO)
        text.extend(strings)
    return text,error


def linear_coefficients(center,slope,degree):
    h=iv.pi/M
    a=point(".1")
    b,bp=[point(x)/10 for x in (center[0],slope[0])]
    ph,dph=map(point,(center[1],slope[1]))
    records=[]
    errors=[]
    for j in range(M):
        c=iv.cos(2*j*h)
        s=iv.sin(2*j*h)
        cp=[iv.cos(4*j*h+ph)]
        sp=[iv.sin(4*j*h+ph)]
        for k in range(degree):
            cp.append(-dph*sp[k]/(k+1))
            sp.append(dph*cp[k]/(k+1))
        for k in range(T+1):
            diag=[h*(b*sp[i]+(bp*sp[i-1] if i else ZERO)) for i in range(degree+1)]
            co=[h*(b*cp[i]+(bp*cp[i-1] if i else ZERO)) for i in range(degree+1)]
            anti=[-v for v in diag]
            upper=[-v for v in co]; lower=[-v for v in co]
            upper[0]+=h*(point(".2")*c-(a if k==0 else ZERO))
            lower[0]+=h*(-point(".2")*c-(a if k==0 else ZERO))
            for row in (diag,upper,lower,anti):
                strings=[approximant(x) for x in row]
                records.extend(strings)
                errors.extend(abs_distance(p,x) for p,x in zip(row,strings))
            c,s=-2*h*s/(k+1),2*h*c/(k+1)
            cp,sp=[-4*h*v/(k+1) for v in sp],[4*h*v/(k+1) for v in cp]
    tv=h*(point(".2")*(2*h)**(T+1)+2*(abs(b)+abs(bp))*iv.exp(abs(dph))*(4*h)**(T+1))/factorial(T+1)
    pv=2*h*iv.exp(4*h+abs(dph))*(abs(b)*abs(dph)**(degree+1)/factorial(degree+1)+abs(bp)*abs(dph)**degree/factorial(degree))
    hstr=approximant(h)
    header=[hstr,pos(abs_distance(h,hstr)),pos(sum(errors,ZERO)+tv+pv),
            pos(a+abs(b)+2*matrix_change(center,slope,1))]
    return header,records


def run(job):
    left,right,arc,X,V=job
    for case in (left,right):
        assert Fraction(case["eps"])==Fraction(1,5)
        assert Fraction(case["detuning"])==0 and Fraction(case["span"])==2
    center,slope=parameters(left,right,arc)
    ref=Gap(left).arcs[arc].inverse(Fraction(".25885"))
    x0=Fraction(round(float(ref.mid)*1000),1000)
    radius=Fraction(".012")
    periods=left["periods"][arc]
    assert right["periods"][arc]==periods
    skip=65
    header,linear=linear_coefficients(center,slope,V)
    start,error=launch_model(left,center,slope,x0,radius,periods,X,V,skip)
    print("launch",arc,x0,pos(error),flush=True)
    msg=f"{X} {V} {periods-skip}\n"+" ".join(header+[pos(error)]+linear+start)+"\n"
    executable=os.environ.get("KERR_JOINT_EXE",str(HERE/"transport_bivariate"))
    proc=subprocess.run([executable],input=msg,text=True,check=True,capture_output=True)
    lines=proc.stdout.splitlines()
    error,defect=lines[0].split()
    return {"arc":arc,"x_center":str(x0),"x_radius":str(radius),
            "control_center":[str(x) for x in center],"control_slope":[str(x) for x in slope],
            "x_degree":X,"v_degree":V,"skip":skip,"periods":periods-skip,
            "end_error":pos(point(error)*(ONE+BINARY_PAD)),"max_step_defect":defect,
            "coefficients":[x.split() for x in lines[1:]]}


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("left",type=Path)
    p.add_argument("right",type=Path)
    p.add_argument("output",type=Path)
    p.add_argument("--degree",type=int,default=10)
    args=p.parse_args()
    raw=[path.read_bytes() for path in (args.left,args.right)]
    cases=list(map(json.loads,raw))
    with ProcessPoolExecutor(2) as pool:
        out=list(pool.map(run,((*cases,i,args.degree,3) for i in (0,1))))
    for record in out:
        record["endpoint_sha256"]=[sha256(r).hexdigest() for r in raw]
    args.output.write_text(json.dumps(out,indent=2)+"\n")
    for r in out:
        print(r["arc"],r["x_center"],r["end_error"],flush=True)
