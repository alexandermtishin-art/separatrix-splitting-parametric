#include <quadmath.h>
#include <algorithm>
#include <array>
#include <cassert>
#include <cfenv>
#include <iostream>
#include <string>
#include <vector>

using Q=__float128;
using Vec=std::vector<Q>;
using State=std::array<Vec,2>;
constexpr int T=24, M=24;
constexpr Q pad=1e-25Q, guard_coefficient=1e-27Q;
Q read_q(){std::string s;assert(bool(std::cin>>s));return strtoflt128(s.c_str(),nullptr);}
void write_q(Q x){char s[110];quadmath_snprintf(s,sizeof(s),"%.39Qe",x);std::cout<<s<<" ";}
Q norm(Q a,Q b){const Q s=a*a+b*b;Q v=sqrtq(s)*(1+pad);assert(finiteq(s)&&v*v>=s*(1+pad));return v;}
Q l1(const Vec& a){Q total=0;for(Q x:a)total+=fabsq(x);return total;}

struct Product{
    int out,left,right;
};
std::vector<Product> indices(int X1,int V1,int X2,int V2){
    const int width=X1+X2+1;
    std::vector<Product> result;
    for(int v=0;v<=V1;++v)for(int x=0;x<=X1;++x)
        for(int w=0;w<=V2;++w)for(int y=0;y<=X2;++y)
            result.push_back({(v+w)*width+x+y,v*(X1+1)+x,w*(X2+1)+y});
    return result;
}

std::vector<Product> retained(int X1,int V1,int X2,int V2,int X,int V){
    auto full=indices(X1,V1,X2,V2);
    const int width=X1+X2+1;
    std::vector<Product> result;
    for(const auto& p:full){
        int x=p.out%width,v=p.out/width;
        if(x<=X&&v<=V)result.push_back({v*(X+1)+x,p.left,p.right});
    }
    return result;
}

Q cubic_high(const Vec& coefficients){
    const int degree=coefficients.size()-1;
    Q tail=0;
    for(int i=0;i<=degree;++i)for(int j=0;j<=degree;++j)
        for(int k=std::max(0,degree+1-i-j);k<=degree;++k)
            tail+=coefficients[i]*coefficients[j]*coefficients[k];
    return tail;
}

using Linear=std::array<std::array<std::array<Vec,4>,T+1>,M>;
struct Integrator{
    int X,V,space;
    Q h,h_error,a_error,sym;
    Linear linear;
    std::vector<Product> square,cube,lin;
    Integrator(int x,int v,Q step,Q step_error,Q lin_error,Q symmetric)
        :X(x),V(v),space((x+1)*(v+1)),h(step),h_error(step_error),a_error(lin_error),sym(symmetric),
        square(retained(x,v,x,v,x,v)),cube(square),lin(retained(0,v,x,v,x,v)){}

    State step(const State& initial,int k,Q& error,Q& max_defect) const{
        std::array<State,T+1> u;
        std::array<Vec,T+1> n;
        for(auto& p:u)for(auto& c:p)c.resize(space);
        for(auto& p:n)p.resize(space);
        u[0]=initial;
        Q dq=0,dp=0;
        for(int j=0;j<=T;++j){
            for(int a=0;a<=j;++a){
                int b=j-a;
                for(const auto& m:square)
                    n[j][m.out]+=(u[a][0][m.left]*u[b][0][m.right]+u[a][1][m.left]*u[b][1][m.right])/2;
            }
            Vec f(space),g(space);
            for(int a=0;a<=j;++a){
                int b=j-a;
                for(const auto& m:lin){
                    const auto& A=linear[k][a];
                    f[m.out]+=A[0][m.left]*u[b][0][m.right]+A[1][m.left]*u[b][1][m.right];
                    g[m.out]+=A[2][m.left]*u[b][0][m.right]+A[3][m.left]*u[b][1][m.right];
                }
                // Scaling a density once per pair of time coefficients
                // keeps the innermost convolution compact.
                Vec hn=n[a];
                for(Q& t:hn)t*=h;
                for(const auto& m:cube){
                    f[m.out]-=hn[m.left]*u[b][1][m.right];
                    g[m.out]+=hn[m.left]*u[b][0][m.right];
                }
            }
            if(j<T)for(int i=0;i<space;++i){
                u[j+1][0][i]=f[i]/(j+1);u[j+1][1][i]=g[i]/(j+1);
            }else{dq+=l1(f);dp+=l1(g);}
        }
        State end{Vec(space),Vec(space)};
        std::array<Q,T+1> size{},sizeA{};
        Vec x_majorant(X+1),v_majorant(V+1),linear_v(V+1);
        Q total=0,totalA=0,linear_tail=0,cubic_tail=0,center=0,variation=0;
        for(int j=0;j<=T;++j){
            for(int i=0;i<space;++i){
                end[0][i]+=u[j][0][i];end[1][i]+=u[j][1][i];
            }
            size[j]=fmaxq(l1(u[j][0]),l1(u[j][1]));
            const auto& a=linear[k][j];
            sizeA[j]=fmaxq(l1(a[0])+l1(a[1]),l1(a[2])+l1(a[3]));
            for(int v=0;v<=V;++v){
                linear_v[v]+=fmaxq(fabsq(a[0][v])+fabsq(a[1][v]),fabsq(a[2][v])+fabsq(a[3][v]));
                for(int x=0;x<=X;++x){
                    int i=v*(X+1)+x;
                    Q bound=fmaxq(fabsq(u[j][0][i]),fabsq(u[j][1][i]));
                    x_majorant[x]+=bound;v_majorant[v]+=bound;
                }
            }
            total+=size[j];totalA+=sizeA[j];
            center+=norm(u[j][0][0],u[j][1][0]);
            for(int i=1;i<space;++i)variation+=norm(u[j][0][i],u[j][1][i]);
        }
        // Products of marginal l1 bounds dominate all omitted coefficients.
        // Counting a term in two discarded-degree directions is harmless.
        cubic_tail+=cubic_high(x_majorant)+cubic_high(v_majorant);
        for(int i=0;i<=V;++i)for(int j=V+1-i;j<=V;++j)
            linear_tail+=linear_v[i]*v_majorant[j];
        for(int a=0;a<=T;++a)for(int b=0;b<=T;++b){
            if(a+b>T)linear_tail+=sizeA[a]*size[b];
            for(int c=std::max(0,T+1-a-b);c<=T;++c)
                cubic_tail+=size[a]*size[b]*size[c];
        }
        Q cubic=total*total*total;
        Q guard=guard_coefficient*(total+totalA*total+cubic)+1e-1000Q;
        Q defect=(dq+dp+2*(linear_tail+h*cubic_tail+a_error*total+h_error*cubic+guard))*(1+pad);
        constexpr Q cap=1e-7Q;
        Q near=(variation+cap)*(1+pad);
        Q rate=((h+h_error)*(sym+center*center/2+1.5Q*(2*center+near)*near))*(1+pad);
        assert(rate<.5Q);
        error=((error+defect)/(1-rate))*(1+pad);
        assert(error<cap&&finiteq(error));
        max_defect=fmaxq(max_defect,defect);
        return end;
    }
};

int main(){
    static_assert(FLT128_MANT_DIG==113);
    assert(std::fegetround()==FE_TONEAREST);
    int X,V,N;
    assert(bool(std::cin>>X>>V>>N));
    assert(X>=1&&X<=12&&V>=1&&V<=4&&N>=1);
    Q h=read_q(),he=read_q(),ae=read_q(),sym=read_q(),error=read_q();
    Integrator flow(X,V,h,he,ae,sym);
    for(auto& t:flow.linear)for(auto& j:t)for(auto& a:j){
        a.resize(V+1);for(auto& c:a)c=read_q();
    }
    State u{Vec(flow.space),Vec(flow.space)};
    for(auto& a:u)for(auto& x:a)x=read_q();
    // Optional number of steps in the final fractional period.
    int extra=0;
    if(std::cin>>extra) assert(extra>=0&&extra<M);
    Q defect=0;
    for(int j=0;j<N;++j)for(int k=0;k<M;++k)u=flow.step(u,k,error,defect);
    for(int k=0;k<extra;++k)u=flow.step(u,k,error,defect);
    write_q(error);write_q(defect);std::cout<<"\n";
    for(const auto& a:u){for(Q x:a)write_q(x);std::cout<<"\n";}
}
