# Phase derivatives under joint depth and detuning deviations

Appendix E.10 and Proposition 1 use the interval certificates in Kerr_joint_phase_derivative_certificate_2026-11-11.zip. Run the replay from the root of Online Resource 2. The nested archive is unpacked into a fresh directory and includes the frozen ESM_2_v6.zip used by the certificate. Its phase_joint/README_RU.md identifies the models, numerical bounds and rebuild steps. The commands below reproduce the final interval tests using the checked endpoint models.

```sh
(cd joint_phase && sha256sum -c SHA256SUMS)
mkdir joint_phase_replay
unzip -q joint_phase/Kerr_joint_phase_derivative_certificate_2026-11-11.zip -d joint_phase_replay
cd joint_phase_replay
unzip -q Kerr_lobe_area_certificate_2026-11-11.zip
unzip -q Kerr_fundamental_strip_certificate_2026-11-11.zip
unzip -q ESM_2_v6.zip -d base
ROOT="$PWD/base/certified_contour"
python advance/verify/verify_pair13.py "$ROOT" advance/transport/out-13-0.json advance/transport/out-13-1.json --preimage advance/transport/preimage-13-0.json advance/transport/preimage-13-1.json > replay-pair.json
cmp replay-pair.json advance/verify/certificate.json
python advance/verify/verify_intermediate.py "$ROOT" intermediate > replay-strip.json
cmp replay-strip.json intermediate/fundamental-strip-certificate.json
python advance/verify/verify_areas.py "$ROOT" intermediate > replay-area.json
cmp replay-area.json intermediate/area-certificate.json
python phase_joint/verify_derivative.py "$ROOT" intermediate --jets phase_joint/results-12 > replay-derivative.json
cmp replay-derivative.json phase_joint/results-12/derivative-certificate.json
```

The phase derivative is evaluated at 2.65 × 10⁻⁶ rad and at the central amplitude ratio. The derivatives hold uniformly over the stated joint depth and detuning box. The phase scan of Theorem 2 uses the nominal depth and detuning and can be replayed separately with phase_partition/check_flux.py.
