# Replay of the inverse transport results

Theorems 3 and 4 and Appendix E.11 use the archived original-flow interval panels. From the root of ESM_2_v8, run the commands below. The input ESM_2_v6.zip inside the extracted certificate is frozen, and the verifiers validate the input panel hashes against the contour record.

```sh
mkdir inverse_replay
unzip -q inverse_control/Kerr_inverse_control_and_flux_floor_2026-11-11.zip -d inverse_replay
cd inverse_replay
sha256sum -c SHA256SUMS
unzip -q ESM_2_v6.zip -d base
ROOT="$PWD/base/certified_contour"
python fold/certify_fold.py "$ROOT" --rho 2e-7 --phase 3.5e-7 --share .006 --grid 5 > fold-wide-replay.json
cmp fold-wide-replay.json fold/fold_wide_certificate.json
python fold/certify_fold.py "$ROOT" --rho 4e-7 --phase 7.5e-7 --share .015 --grid 9 --extended-chart > fold-replay.json
cmp fold-replay.json fold/fold_extended_certificate.json
python fold/normalized_curvature.py "$ROOT" fold/fold_wide_certificate.json > curvature-replay.json
cmp curvature-replay.json fold/normalized_curvature_certificate.json
PYTHONPATH="$ROOT/full_contour/code" python inverse/certify_rectangle.py "$ROOT" > rectangle-replay.log
cmp rectangle-replay.log inverse/rectangle.log
```

The checks use Python, mpmath and NumPy. They recompute graph projection, root bounds, interval area derivatives and the final inequality tests. The ODE enclosures are inputs to these replays. Their source and rebuild instructions are provided in the underlying ESM.
