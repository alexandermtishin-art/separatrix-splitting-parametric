import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Model M_E (phase-invariant oscillator with the Duffing frequency-action law) in multiprecision.
omega(n) is the exact power series of omega_series.py, truncated adaptively at relative 1e-24.
Based on split_mp2.py: direct separatrix splitting in multiprecision: Taylor integrator (order NORD) with mpmath/gmpy2,
stroboscopic map over the pump period pi, symplectically normalized Floquet coordinates."""
import sys, mpmath as mp
mp.mp.dps = 34
NORD = 32
PI = mp.pi
import os
NSTEP = int(os.environ.get('NSTEP', 12))  # Taylor steps per pump period
DT = PI / NSTEP
BETA = mp.mpf(4) / 3; U = mp.mpf(1); GAMMA = mp.mpf(0)

from fractions import Fraction
sys.path.insert(0, HERE)
import omega_series
_CO = None; _CA = None
def setup_omega(beta, N=160):
    global _CO, _CA
    b = Fraction(beta); c = omega_series.omega_coeffs(mp.mpf(b.numerator) / b.denominator, N)
    _CO = [+x for x in c]; _CA = [abs(float(x)) for x in c]
def degree(nmax):
    tail = 0.0
    for d in range(len(_CA) - 1, 0, -1):
        tail += _CA[d] * nmax ** d
        if tail > 1e-24: return min(d + 2, len(_CA) - 1)
    return 1

def step(model, eps, q, p, c, s):
    """one Taylor step of length DT for H = E_D(n) + eps cos(2t) q^2"""
    N = NORD
    n0 = float((q * q + p * p) / 2); d = degree(max(1.5 * n0, n0 + 0.02 * float(eps)))
    Q = [q]; P = [p]; Cc = [c]; Ss = [s]; NN = []; OM = []; CQ = []
    Hs = [[] for _ in range(d)]      # Horner levels h_j = c_j + n h_{j+1}, j = d-1..0, h_d = c_d
    for k in range(N):
        CQ.append(mp.fsum(Cc[j] * Q[k - j] for j in range(k + 1)))
        NN.append((mp.fsum(Q[j] * Q[k - j] for j in range(k + 1)) + mp.fsum(P[j] * P[k - j] for j in range(k + 1))) / 2)
        for j in range(d - 1, -1, -1):
            if j == d - 1:
                v = NN[k] * _CO[d]
            else:
                v = mp.fsum(NN[i] * Hs[j + 1][k - i] for i in range(k + 1))
            if k == 0: v += _CO[j]
            Hs[j].append(v)
        OM.append(Hs[0][k])
        fq = mp.fsum(OM[j] * P[k - j] for j in range(k + 1))
        fp = -mp.fsum(OM[j] * Q[k - j] for j in range(k + 1)) - 2 * eps * CQ[k]
        Q.append(fq / (k + 1)); P.append(fp / (k + 1))
        Cc.append(-2 * Ss[k] / (k + 1)); Ss.append(2 * Cc[k] / (k + 1))
    ev = lambda X: mp.polyval(X[::-1], DT)
    return ev(Q), ev(P), ev(Cc), ev(Ss)

def step_lin(model, eps, q, p, c, s):
    """one Taylor step of length DT from (q,p) with c=cos2t, s=sin2t at the step start"""
    N = NORD
    Q = [q]; P = [p]; Cc = [c]; Ss = [s]; Q2 = []; Q3 = []; CQ = []; P2 = []; NN = []; PN = []; NQ = []
    for k in range(N):
        CQ.append(mp.fsum(Cc[j] * Q[k - j] for j in range(k + 1)))
        Q2.append(mp.fsum(Q[j] * Q[k - j] for j in range(k + 1)))
        if model == 'D':  # q'' + (1+eps c)^2 q + beta q^3 = 0
            Q3.append(mp.fsum(Q2[j] * Q[k - j] for j in range(k + 1)))
            CCQ = mp.fsum(Cc[j] * CQ[k - j] for j in range(k + 1))
            fq = P[k]
            fp = -Q[k] - 2 * eps * CQ[k] - eps * eps * CCQ - BETA * Q3[k]
        elif model == 'M':
            Q3.append(mp.fsum(Q2[j] * Q[k - j] for j in range(k + 1)))
            fq = P[k]
            fp = -Q[k] - 2 * eps * CQ[k] - BETA * Q3[k]
            if GAMMA != 0:
                Q5k = mp.fsum(Q3[j] * Q2[k - j] for j in range(k + 1))
                fp -= GAMMA * Q5k
        else:  # 'M0' : H = n + U n^2/2 + eps cos(2t) q^2
            P2.append(mp.fsum(P[j] * P[k - j] for j in range(k + 1)))
            NN.append((Q2[k] + P2[k]) / 2)
            PN.append(mp.fsum(P[j] * NN[k - j] for j in range(k + 1)))
            NQ.append(mp.fsum(NN[j] * Q[k - j] for j in range(k + 1)))
            fq = P[k] + U * PN[k]
            fp = -Q[k] - 2 * eps * CQ[k] - U * NQ[k]
        Q.append(fq / (k + 1)); P.append(fp / (k + 1))
        Cc.append(-2 * Ss[k] / (k + 1)); Ss.append(2 * Cc[k] / (k + 1))
    ev = lambda X: mp.polyval(X[::-1], DT)
    return ev(Q), ev(P), ev(Cc), ev(Ss)

def strobe(model, eps, q, p):
    c, s = mp.mpf(1), mp.mpf(0)
    f = step if model == 'ME' else step_lin
    for _ in range(NSTEP):
        q, p, c, s = f(model, eps, q, p, c, s)
    return q, p

def monodromy(eps, model='M'):
    # linear Mathieu: same integrator with BETA=0 and no Kerr -> use model 'M' with q small? use exact linear system:
    global BETA, GAMMA
    b = BETA; g = GAMMA; BETA = mp.mpf(0); GAMMA = mp.mpf(0)
    lm = 'D' if model == 'D' else 'M'
    a = strobe(lm, eps, mp.mpf(1), mp.mpf(0)); bb = strobe(lm, eps, mp.mpf(0), mp.mpf(1))
    BETA = b; GAMMA = g
    M = mp.matrix([[a[0], bb[0]], [a[1], bb[1]]])
    tr = M[0, 0] + M[1, 1]; det = M[0, 0] * M[1, 1] - M[0, 1] * M[1, 0]
    disc = mp.sqrt(tr * tr / 4 - det)
    L1 = tr / 2 + disc; L2 = tr / 2 - disc
    Lu = L1 if abs(L1) > abs(L2) else L2; Ls = det / Lu
    def evec(L):
        # (M00-L) x + M01 y = 0
        return mp.matrix([M[0, 1], L - M[0, 0]])
    eu = evec(Lu); es = evec(Ls)
    nu_ = mp.sqrt(eu[0] ** 2 + eu[1] ** 2); eu = eu / nu_
    om = eu[0] * es[1] - eu[1] * es[0]; es = es / om
    hF = mp.log(abs(Lu)) / PI
    return eu, es, Lu, hF

def coords(q, p, eu, es):
    u = q * es[1] - p * es[0]; s = eu[0] * p - eu[1] * q
    return u, s

def splitting(model, eps, nph=16, u0=mp.mpf('1e-10'), maxper=2000):
    eps = mp.mpf(eps)
    eu, es, L, hF = monodromy(eps, model)
    lnL = mp.log(abs(L)); vals = []
    for j in range(nph):
        uu = u0 * mp.e ** (lnL * j / nph); q = uu * eu[0]; p = uu * eu[1]
        left = False; rec = []
        for k in range(maxper):
            q, p = strobe(model, eps, q, p)
            r = mp.sqrt(q * q + p * p)
            if r > 0.2: left = True
            if left:
                u, s = coords(q, p, eu, es); rec.append((r, u * s))
                if len(rec) > 3 and rec[-1][0] > rec[-2][0] and rec[-2][0] < 0.03: break
        km = min(range(len(rec)), key=lambda i: rec[i][0])
        vals.append(rec[km][1])
        print('  ', model, float(eps), j, mp.nstr(rec[km][1], 8), flush=True)
    # first-harmonic fit
    import math
    n = nph; ph = [2 * mp.pi * j / n for j in range(n)]
    a1 = 2 * mp.fsum(v * mp.sin(x) for v, x in zip(vals, ph)) / n
    b1 = 2 * mp.fsum(v * mp.cos(x) for v, x in zip(vals, ph)) / n
    a0 = mp.fsum(vals) / n
    res = max(abs(v - a0 - a1 * mp.sin(x) - b1 * mp.cos(x)) for v, x in zip(vals, ph))
    return hF * mp.sqrt(a1 ** 2 + b1 ** 2), hF * res, hF

if __name__ == '__main__':
    sys.path.insert(0, HERE)
    model = sys.argv[1]; eps = sys.argv[2]; nph = int(sys.argv[3]) if len(sys.argv) > 3 else 16
    if len(sys.argv) > 4: BETA = mp.mpf(sys.argv[4]); U = 3 * BETA / 4
    if len(sys.argv) > 5: GAMMA = mp.mpf(sys.argv[5])
    if len(sys.argv) > 6: mp.mp.dps = int(sys.argv[6])
    setup_omega(Fraction(4, 3) if len(sys.argv) <= 4 else Fraction(sys.argv[4]))
    U0 = mp.mpf(os.environ.get('U0', '1e-10'))
    W, res, hF = splitting(model, eps, nph, u0=U0)
    print('RESULT', model, eps, 'nstep', NSTEP, 'dps', mp.mp.dps, 'u0', mp.nstr(U0, 3), mp.nstr(W, 10), 'fitres', mp.nstr(res, 3), 'hF', mp.nstr(hF, 10), flush=True)
