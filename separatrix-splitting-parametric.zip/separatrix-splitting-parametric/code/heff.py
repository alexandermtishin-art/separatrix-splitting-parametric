import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Second-order (1/omega) classical static effective Hamiltonian for the lab-frame family
H = p^2/2 + Om^2 q^2/2 + beta(t) q^4/4,  Om = 1+eps cos(2t), beta = b0 Om^s, rotating frame a = c e^{-it}.
Classical Floquet high-frequency formula: H_eff = Hbar + sum_{k>0} i{V_k,V_-k}/k  (unit fast frequency, e^{ikt}),
sign checked against Duffing omega(A) = 1 + 3bA^2/8 - 15 b^2 A^4/256."""
import sympy as sp
c,cb,t=sp.symbols('c cb t'); eps,b0,s=sp.symbols('epsilon b0 s',positive=True)
E=sp.Symbol('E')  # E = e^{it}
def PB(A,B):  # {c,cb} = -i
    return -sp.I*(sp.diff(A,c)*sp.diff(B,cb)-sp.diff(A,cb)*sp.diff(B,c))
def build(order_eps=2, sval=None):
    a=c/E; ab=cb*E   # a = c e^{-it}
    q=(a+ab)/sp.sqrt(2); p=(a-ab)/(sp.I*sp.sqrt(2))
    cosnt=(E**2+E**-2)/2
    Om=1+eps*cosnt
    sv=s if sval is None else sval
    beta=b0*sp.series(Om**sv,eps,0,order_eps+1).removeO() if sval!=0 else b0
    H=sp.expand(p**2/2+sp.expand(Om**2)*q**2/2+beta*q**4/4 - c*cb)   # minus frame term n
    H=sp.expand(H)
    # Fourier decomposition in E
    terms=sp.Poly(sp.expand(H*E**12),E).as_dict()
    V={}
    for (k,),coef in terms.items():
        V[k-12]=sp.expand(coef)
    Hbar=V.get(0,0); H2=0
    for k in V:
        if k>0 and -k in V:
            H2+=sp.I*PB(V[k],V[-k])/k
    return sp.expand(Hbar), sp.expand(H2)
if __name__=='__main__':
    # sign check: pure Duffing, eps=0
    Hb,H2=build(sval=0)
    Hb0=sp.expand(Hb.subs(eps,0)); H20=sp.expand(H2.subs(eps,0))
    n=sp.Symbol('n')
    print('Hbar(eps=0) =',sp.simplify(Hb0))
    print('H2(eps=0)   =',sp.simplify(H20))
    print('expected H2 = -5 b0^2 n^3/64  -> check:',sp.simplify(H20.subs({c:sp.sqrt(n),cb:sp.sqrt(n)})+5*b0**2*n**3/64))
