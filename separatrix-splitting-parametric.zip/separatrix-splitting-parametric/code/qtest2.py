import os; HERE=os.path.dirname(os.path.abspath(__file__))+'/'; ROOT=os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Robustness of the direct exponent test: fits of s = ln(W/W0)+Delta by c + q ln(eps) + corrections, over fit bases
{eps}, {eps, eps^2}, {eps, eps ln eps}, {eps, eps^2, eps^3}, {eps, eps ln eps, eps^2} and windows eps<=0.28, 0.145;
and an injection test: add dq*ln(eps) to s and report the recovered fraction of dq."""
import json, numpy as np
r = json.load(open(DATA+'qtest.json'))
bases = {'e': lambda e: [e], 'e,e2': lambda e: [e, e*e], 'e,elne': lambda e: [e, e*np.log(e)],
         'e,e2,e3': lambda e: [e, e*e, e**3], 'e,elne,e2': lambda e: [e, e*np.log(e), e*e]}
out = {}
for g in r:
    e = np.array([float(x) for x in r[g]['eps']]); s = np.array(r[g]['s'])
    rows = []
    for name, f in bases.items():
        for hi in (0.29, 0.145):
            m = e <= hi
            if m.sum() < len(f(e)) + 3: continue
            A = np.c_[tuple([np.ones(m.sum()), np.log(e[m])] + [c[m] for c in f(e)])]
            co = np.linalg.lstsq(A, s[m], rcond=None)[0]
            rec = np.linalg.lstsq(A, s[m] + 0.02*np.log(e[m]), rcond=None)[0][1] - co[1]
            rows.append((name, hi, int(m.sum()), float(co[1]), float(rec/0.02), float(np.sqrt(np.mean((A@co-s[m])**2)))))
    qs = [x[3] for x in rows]
    out[g] = dict(rows=rows, qmin=min(qs), qmax=max(qs))
    print('gamma', g, ' q range %+.4f .. %+.4f' % (min(qs), max(qs)))
    for x in rows: print('   %-10s eps<=%.3f N=%2d q=%+.4f  recovered %.2f  rms %.1e' % x)
json.dump(out, open(DATA+'qtest2.json', 'w'), indent=1)
