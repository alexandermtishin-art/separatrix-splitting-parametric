import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Figures for ms4."""
import json, re, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'serif','font.serif':['DejaVu Serif'],'font.size':10,'axes.linewidth':0.8,
                     'axes.spines.top':False,'axes.spines.right':False,'legend.frameon':False,'lines.linewidth':1.6})
BLUE,ORANGE,AQUA,YELLOW,MAGENTA,GREEN='#2a78d6','#eb6834','#1baf7a','#eda100','#e87ba4','#008300'
GRID='#e6e6e3'
D=DATA+''
sp=json.load(open(D+'splitting.json')); th=json.load(open(D+'theory.json')); MD=json.load(open(D+'MD.json'))
def readmp(fn):
    out={}
    for l in open(fn):
        if l.startswith('RESULT'):
            x=l.split(); out[float(x[2])]=float(x[3])
    return out
mpM=readmp(D+'mp_M.txt'); mpM0=readmp(D+'mp_M0.txt')
ellM={0.14:1.6189e-12,0.16:3.9199e-11,0.20:3.7037e-09,0.24:8.3952e-08,0.28:8.2977e-07}
ellD={0.14:2.1791e-13,0.16:4.9247e-12,0.20:4.5966e-10,0.24:1.0252e-08,0.28:9.9613e-08}
for k,v in th.items(): ellM[float(k)]=v['ell2_M']; ellD[float(k)]=v['ell2_D']
try:
    for l in open(D+'th_small.txt'):
        if l.startswith('eps'): x=l.split(); ellM[float(x[1])]=float(x[3])
except FileNotFoundError: pass
def Wth0(e,U=1.0,nu=2.0):
    g=e/2; d=-e*e/16; h=np.sqrt(g*g-d*d); a=np.arccos(d/g)
    return 2*np.pi*e*nu/U*np.exp(nu*a/(2*h)-np.pi*nu/(2*h))*(1-np.exp(-nu*a/h))/(1-np.exp(-np.pi*nu/h))
def col(key,emin=0.13,emax=0.28):
    ks=sorted((k for k in sp if emin-1e-9<=float(k)<=emax+1e-9),key=float)
    return np.array([float(k) for k in ks]),np.array([sp[k][key] for k in ks])
kw=dict(ms=5,mec='white',mew=0.8,zorder=3)

# ---------------- Fig. 2
fig,axs=plt.subplots(1,2,figsize=(7.4,3.5),sharey=True)
ax=axs[0]
e,W=col('M'); ax.semilogy(e,W,'o',color=BLUE,label='M, direct',**kw)
em=np.array(sorted(x for x in mpM if x<0.13)); ax.semilogy(em,[mpM[x] for x in em],'o',color=BLUE,mfc='white',ms=5,mew=1.2,zorder=3,label='M, 34 digits')
e0,W0=col('M0'); ax.semilogy(e0,W0,'s',color=AQUA,label='M$_0$, direct',**kw)
em0=np.array(sorted(x for x in mpM0 if x<0.13)); ax.semilogy(em0,[mpM0[x] for x in em0],'s',color=AQUA,mfc='white',ms=5,mew=1.2,zorder=3)
eE=np.array(sorted(float(k) for k in MD)); ax.semilogy(eE,[MD[str(x) if str(x) in MD else [k for k in MD if float(k)==x][0]]['W'] for x in eE],'^',color=YELLOW,label='M$_{\\rm E}$, direct',**kw)
er,WR=col('melRWA_M',emin=0.16); ax.semilogy(er,WR,'--',color=ORANGE,label='M, Kerr-separatrix Melnikov')
ee=np.array(sorted(x for x in ellM if x>=0.14)); ax.semilogy(ee,[ellM[x] for x in ee],'-',color=BLUE,lw=1.3,label='M, Eq. (10)')
ex=np.linspace(0.06,0.30,100); ax.semilogy(ex,Wth0(ex),'-',color=AQUA,lw=1.3,label='M$_0$, Eq. (5)')
ax.semilogy(eE,[ [MD[k]['Wth'] for k in MD if float(k)==x][0] for x in eE],'-',color=YELLOW,lw=1.3,label='M$_{\\rm E}$, Eq. (10)')
ax.set_title('(a)',fontsize=10,loc='left'); ax.set_xlabel('$\\epsilon$'); ax.set_ylabel('kick amplitude $W$')
ax.grid(True,which='major',color=GRID,lw=0.6); ax.set_xlim(0.05,0.30); ax.legend(fontsize=6.8,loc='lower right',ncol=1)
ax=axs[1]
e,W=col('D'); ax.semilogy(e,W,'o',color=BLUE,label='D, direct',**kw)
e0,W0=col('D0'); ax.semilogy(e0,W0,'s',color=AQUA,label='D$_0$, direct',**kw)
er,WR=col('melRWA_D',emin=0.16); ax.semilogy(er,WR,'--',color=ORANGE,label='D, Kerr-separatrix Melnikov')
ee=np.array(sorted(ellD)); ax.semilogy(ee,[ellD[x] for x in ee],'-',color=BLUE,lw=1.3,label='D, Eq. (10) with $\\epsilon^2$ terms')
ax.set_title('(b)',fontsize=10,loc='left'); ax.set_xlabel('$\\epsilon$'); ax.grid(True,which='major',color=GRID,lw=0.6); ax.set_xlim(0.12,0.30)
ax.legend(fontsize=6.8,loc='lower right')
fig.tight_layout(); fig.savefig(ROOT+'figures/fig2_kick.png',dpi=300); plt.close(fig)

# ---------------- Fig. 3
fd2=json.load(open(D+'fig_data2.json')); eg=np.array(fd2['eps'])
rs=json.load(open(D+'resid_small.json'))
gams=[0.0,8/15,17/15,26/15,34/15]; labs=['$\\gamma=0$, $\\eta=17/9$','$\\gamma=8/15$, $\\eta=1$','$\\gamma=17/15$, $\\eta=0$','$\\gamma=26/15$, $\\eta=-1$','$\\gamma=34/15$, $\\eta=-17/9$']
cols=[BLUE,ORANGE,AQUA,YELLOW,MAGENTA]; marks=['o','s','^','D','v']
meas={}
for fn,keys in [(D+'sextic.txt',gams[:3]),(D+'sextic_neg.txt',[gams[4],gams[3]])]:
    for l in open(fn):
        if not l.startswith('eps'): continue
        e=float(l.split()[1]); rr=[float(x) for x in re.findall(r'ratio ([0-9.e+-]+)',l)]
        for g,r in zip(keys,rr): meas.setdefault(g,{})[e]=r
for x in mpM:
    if x in mpM0: meas[0.0][x]=mpM[x]/mpM0[x]
fig,axs=plt.subplots(1,2,figsize=(7.4,3.6))
ax=axs[0]
for g,c,m,lab in zip(gams,cols,marks,labs):
    Dg=np.array(fd2['Delta'][str(g)]); e=np.array(sorted(meas[g])); r=np.array([meas[g][x] for x in e])
    kap=np.exp(np.mean(np.log(r)+np.interp(e,eg,Dg)))
    ax.loglog(eg,kap*np.exp(-Dg),'-',color=c,lw=1.3)
    big=e>=0.135; ax.loglog(e[big],r[big],m,color=c,label=lab,**kw)
    if (~big).any(): ax.loglog(e[~big],r[~big],m,color=c,mfc='white',ms=5,mew=1.2,zorder=3)
DgE=np.array(fd2['Delta']['MD']); eE=np.array(sorted(float(k) for k in MD))
rE=np.array([[MD[k]['W'] for k in MD if float(k)==x][0]/[sp[k]['M0'] for k in sp if abs(float(k)-x)<1e-9][0] for x in eE])
kapE=np.exp(np.mean(np.log(rE)+np.interp(eE,eg,DgE)))
ax.loglog(eg,kapE*np.exp(-DgE),'-',color=GREEN,lw=1.3); ax.loglog(eE,rE,'P',color=GREEN,label='M$_{\\rm E}$, $\\eta=17/9$',**kw)
ax.set_xlabel('$\\epsilon$'); ax.set_ylabel('$W/W^{(0)}$'); ax.set_title('(a)',fontsize=10,loc='left')
ax.set_xticks([0.05,0.1,0.2,0.3]); ax.set_xticklabels(['0.05','0.1','0.2','0.3']); ax.minorticks_off()
ax.grid(True,which='major',color=GRID,lw=0.6); ax.legend(fontsize=6.6,loc='lower right')
ax=axs[1]; es=np.array(rs['eps'])
for g,c,m,lab in zip(gams,cols,marks,labs):
    R=np.array(rs['R'][str(g)]); ax.semilogx(es,R,'-',color=c,lw=1.3); ax.semilogx(es[::3],R[::3],m,color=c,ms=4.5,mec='white',mew=0.7)
ax.set_xlabel('$\\epsilon$'); ax.set_ylabel('$\\Delta-\\eta\\,\\ln(1/\\epsilon)$'); ax.set_title('(b)',fontsize=10,loc='left')
ax.grid(True,which='major',color=GRID,lw=0.6)
fig.tight_layout(); fig.savefig(ROOT+'figures/fig3_law.png',dpi=300); plt.close(fig)
print('ok')
