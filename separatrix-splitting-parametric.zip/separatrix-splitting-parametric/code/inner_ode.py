"""Inner problem (see inner.py) with the harmonic -2 response taken as the unique solution that stays polynomial in
the lower half plane, Y(tau) = i Phi(tau) int_0^inf e^{-2y} Phi^{-1}(tau-iy) S(tau-iy) dy, and the jump of the
harmonic +2 evaluated on the line Im tau = -c for increasing c (the harmonic-4 jump of X4 is O(e^{-4c}) there)."""
import numpy as np
from scipy.integrate import solve_ivp
U = -1.0
v1 = np.array([1, U], complex); v2 = np.array([1, -U/2], complex)
V = np.c_[v1, v2]; Vi = np.linalg.inv(V)
Phi = lambda t: np.c_[t*v1, v2/t**2]
Phii = lambda t: np.diag([1/t, t**2]) @ Vi
yl, wl = np.polynomial.laguerre.laggauss(80)       # int_0^inf e^{-x} f(x) dx, x = 2y
def Ym2(t):
    acc = np.zeros(2, complex)
    for x, wq in zip(yl, wl):
        s = t - 0.5j*x
        acc += wq * (Phii(s) @ np.array([0, 0.5/s]))
    return 1j * (Phi(t) @ acc) * 0.5            # dy = dx/2
def check(t, h=1e-5):
    d = (Ym2(t+h) - Ym2(t-h))/(2*h)
    M = np.array([[-1, 2/U], [U, 0]])/t
    return np.abs(d - 2j*Ym2(t) - M@Ym2(t) - np.array([0, 0.5/t])).max()
def rhs(x, y, c, cross):
    t = x - 1j*c
    x4N, x4w, ypN, ypw = y
    ymN, ymw = Ym2(t) if cross else (0, 0)
    d = np.empty(4, complex)
    d[0] = (-U*t*x4N + 2*t*x4w - 1j)/(U*t*t) - 4j*x4N
    d[1] = (U*t*x4N - 0.5j)/(t*t) - 4j*x4w
    fN = (-U*ypN + 2*ypw)/(U*t); fw = (U*ypN + 0.5)/t
    if cross:
        fN += -2j*x4N*ymw - 2j*x4w*ymN - ymN/t + 2*ymw/(U*t)
        fw += 2j*U*x4N*ymw + 2j*U*x4w*ymN + 4j*x4w*ymw + 1j*x4w + 2*ymw/t
    d[2] = fN - 2j*ypN; d[3] = fw - 2j*ypw
    return d
def jump(c, R, cross):
    out = {}
    for side, x0 in (('u', -R), ('s', R)):
        t = x0 - 1j*c
        y0 = np.r_[np.array([-1j/U, -0.5j])/(4j*t*t), np.array([0, 0.5/t])/(2j)]
        r = solve_ivp(rhs, (x0, 0.0), y0, args=(c, cross), method='DOP853', rtol=1e-13, atol=1e-16)
        out[side] = r.y[:, -1]
    D = out['u'][2:] - out['s'][2:]; t = -1j*c
    C = np.linalg.solve(Phi(t)*np.exp(-2j*t), D)
    return C
if __name__ == '__main__':
    print('ODE check of Ym2:', check(1.0-2j), check(-3.0-0.5j))
    for c in (5.0, 6.0, 7.0):
        d = jump(c, 300.0, False); tt = jump(c, 300.0, True)
        print('c=%.0f  C1_dir=%.6f%+.6fj  C1_tot=%.6f%+.6fj  ratio=%.6f%+.6fj  |ratio|=%.6f' % (c, d[0].real, d[0].imag, tt[0].real, tt[0].imag, (tt[0]/d[0]).real, (tt[0]/d[0]).imag, abs(tt[0]/d[0])), flush=True)
