# Inner problem of M0 for U<0 near the upper singularity: harmonic expansion of the PDE (d_tau + d_s) X = F(X, s)
import sympy as sp
tau, U, eps, lam, E = sp.symbols('tau U epsilon lambda E')   # E = e^{is}
N0 = sp.I/(U*tau); w0 = -U*N0/2
x4N, x4w, ymN, ymw, ypN, ypw = sp.symbols('x4N x4w ymN ymw ypN ypw')
N = N0 + lam*x4N*E**4 + eps*(ymN/E**2 + ypN*E**2)
w = w0 + lam*x4w*E**4 + eps*(ymw/E**2 + ypw*E**2)
cos2s = (E**2 + E**-2)/2
FN = -2*sp.I*N*w*(1 + lam*E**4)
Fw = 2*sp.I*w*(U*N + w*(1 + lam*E**4) + eps*cos2s)
def coeff(expr, k, ordlam, ordeps):
    e = sp.expand(expr)
    e = sp.Poly(e, lam, eps).as_expr()
    c = sp.expand(e).coeff(lam, ordlam).coeff(eps, ordeps)
    c = sp.expand(c*E**8)   # shift to polynomial in E
    return sp.simplify(sp.Poly(c, E).coeff_monomial(E**(k+8)))
for name, F in [('N', FN), ('w', Fw)]:
    print(name, 'base residual k=0:', sp.simplify(coeff(F,0,0,0) - sp.diff(N0 if name=='N' else w0, tau)))
    print(name, 'X4 source (lam^1 eps^0, k=4):', coeff(F,4,1,0).subs({x4N:0,x4w:0}))
    print(name, 'X4 full (lam^1, k=4):', coeff(F,4,1,0))
    print(name, 'Y-2 (eps^1, k=-2):', coeff(F,-2,0,1))
    print(name, 'Y+2 direct (eps^1 lam^0, k=2):', coeff(F,2,0,1))
    print(name, 'Y+2 cross (eps^1 lam^1, k=2):', coeff(F,2,1,1))
