import os; HERE=os.path.dirname(os.path.abspath(__file__))+'/'; ROOT=os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Direct exponent test: s(eps)=ln(W/W0)+Delta(eps) fitted by c + q ln(eps) + a eps (+ b eps^2).
If the singular-time law holds, q = 0. W: 34-digit runs for eps<=0.14, double precision (data/sextic*.txt) above."""
import json, re, numpy as np
D = json.load(open(DATA+'delta_sextic.json'))
def read_mp(f):
    out = {}
    for l in open(f):
        m = re.match(r'RESULT \S+ (\S+) (?:.* u0 \S+ )?(\S+) fitres', l)
        if m: out['%.2f' % float(m.group(1))] = float(m.group(2))
    return out
W0 = read_mp(DATA+'mp_M0.txt')
W0.update({'0.16': 7.1706e-09, '0.20': 4.4688e-07, '0.24': 7.2200e-06, '0.28': 5.3681e-05})
dbl = {}
for f, labels in [('sextic.txt', ['17/9', '1', '0']), ('sextic_neg.txt', ['-17/9', '-1'])]:
    for l in open(DATA+f):
        if not l.startswith("eps"): continue
        e = "%.2f" % float(l.split()[1])
        for lab, w in re.findall(r'p=(\S+): (\S+) ratio', l):
            dbl.setdefault(lab, {})[e] = float(w)
cases = {'0': ('17/9', read_mp(DATA+'mp_M.txt')),
         '17/15': ('0', read_mp(DATA+'mp_g17_15.txt')),
         '34/15': ('-17/9', read_mp(DATA+'mp_g34_15.txt'))}
res = {}
for g, (lab, mpW) in cases.items():
    W = dict(dbl[lab]); W.update(mpW)
    es = sorted(k for k in W if k in W0 and k in D[g])
    e = np.array([float(k) for k in es]); s = np.array([np.log(W[k] / W0[k]) + D[g][k] for k in es])
    r = ln = np.log(W[k] / W0[k]) if False else None
    rows = []
    for name, cols in [('c+q ln e+a e', [np.ones_like(e), np.log(e), e]),
                       ('c+q ln e+a e+b e^2', [np.ones_like(e), np.log(e), e, e * e])]:
        for lo, hi in [(0.0, 0.29), (0.0, 0.145), (0.0, 0.105)]:
            m = (e >= lo) & (e <= hi)
            A = np.c_[tuple(c[m] for c in cols)]
            co, *_ = np.linalg.lstsq(A, s[m], rcond=None)
            rows.append((name, hi, m.sum(), co[1], np.sqrt(np.mean((A @ co - s[m]) ** 2))))
    lnr = np.array([np.log(W[k] / W0[k]) for k in es])
    print('gamma', g, 'eta', lab, 'eps', es)
    print('   ln(W/W0):', np.round(lnr, 4).tolist())
    print('   s=ln(W/W0)+Delta:', np.round(s, 4).tolist(), ' spread %.4f' % (s.max() - s.min()))
    for r_ in rows: print('   %-22s eps<=%.3f N=%2d  q=%+.4f  rms=%.1e' % r_)
    res[g] = dict(eps=es, lnratio=lnr.tolist(), s=s.tolist(), fits=[list(map(lambda x: x if isinstance(x, str) else float(x), r_)) for r_ in rows])
json.dump(res, open(DATA+'qtest.json', 'w'), indent=1)
