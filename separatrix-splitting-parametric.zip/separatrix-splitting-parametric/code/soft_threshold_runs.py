import os, sys; HERE=os.path.dirname(os.path.abspath(__file__))+'/'; ROOT=os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Out-of-sample test of the interference prediction for gamma=26/15 near reconnection (predicted max 0.1609, min 0.1629).
Uses the softening model and Mathieu monodromy of soft_diag.py (beta=-4/3)."""
sys.path.insert(0, HERE)
sys.argv, args = [sys.argv[0], 'none'], sys.argv[1:]
import soft_diag, split
for e in [float(x) for x in args]:
    r = split.splitting('G%.12f' % (26/15), e, nph=16, u0=1e-6)
    print('G26 eps %.4f W1 %.5e W2/W1 %.1e res/W %.1e rmin %.2e' % (e, r['W1'], abs(r['W2'])/abs(r['W1']), r['fitres']/abs(r['W1']), r['rmin']), flush=True)
