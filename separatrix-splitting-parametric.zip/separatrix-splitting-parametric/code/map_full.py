import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Separatrix map with the complete first-order kick W = W1 (1 + nu/(2 Omega0)) (gauge identity),
using either the first-order saddle rate g or the exact Floquet rate of the origin h_F.
Reports per-iteration exponent L_map, mean passage time and time-unit exponent; stationarity over segments."""
import numpy as np, sys
from numba import njit
sys.path.insert(0,HERE)
from core import propagate
@njit(cache=True)
def run(W, lam, C, h, nseg, nper, seed):
    np.random.seed(seed)
    w = 1e-3*W*(np.random.rand()-0.5); tau = 2*np.pi*np.random.rand(); dw, dt_ = 1.0, 0.0
    S = np.zeros(nseg); T = np.zeros(nseg)
    for k in range(nseg):
        for i in range(nper):
            w1 = w - W*np.sin(tau); dw1 = dw - W*np.cos(tau)*dt_
            tau1 = tau + lam*np.log(C/abs(w1)); dtau1 = dt_ - lam*dw1/w1
            w, tau, dw, dt_ = w1, tau1 % (2*np.pi), dw1, dtau1
            nr = np.sqrt(dw*dw+dt_*dt_); S[k] += np.log(nr); dw /= nr; dt_ /= nr
            T[k] += np.log(C/abs(w))/h
    return S, T
def floquet_rate(eps, nu=2.0):
    P = 2*np.pi/nu; par = np.array([1.0, eps, nu, 0, 0])
    y,*_ = propagate(0., 0., 1, par, 0.0, 0.0, P, P/8000)
    return np.log(max(abs(np.linalg.eigvals(y[2:].reshape(2,2)))))/P
if __name__ == '__main__':
    nu=2.0; O0=1.0
    for eps in [0.20,0.24,0.28]:
        g = eps*nu/4; hF = floquet_rate(eps)
        for lab,h in [('g',g),('hF',hF)]:
            x = np.pi*nu/(4*h); W1 = np.pi*eps*O0*nu/np.cosh(x); W = W1*(1+nu/(2*O0))
            C = 8*h**2; lam = nu/h
            Ss=[]; Ts=[]
            for s in range(4):
                S,T = run(W, lam, C, h, 10, 200000, s); Ss.append(S); Ts.append(T)
            Ss=np.array(Ss); Ts=np.array(Ts)
            Lit = Ss.sum()/ (10*200000*4); Tm = Ts.sum()/(10*200000*4)
            segL = (Ss.sum(0)/Ts.sum(0))
            print('eps %.2f %-2s h=%.4f  L_map/iter %.3f  <T>_map %.1f  lam_map %.4f  seg spread %.4f..%.4f'%(eps,lab,h,Lit,Tm,Lit/Tm,segL.min(),segL.max()))
