import os; HERE=os.path.dirname(os.path.abspath(__file__))+'/'; ROOT=os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Power series of the Duffing frequency-action law omega(J), V = q^2/2 + beta q^4/4, in mpmath arithmetic.
With s = A^2 (A the amplitude), J(s) = (2/pi) int_0^{pi/2} s cos^2(phi) [1 + beta s (1+sin^2 phi)/2]^{1/2} dphi
and E(s) = s/2 + beta s^2/4 have exactly known Taylor coefficients in s. s(J) follows by Lagrange inversion and
omega = (dE/ds)/(dJ/ds) is re-expanded in J. omega_coeffs(beta, N, dps) -> list of mpf c_k, omega(J) = sum c_k J^k."""
import mpmath as mp
from math import comb

def mul(a, b, N):
    return [mp.fsum(a[i] * b[k - i] for i in range(k + 1)) for k in range(N)]

def inv(a, N):
    r = [1 / a[0]]
    for k in range(1, N):
        r.append(-mp.fsum(a[i] * r[k - i] for i in range(1, k + 1)) / a[0])
    return r

def omega_coeffs(beta, N, dps=60):
    with mp.workdps(dps):
        beta = mp.mpf(beta)
        I = lambda m: mp.mpf(comb(2 * m, m)) / 4 ** m / (2 * (m + 1))   # (2/pi) int cos^2 sin^{2m}
        bh = [mp.binomial(mp.mpf(1) / 2, k) for k in range(N)]
        a = [bh[k] * (beta / 2) ** k * mp.fsum(comb(k, m) * I(m) for m in range(k + 1)) for k in range(N)]  # J/s
        # Lagrange inversion: s(J) = sum_n b_n J^n, b_n = (1/n) [s^{n-1}] (s/J(s))^n = (1/n)[s^{n-1}] (1/a(s))^n
        r = inv(a, N); pw = [mp.mpf(1)] + [mp.mpf(0)] * (N - 1); b = [mp.mpf(0)]
        for n in range(1, N):
            pw = mul(pw, r, N); b.append(pw[n - 1] / n)
        # omega as series in s: (1/2 + beta s/2) / J'(s), J'(s) = sum (k+1) a_k s^k
        dJ = [(k + 1) * a[k] for k in range(N)]
        om_s = mul([mp.mpf(1) / 2, beta / 2] + [mp.mpf(0)] * (N - 2), inv(dJ, N), N)
        # compose omega(s(J)) by Horner in series arithmetic
        res = [om_s[N - 1]] + [mp.mpf(0)] * (N - 1)
        for k in range(N - 2, -1, -1):
            res = mul(res, b, N); res[0] += om_s[k]
        return [+x for x in res]

if __name__ == '__main__':
    import sys
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 30
    c = omega_coeffs(mp.mpf(4) / 3, N)
    print([mp.nstr(x, 12) for x in c[:4]])   # expect 1, 1, -17/12, 125/36
    for k in range(0, N, 10): print(k, mp.nstr(c[k], 6))
