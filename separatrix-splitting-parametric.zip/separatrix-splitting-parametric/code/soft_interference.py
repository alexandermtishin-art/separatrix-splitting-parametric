import os; HERE=os.path.dirname(os.path.abspath(__file__))+'/'; ROOT=os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Softening sextics (beta=-4/3, U=-1): real part r of the complex singular time.
Beyond the lobe tip the continued separatrix of K0 meets |X|<1 on J_a<J<J_b (near the second resonance);
there the time increment is real, r = int_{J_a}^{J_b} dJ / (eps Q2 sqrt(1-X^2)), X = -2(F - eps^2 J/16)/(eps Q2).
The pair of singularities t* = +-r + i I gives W ~ |cos(nu r + phi)|. Output: phase P(eps) = nu r/pi - 1/2 on a grid,
the predicted extrema for one common phase fitted to the measured minima, and the comparison with the measured extrema."""
import numpy as np, json
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq
from scipy.integrate import quad
src = open(HERE+'imt_soft.py').read().split("if __name__=='__main__':")[0]
ns = {'__file__': HERE+'imt_soft.py'}; exec(src, ns)
nu = 2.0
def phase_fn(g):
    J, E, om, Q2 = ns['table'](g, Amax=6.0, N=1500); F = E - J
    sF = CubicSpline(J, F); sQ = CubicSpline(J, Q2); js = np.linspace(J[5], J[-5], 20000)
    def P(eps):
        X = lambda j: -2*(sF(j) - eps**2*j/16)/(eps*sQ(j)); xs = X(js)
        c2 = np.where((xs[:-1] > 1) & (xs[1:] <= 1))[0]; c3 = np.where((xs[:-1] > -1) & (xs[1:] <= -1))[0]
        if len(c2) == 0 or len(c3) == 0: return np.nan
        Ja = brentq(lambda j: X(j)-1, js[c2[0]], js[c2[0]+1]); Jb = brentq(lambda j: X(j)+1, js[c3[0]], js[c3[0]+1])
        jj = lambda th: Ja + (Jb-Ja)*(1-np.cos(th))/2
        f = lambda th: (Jb-Ja)/2*np.sin(th)/(eps*sQ(jj(th))*np.sqrt(max(1e-300, 1-X(jj(th))**2)))
        return nu*quad(f, 0, np.pi, limit=400)[0]/np.pi - 0.5
    return P
meas = {'26/15': dict(min=[0.1025, 0.14525, 0.1575], max=[0.1275, 0.1525]), '17/15': dict(min=[0.1859, 0.235], max=[0.218])}
out = {}
Ps = {g: phase_fn(eval(g)) for g in ['8/15', '17/15', '26/15']}
grid = np.round(np.arange(0.09, 0.2451, 0.0025), 4)
for g, P in Ps.items():
    out[g] = {'eps': grid.tolist(), 'P': [float(P(e)) for e in grid]}
fr = [Ps[g](e) % 1 for g in meas for e in meas[g]['min']]
phi = float(np.mean(fr)); out['phi_min'] = phi; out['frac_min'] = fr
out['frac_max'] = [Ps[g](e) % 1 for g in meas for e in meas[g]['max']]
print('fractional phase at measured minima', np.round(fr, 3), 'mean %.3f sd %.3f' % (phi, np.std(fr)))
print('fractional phase at measured maxima', np.round(out['frac_max'], 3))
# predicted extrema positions with the common phase
pred = {}
for g, P in Ps.items():
    e = np.array(out[g]['eps']); p = np.array(out[g]['P']); ok = np.isfinite(p); e, p = e[ok], p[ok]
    rows = []
    for kind, off in (('min', phi), ('max', phi + 0.5)):
        for k in range(int(np.floor(p.min())) - 1, int(np.ceil(p.max())) + 1):
            tgt = k + off
            idx = np.where((p[:-1] - tgt) * (p[1:] - tgt) <= 0)[0]
            for i in idx:
                ee = brentq(lambda x: P(x) - tgt, e[i], e[i+1]); rows.append((kind, round(ee, 4)))
    pred[g] = sorted(rows, key=lambda x: x[1]); print(g, 'P range %.3f..%.3f' % (p.min(), p.max()), pred[g])
out['pred'] = pred
json.dump(out, open(DATA+'soft_interference.json', 'w'), indent=1)
