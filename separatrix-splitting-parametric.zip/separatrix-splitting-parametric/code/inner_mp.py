"""High-precision Stokes constant of the inner problem (U=-1), integral form on two rays from -ic.
C1 = int e^{2 i s} [Phi^{-1}(s) R(s)]_1 ds over the line Im s = -c, deformed to rays s = -ic + r e^{i(pi-a)}, -ic + r e^{ia}.
X4 and Y_-2 from their ray representations (algebraic in the upper half plane)."""
import mpmath as mp, sys
mp.mp.dps = int(sys.argv[1]) if len(sys.argv) > 1 else 20
U = mp.mpf(-1)
V = mp.matrix([[1, 1], [U, -U/2]]); Vi = V**-1
def Phi(t): return mp.matrix([[t, 1/t**2], [U*t, -U/(2*t**2)]])
def Phii(t): return mp.diag([1/t, t**2]) * Vi
b = mp.matrix([-1j/U, -0.5j])
Vib = Vi * b
def X4(t):
    I3 = mp.quad(lambda y: mp.exp(-4*y)*(t + 1j*y)**-3, [0, 1, mp.inf])
    c = mp.matrix([-1j*Vib[0]*I3, Vib[1]/(4j)])
    return Phi(t) * c
def Ym2(t):
    I2 = mp.quad(lambda y: mp.exp(-2*y)*(t - 1j*y)**-2, [0, 1, mp.inf])
    I1 = t/2 - 0.25j
    acc = mp.matrix([Vi[0, 1]*I2/2, Vi[1, 1]*I1/2])
    return 1j * Phi(t) * acc
def Scross(t):
    x4N, x4w = X4(t); ymN, ymw = Ym2(t)
    fN = -2j*x4N*ymw - 2j*x4w*ymN - ymN/t + 2*ymw/(U*t)
    fw = 2j*U*x4N*ymw + 2j*U*x4w*ymN + 4j*x4w*ymw + 1j*x4w + 2*ymw/t
    return mp.matrix([fN, fw])
def C1(src, c, a=mp.pi/3):
    s0 = -1j*c
    g = lambda s: mp.exp(2j*s) * (Phii(s) * src(s))[0]
    left = mp.quad(lambda r: g(s0 + r*mp.expj(mp.pi - a))*mp.expj(mp.pi - a), [0, 1, 4, mp.inf])
    right = mp.quad(lambda r: g(s0 + r*mp.expj(a))*mp.expj(a), [0, 1, 4, mp.inf])
    return right - left
if __name__ == '__main__':
    d = C1(lambda s: mp.matrix([0, 1/(2*s)]), 3)
    print('C1_dir =', mp.nstr(d, 15), ' 4pi/3 =', mp.nstr(4*mp.pi/3, 15), flush=True)
    for c in [float(x) for x in sys.argv[2:]] or [4, 6]:
        x = C1(Scross, c); r = (4*mp.pi/3 + x)/(4*mp.pi/3)
        print('c=%g  C1_cross=%s  ratio=%s  ratio+1/6=%s' % (c, mp.nstr(x, 14), mp.nstr(r, 14), mp.nstr(r + mp.mpf(1)/6, 3)), flush=True)
