import os; HERE=os.path.dirname(os.path.abspath(__file__))+'/'; ROOT=os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Recompute the detuned Kerr-separatrix quadratures at eps=0.20 (data/ks_detuned.json).
With the default integration length T=60/h of melD.homoclinic the orbit picked at eps=0.20 with delta=-eps^2/16
is not the primary homoclinic loop and the quadrature fails (KS_det ~ 2.6e-3); T=40/h gives the correct loop."""
import sys, json
sys.path.insert(0, HERE)
src = open(HERE+'melD.py').read().replace('T=60/h', 'T=40/h'); ns = {'__file__': HERE+'melD.py'}; exec(src, ns)
g = open(HERE+'gather.py').read().split('out={}')[0]
g = g.replace("def melRWA_M(eps,inv=False):", "def melRWA_M(eps,inv=False,dd=0.0):").replace("g=eps*nu/4; d=0.0;", "g=eps*nu/4; d=dd;")
n2 = {'__file__': HERE+'gather.py'}; exec(g, n2); n2['homoclinic'] = ns['homoclinic']
e = 0.20
d = json.load(open(DATA+'ks_detuned.json'))
d['0.2'].update(KS_det=n2['melRWA_M'](e, dd=-e*e/16), KS0_det=n2['melRWA_M'](e, True, dd=-e*e/16))
json.dump(d, open(DATA+'ks_detuned.json', 'w'), indent=1); print(d['0.2'])
