import os; HERE=os.path.dirname(os.path.abspath(__file__))+'/'; ROOT=os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Melnikov integral of the phase-invariant oscillator M_E by the residue at the singularity t* of its separatrix.
M_E: H = E_D(n) + eps cos(nu t) q^2, Q0 = Q2 = J, h0 = -J/16, E_D the Duffing energy-action function (beta=4/3).
On the continued separatrix J -> inf at t*, J ~ sigma^-3 (sigma = t - t*); the Laurent coefficients follow from
E_D = e4 J^{4/3} + e2 J^{2/3} + ..., and W_Mel = 2 pi eps nu |C_-3 (i nu)^2/2 + C_-2 i nu + C_-1| exp(-nu Im t*).
nu Im t* from (11). Prediction of the selection rule: W_{M_E}/W_Mel -> 1 as eps -> 0."""
import numpy as np, json, re, sys
import mpmath as mp
from scipy.integrate import quad
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq
b = 4/3; nu = 2.0
# large-amplitude constants: J = A^3 (j0 + j1 A^-2 + ...), E = b A^4/4 + A^2/2
I0 = quad(lambda f: np.cos(f)**2*np.sqrt(1+np.sin(f)**2), 0, np.pi/2, epsabs=1e-15)[0]
I1 = quad(lambda f: np.cos(f)**2/np.sqrt(1+np.sin(f)**2), 0, np.pi/2, epsabs=1e-15)[0]
j0 = (2/np.pi)*np.sqrt(b/2)*I0; j1 = (2/np.pi)*np.sqrt(b/2)*I1/b
e4 = (b/4)*j0**(-4/3); e2 = (0.5 - b*j1/(3*j0))*j0**(-2/3)
def laurent(eps):
    # sigma = -i K (u + c2 u^2 + c3 u^3), u = J^{-1/3}, K = 3/(2 e4)
    K = 3/(2*e4); c2 = 1/(2*e4); c3 = (1/e4**2 - e2/e4 + eps**2/(8*e4**2))/3
    w = mp.mpf(1)  # series in w = u + c2 u^2 + c3 u^3 ; invert to u = w - c2 w^2 + (2 c2^2 - c3) w^3
    a1, a2 = -c2, 2*c2**2 - c3
    # J = u^-3 = w^-3 (1 + a1 w + a2 w^2)^-3 = w^-3 (1 - 3 a1 w + (6 a1^2 - 3 a2) w^2 + ...)
    B0, B1, B2 = 1.0, -3*a1, 6*a1**2 - 3*a2
    # w = i sigma / K  -> w^-3 = (K/i)^3 sigma^-3 etc.
    Ki = K/1j
    return B0*Ki**3, B1*Ki**2, B2*Ki   # C_-3, C_-2, C_-1
# separatrix of K0 for M_E: X = -2(F - eps^2 J/16)/(eps J), F = E_D - J
src = open(HERE+'imt_sextic.py').read().split('TAB={}')[0]
ns = {'__file__': HERE+'imt_sextic.py'}; exec(src, ns)
As, J, E, om, Q2 = ns['table'](0.0, Amax=float(os.environ.get('AMAX','60')), N=int(os.environ.get('NA','900')))
lJ = np.log(J); sF = CubicSpline(lJ, np.log(E - J))
def nuImt(eps):
    Xf = lambda x: 2*(np.exp(sF(x)) - eps**2*np.exp(x)/16)/(eps*np.exp(x))
    xm = brentq(lambda x: Xf(x) - 1, lJ[2], lJ[-3])
    f = lambda x: np.exp(x)/(eps*np.exp(x)*np.sqrt(Xf(x)**2 - 1))
    I = quad(lambda u: f(xm + u*u)*2*u, 0, np.sqrt(lJ[-1] - xm), limit=800, epsabs=1e-12, epsrel=1e-11)[0]
    Jt = J[-1]   # tail: integrand -> 1/(2F) with F ~ e4 J^{4/3} - J
    ut = Jt**(-1/3)   # J = u^-3, dJ = -3 u^-4 du
    I += quad(lambda u: 3*u**-4/(2*(e4*u**-4 + e2*u**-2 - u**-3)), 0, ut, limit=200, epsabs=1e-14)[0]
    return nu*I
def Wmel(eps):
    Cm3, Cm2, Cm1 = laurent(eps)
    R = abs(Cm3*(1j*nu)**2/2 + Cm2*1j*nu + Cm1)
    return 2*np.pi*eps*nu*R*np.exp(-nuImt(eps))
def rd(f):
    o = {}
    for l in open(f):
        m = re.match(r'RESULT \S+ (\S+) (?:.* u0 \S+ )?(\S+) fitres', l)
        if m: o[float(m.group(1))] = float(m.group(2))
    return o
if os.environ.get('CHECK'):
    for e in (0.01, 0.003):
        D = nuImt(e) - (2/e)*np.arccos(e/8)/np.sqrt(1-e*e/64); print('eps %g  Delta - (17/9) ln(1/eps) = %.4f' % (e, D - 17/9*np.log(1/e)))
    raise SystemExit
W = rd(DATA+'mp_ME.txt')
for k, v in json.load(open(DATA+'MD.json')).items(): W.setdefault(float(k), v['W'])
es = sorted(W); rat = []
print('e4 %.8f e2 %.8f' % (e4, e2))
for e in es:
    wm = Wmel(e); rat.append(W[e]/wm); print('eps %.2f  W_ME %.6e  W_Mel(residue) %.6e  ratio %.5f' % (e, W[e], wm, W[e]/wm))
e = np.array(es); r = np.array(rat)
for n, d in ((len(e), 1), (len(e), 2), (4, 1), (4, 2)):
    print('extrapolation to eps=0 (%d points, degree %d): %.4f' % (n, d, np.polyfit(e[:n], r[:n], d)[-1]))
json.dump(dict(eps=es, ratio=rat, e4=e4, e2=e2), open(DATA+'me_residue.json', 'w'), indent=1)
