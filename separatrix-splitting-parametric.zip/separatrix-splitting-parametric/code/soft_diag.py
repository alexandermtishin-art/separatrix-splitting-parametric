import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Diagnostics for U<0 runs: fit failures at larger eps, cosine at eps>=0.16, u0/tolerance checks."""
import sys, numpy as np
sys.path.insert(0,HERE)
import split
from split import nu
from scipy.integrate import solve_ivp
b0=-4/3; U=-1.0; s=np.sqrt(8.0)
def monoM(eps):
    f=lambda t,y:(np.array([[0,1],[-(1+2*eps*np.cos(nu*t)),0]])@y.reshape(2,2)).ravel()
    M=solve_ivp(f,(0,split.Tp),np.eye(2).ravel(),rtol=1e-13,atol=1e-15,method='DOP853').y[:,-1].reshape(2,2)
    w,V=np.linalg.eig(M); i=np.argmax(abs(w)); eu=np.real(V[:,i]); es=np.real(V[:,1-i]); L=np.real(w[i])
    es=es/(eu[0]*es[1]-eu[1]*es[0]); return eu,es,L,np.log(abs(L))/split.Tp
split.monodromy=monoM
def rhs(model,eps,sv=0.0):
    if model=='M0':
        def f(t,y):
            q,p=y; n=0.5*(q*q+p*p); return [p*(1+U*n),-(1+2*eps*np.cos(nu*t))*q-U*n*q]
        return f
    if model=='P':
        return lambda t,y:[y[1],-np.sin(s*y[0])/s-2*eps*np.cos(nu*t)*y[0]]
    g=float(model[1:])
    return lambda t,y:[y[1],-(1+2*eps*np.cos(nu*t))*y[0]-b0*y[0]**3-g*y[0]**5]
split.rhs=rhs
def show(lab,model,eps,**kw):
    r=split.splitting(model,eps,nph=16,**kw)
    print('%-10s eps %.2f %s W1 %.5e W2/W1 %.2e res/W %.1e rmin %.3e'%(lab,eps,kw,r['W1'],abs(r['W2'])/abs(r['W1']),r['fitres']/abs(r['W1']),r['rmin']),flush=True)
what=sys.argv[1]
if what=='fail':
    for g in ['G%.12f'%(8/15),'G%.12f'%(26/15)]:
        for e in [0.16,0.20]: show(g[:6],g,e,u0=1e-6)
if what=='cos':
    for e in [0.16,0.20]: show('P',  'P',e,u0=1e-6); show('P0','M0',e,u0=1e-6)
if what=='conv':
    for lab,m,e in [('G17/15','G%.12f'%(17/15),0.16),('P','P',0.14),('M0','M0',0.14)]:
        show(lab,m,e,u0=1e-6); show(lab,m,e,u0=3e-7); show(lab,m,e,u0=1e-6,rtol=1e-12)
if what=='small':
    for e in [0.10,0.11,0.12,0.13]:
        for g in [8/15,17/15,26/15]: show('G%.4f'%g,'G%.12f'%g,e,u0=1e-6)
if what=='osc':
    for e in [0.095,0.105,0.115,0.125,0.135,0.15]: show('G1.7333','G%.12f'%(26/15),e,u0=1e-6)
if what=='osc2':
    for e in [0.1375,0.14,0.1425,0.145,0.1475,0.155]:
        r=split.splitting('G%.12f'%(26/15),e,nph=16,u0=1e-6)
        print('G26 eps %.4f W1 %.5e W2/W1 %.1e res/W %.1e rmin %.2e'%(e,r['W1'],abs(r['W2'])/abs(r['W1']),r['fitres']/abs(r['W1']),r['rmin']),flush=True)
    r=split.splitting('G%.12f'%(26/15),0.14,nph=16,u0=3e-7)
    print('G26 eps 0.1400 u0=3e-7 W1 %.5e'%r['W1'],flush=True)
if what in ('grid1','grid2'):
    es=np.round(np.arange(0.1025,0.1626,0.0025),4)
    es=es[0::2] if what=='grid1' else es[1::2]
    for e in es:
        if abs(e-0.145)<1e-9 or abs(e-0.14)<1e-9: continue
        r=split.splitting('G%.12f'%(26/15),e,nph=16,u0=1e-6)
        print('G26 eps %.4f W1 %.5e W2/W1 %.1e res/W %.1e rmin %.2e'%(e,r['W1'],abs(r['W2'])/abs(r['W1']),r['fitres']/abs(r['W1']),r['rmin']),flush=True)
if what in ('g17a','g17b'):
    es=[0.165,0.17,0.175,0.18,0.185,0.19,0.195,0.205,0.21,0.215,0.22,0.225,0.23,0.235,0.245,0.25,0.255,0.26]
    es=es[0::2] if what=='g17a' else es[1::2]
    for e in es:
        r=split.splitting('G%.12f'%(17/15),e,nph=16,u0=1e-6)
        print('G17 eps %.4f W1 %.5e W2/W1 %.1e res/W %.1e rmin %.2e'%(e,r['W1'],abs(r['W2'])/abs(r['W1']),r['fitres']/abs(r['W1']),r['rmin']),flush=True)
