"""Stokes constant of the inner problem by quadrature: C1 = C1_dir + C1_cross with C1_dir = 4 pi/3 exactly and
C1_cross = int_{line} e^{2 i sigma} [Phi^{-1}(sigma) S_cross(sigma)]_1 d sigma, Im sigma = -c."""
import os, sys, numpy as np
from scipy.integrate import solve_ivp, quad
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from inner_ode import U, Phii, Ym2
def X4_dense(c, R):
    def f(x, y):
        t = x - 1j*c; a, b = y
        return [(-U*t*a + 2*t*b - 1j)/(U*t*t) - 4j*a, (U*t*a - 0.5j)/(t*t) - 4j*b]
    t0 = -R - 1j*c
    y0 = np.array([-1j/U, -0.5j])/(4j*t0*t0)
    return solve_ivp(f, (-R, R), y0, method='DOP853', rtol=1e-13, atol=1e-17, dense_output=True).sol
def Scross(t, x4):
    x4N, x4w = x4; ymN, ymw = Ym2(t)
    fN = -2j*x4N*ymw - 2j*x4w*ymN - ymN/t + 2*ymw/(U*t)
    fw = 2j*U*x4N*ymw + 2j*U*x4w*ymN + 4j*x4w*ymw + 1j*x4w + 2*ymw/t
    return np.array([fN, fw])
def C1cross(c, R):
    X = X4_dense(c, R)
    g = lambda x: (Phii(x - 1j*c) @ Scross(x - 1j*c, X(x)))[0] * np.exp(2*c)   # times e^{2ix}
    # e^{2i sigma} = e^{2ix} e^{2c}
    re = lambda x: g(x).real; im = lambda x: g(x).imag
    kw = dict(limit=4000, epsabs=1e-13, epsrel=1e-12)
    I = 0
    for fun, mult in ((re, 1), (im, 1j)):
        Ic = quad(fun, -R, R, weight='cos', wvar=2.0, **kw)[0]
        Is = quad(fun, -R, R, weight='sin', wvar=2.0, **kw)[0]
        I += mult*(Ic + 1j*Is)
    return I
if __name__ == '__main__':
    dir_ = 4*np.pi/3
    for c in [float(a) for a in sys.argv[1:]] or [4.0, 5.0, 6.0]:
        for R in (500.0, 2000.0):
            cc = C1cross(c, R)
            print('c=%.1f R=%6.0f  C1_cross=%.8f%+.8fj  ratio=%.8f%+.8fj' % (c, R, cc.real, cc.imag, ((dir_+cc)/dir_).real, ((dir_+cc)/dir_).imag), flush=True)
