# Separatrix splitting of parametrically pumped oscillators beyond the Kerr approximation

Code and data for the manuscript of the same title (A.M. Tishin).

Requirements: Python 3.10+, numpy, scipy, numba, mpmath (with gmpy2 for speed), sympy, matplotlib.

## Layout

- `code/` — all scripts. Paths are relative to the package root; data are written to `data/`.
- `data/` — numerical results used in the tables and figures.
- `figures/` — figures of the manuscript.

## What reproduces what

| Result | Script | Output |
|---|---|---|
| Direct splitting, double precision (Sec. 3; Tables 1, 2, 5; Fig. 2) | `split.py`, `gather.py` | `data/splitting.json` |
| Direct splitting, 34-digit Taylor integrator (Tables 1, 2) | `split_mp.py`, `run_mp.sh` (`bash run_mp.sh M`, `bash run_mp.sh M0`) | `data/mp_M.txt`, `data/mp_M0.txt` |
| Phase-invariant oscillator M_E with the Duffing energy–action law (Tables 1–3) | `model_MD.py`, `run_MD.py` | `data/MD.json` |
| Action–angle Melnikov integral, Eq. (10) (Sec. 5, Table 2) | `ell_exact.py`, `ell_cheb.py`, `ell_h2.py`, `ell_D.py`, `gather_theory.py` | `data/theory.json` |
| m = 4 channel check (Sec. 5.2) | `channel4.py` | `data/channel4.txt` |
| Second-order static term, Duffing frequency check (App. B) | `heff.py` | printed |
| Singular time, Eqs. (11)–(14), Table 3 (c0, a1, b1, d1 from `data/resid_small.json`), Fig. 3 | `imtstar_exact.py`, `imt_sextic.py`, `param_free.py`, `imt_small.py`, `fig_data2.py` | `data/singular_time.txt`, `data/resid_small.json`, `data/fig_data2.json` |
| Sextic oscillators (Table 3) | `test_sextic.py`, `test_sextic_neg.py` | `data/sextic.txt`, `data/sextic_neg.txt` |
| Layer width (Table 4) | `width.py` (`python3 code/width.py all 200000`) | `data/width_all.json`, `data/width_all.txt` |
| Passage times and Lyapunov exponents, flow (Table 5, App. C) | `table5_y8.py` (`python3 code/table5_y8.py 40 1e-4 all`; checks: `80 1e-4 M20`, `80 1e-4 M24`, `40 1e-5 M20`, `40 1e-3 M20`), `lyap8.py` | `data/table5_y8_*.json`, `data/table5_y8_*.txt` |
| Passage times and Lyapunov exponents, separatrix map (Table 5) | `map_full.py` | printed |
| Kerr-separatrix Melnikov quadratures | `melD.py`, `melS.py` | in `data/splitting.json` |
| Softening nonlinearity, U < 0 (Sec. 6.3, Table 6, Fig. 4) | `test_soft.py`, `test_pendulum.py`, `soft_diag.py` (`small`, `fail`, `conv`, `osc`, `osc2`, `grid1`, `grid2`, `g17a`, `g17b`), `imt_pend.py`, `fig4.py` | `data/soft.json`, `data/pendulum.txt`, `data/soft_diag_*.txt`, `data/soft_grid*.txt`, `data/soft_all.json`, `data/table6_rows.md` |
| Softening cases in 34 digits | `split_mp2.py` with beta = -4/3 | `data/mp_soft*.txt`, `data/mp_g26_010.txt` |
| Model D in 34 digits (Sec. 5.3) | `split_mp2.py D eps 16` | `data/mp_D.txt` |
| Free frequency of the softening sextic oscillators, secondary resonance, reconnection estimate and lobe excursion (Sec. 6.3) | `soft_actions.py`, `soft_lobe.py`, `soft_reconnect.py` | printed |
| Lobe area of the separatrix, map vs K0 (App. B) | `lobe_area.py` (`python3 code/lobe_area.py 0.10 0.12 0.14 0.16 0.24`) | `data/lobe_area.txt` |
| 34-digit integrator with sextic term, arbitrary beta, model D | `split_mp2.py` (`python3 code/split_mp2.py M\|M0\|D eps nph [beta gamma dps]`) | printed |
| Decomposition of the second-order static term (Sec. 5.3) | `h2_diag.py` | printed |
| Layer width from the separatrix map (Table 4) | `map_width.py` | printed |
| Figures | `fig_data.py`, `fig_data2.py`, `figs2.py`, `fig4.py` | `figures/` |

Units: small-amplitude frequency 1, pump frequency 2, Kerr coefficient U = 1 (beta = 4/3).

## License

MIT (see `LICENSE`).
