from fractions import Fraction as F
import json,sys
from pathlib import Path
import verify_wide as v
from verify_charts import point, interval, ZERO
from mpmath import iv


path=Path(sys.argv[1])/'full_contour/data'
reference=json.loads((path/'closed-contour-certificate.json').read_text())
assert reference["closed_seam"]
assert reference["robust_box"]["incoming_lobes"]==2
assert tuple(map(F,reference["robust_box"]["center"]))==v.CENTER
amp_limit,phi_limit=map(F,reference["robust_box"]["half_width"])
assert reference["anchors"]["top"]["incoming_lobes"]==1
panels=[]
for i,c in enumerate(v.Q_CENTERS):
    v.RQ=F('.0065') if i==13 else F('.0052')
    arcs=[v.chart(json.loads((path/f'wide-{i:02d}-{a}.json').read_text())) for a in (0,1)]
    panels.append((c,v.RQ,arcs[0][0]+arcs[1][0],arcs))

def fmt(a):
    return tuple(f'{float(y):.8e}' for y in (a.a,a.b))

def graph(q):
    return min(panels,key=lambda row:abs(row[0]-q))

def gap(q,w):
    c,r,d,_=graph(q)
    return v.derivative(d,(0,0,0),(point((q-c)/r),amp,w))

def sign(x):
    return int(x.a>0)-int(x.b<0)

def roots(w, count):
    brackets=[]
    past=None
    for i in range(173):
        q=F('.203')+F('.0005')*i
        s=sign(gap(q,w))
        if not s:continue
        if past and s!=past[1]:
            brackets.append((past[0],q,past[1]))
        past=(q,s)
    assert len(brackets)==count, (str(w),brackets)
    out=[]
    for a,b,left in brackets:
        for _ in range(15):
            changed=False
            for x in ((a+b)/2,(3*a+b)/4,(a+3*b)/4):
                s=sign(gap(x,w))
                if s==left and a<x:
                    a=x
                    changed=True
                elif s==-left and x<b:
                    b=x
                    changed=True
            if not changed:break
        out.append(interval(a,b))
    return out

def add_image(first,w):
    c,r,d,arcs=panels[1]
    z=(first-point(c))/point(r)
    assert abs(z).b<1
    x,y=[point(a[3]['x_center'])+point(v.RX)*v.derivative(a[1],(0,0,0),(z,amp,w)) for a in arcs]
    c,r,d,arcs=panels[-1]
    xi,yi=[(u-point(a[3]['x_center']))/point(v.RX) for u,a in zip((x+point('.5'),y-point('.5')),arcs)]
    assert all(abs(t).b<point(v.REAL_X).a for t in (xi,yi))
    q=v.derivative(arcs[0][2],(0,0,0),(xi,amp,w))
    assert abs((q-point(c))/point(r)).b<1
    assert q.a>point('.2945').b
    # Existing sign proof covers all q up to .2945. Verify monotonicity
    # on the extension, so its image root is the only further crossing.
    normalized=(iv.mpf([point('.2945').a,q.b])-point(c))/point(r)
    assert sign(v.derivative(d,(1,0,0),(normalized,amp,w)))
    return q

def area(a,b,w,dphi=False):
    total=ZERO
    for i,(c,r,d,_) in enumerate(panels):
        left=point(c-v.Q_HALF)
        right=point(c+v.Q_HALF) if i<len(panels)-1 else point(c+r)
        if b.b<=left.a or a.a>=right.b:continue
        lo=iv.mpf([max(a.a,left.a),max(a.b,left.b)])
        hi=iv.mpf([min(b.a,right.a),min(b.b,right.b)])
        l,h=[(x-point(c))/point(r) for x in (lo,hi)]
        assert max(abs(l).b,abs(h).b)<1
        terms = ((n,i,j-1,k*j) for (n,i,j),k in d.p.items() if j) if dphi else (
                 (n,i,j,k) for (n,i,j),k in d.p.items())
        val=sum((k*amp**i*w**j*(h**(n+1)-l**(n+1))/(n+1)
                 for n,i,j,k in terms),ZERO)*point(r)
        error = d.error/(1-abs(w).b) if dphi else d.error
        enclosed=val+error*(hi-lo)*iv.mpf([-1,1])
        if hi.a<=lo.b:
            enclosed=iv.mpf([min(ZERO,enclosed.a),max(ZERO,enclosed.b)])
        total+=enclosed
    return total

cases = [('center','-.05e-6','.05e-6',4),('edge','2.60e-6','2.65e-6',4),
         ('exterior','9.5e-6','9.5e-6',2)]
cases += [(f'scan-{i:02d}', F('-.05e-6')+F('1e-7')*i, F('-.05e-6')+F('1e-7')*(i+1),4)
          for i in range(27)]
for name,phi_a,phi_b,count in cases:
    if name=='exterior':
        assert F(phi_a)==F(phi_b)==v.CONTROL*v.SCALES[1]
    else:
        assert F('5e-8')<=amp_limit
        assert max(abs(F(phi_a)),abs(F(phi_b)))<=phi_limit
    w=interval(phi_a,phi_b)/point(v.SCALES[1])
    amp=(interval('-.05e-6','.05e-6') if name!='exterior' else ZERO)/point(v.SCALES[0])
    rts=roots(w,count)
    for i,xx,root,before in [(0,'-.88',rts[0],True),(13,'-.38',rts[-1],False)]:
        c,r,d,arcs=panels[i]
        q_arc=arcs[0]
        x=(point(xx)-point(q_arc[3]['x_center']))/point(v.RX)
        q=v.derivative(q_arc[2],(0,0,0),(x,amp,w))
        assert q.b<root.a if before else root.b<q.a
        if not before:
            assert q.a>point('.289').b
    rts.append(add_image(rts[0],w))
    for i in range(70):
        a,b=(F('.289')+F('.0055')*F(j,70) for j in (i,i+1))
        c,r,d,_=panels[-1]
        assert sign(v.derivative(d,(0,0,0),(interval((a-c)/r,(b-c)/r),amp,w)))
    areas=[area(a,b,w) for a,b in zip(rts[:-1],rts[1:])]
    assert all(sign(a) for a in areas)
    inc=[a for a in areas if a.a>0]
    assert 2*len(inc)==count
    total=sum(inc,ZERO)
    shares=[]
    for i,a in enumerate(inc):
        others=sum((b for j,b in enumerate(inc) if i!=j),ZERO)
        shares.append(iv.mpf([(a.a/(a.a+others.b)).a,(a.b/(a.b+others.a)).b]))
    if name=='center':
        assert all(s.a>point('.478').b and s.b<point('.522').a for s in shares)
        assert total.a>point('1.113e-12').b and total.b<point('1.215e-12').a
    if name=='edge':
        assert shares[1].a>point('.779').b and shares[1].b<point('.821').a
        assert total.a>point('1.234e-12').b and total.b<point('1.354e-12').a
    if not name.startswith('scan'):
        print(name,'roots',list(map(fmt,rts)),flush=True)
        print(name,'lobes',list(map(fmt,areas)),'total',fmt(total),'shares',list(map(fmt,shares)),flush=True)

    slopes=[area(a,b,w,True)/point(v.SCALES[1])
            for a,b,z in zip(rts[:-1],rts[1:],areas) if z.a>0]
    if count==4:
        assert slopes[0].b<0<slopes[1].a
    print(name, 'area slopes per radian',list(map(fmt,slopes)),flush=True)
