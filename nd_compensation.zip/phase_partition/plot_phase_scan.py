"""Plot interval enclosures of the two incoming lobe areas and their sum."""
import argparse
import csv
from decimal import Decimal
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.ticker import MultipleLocator
import numpy as np


SERIES = (
    ("a1", r"First lobe $A_1$", "#0072B2"),
    ("a2", r"Second lobe $A_2$", "#D55E00"),
    ("a_total", r"Total $A_1+A_2$", "#3C4250"),
)


def load_scan(path):
    with path.open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    expected = [f"scan-{i:02d}" for i in range(27)]
    if [r["cell"] for r in rows] != expected:
        raise ValueError("Expected 27 ordered phase cells")
    lower = [Decimal(r["phi_low_rad"]) for r in rows]
    upper = [Decimal(r["phi_high_rad"]) for r in rows]
    if lower[1:] != upper[:-1] or any(a >= b for a, b in zip(lower, upper)):
        raise ValueError("Phase cells must form a contiguous ordered partition")
    edges = 1e6 * np.asarray([float(p) for p in [*lower, upper[-1]]])
    return rows, edges


def draw_scan(rows, edges, output):
    plt.rcParams.update({
        "font.family": "DejaVu Serif",
        "mathtext.fontset": "dejavuserif",
        "font.size": 10.5,
        "axes.labelsize": 11,
        "axes.linewidth": .75,
        "xtick.major.size": 4,
        "ytick.major.size": 4,
        "pdf.fonttype": 42,
    })
    fig, ax = plt.subplots(figsize=(6.4, 3.34))
    fig.subplots_adjust(left=.12, right=.982, bottom=.174, top=.84)
    ax.set_axisbelow(True)
    ax.grid(axis="y", color="#D4D9DF", linewidth=.55, alpha=.82)
    ax.spines[["top", "right"]].set_visible(False)
    for key, _, color in SERIES:
        bounds = 1e12 * np.asarray([
            [float(row[f"{key}_low"]), float(row[f"{key}_high"])] for row in rows
        ])
        if not np.all(np.isfinite(bounds)) or np.any(bounds[:, 0] > bounds[:, 1]):
            raise ValueError(f"Invalid bounds for {key}")
        low, high = bounds.T
        ax.fill_between(edges, np.r_[low, low[-1]], np.r_[high, high[-1]],
                        step="post", color=color, alpha=.22, linewidth=0)
        for bound in (low, high):
            ax.stairs(bound, edges, baseline=None, color=color, linewidth=.9)
    ax.set(xlim=(edges[0]-.04, edges[-1]+.04), ylim=(0, 1.48),
           xlabel=r"Relative pump phase $\phi$ ($\mu$rad)",
           ylabel=r"Incoming lobe area ($10^{-12}$)")
    ax.xaxis.set_major_locator(MultipleLocator(.5))
    ax.yaxis.set_major_locator(MultipleLocator(.25))
    ax.tick_params(direction="out", width=.75, pad=4)
    handles = [Patch(facecolor=matplotlib.colors.to_rgba(color, .22),
                     edgecolor=color, linewidth=.9, label=label)
               for _, label, color in SERIES]
    ax.legend(handles=handles, loc="lower center", bbox_to_anchor=(.50, 1.025),
              ncols=3, frameon=False, borderaxespad=0, columnspacing=2.25,
              handlelength=1.55, handleheight=.73)
    fig.savefig(output.with_suffix(".png"), dpi=450, facecolor="white")
    fig.savefig(output.with_suffix(".pdf"), facecolor="white")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data", type=Path)
    parser.add_argument("output", type=Path, help="Output file stem")
    args = parser.parse_args()
    rows, edges = load_scan(args.data)
    draw_scan(rows, edges, args.output)


if __name__ == "__main__":
    main()
