"""Export outward-rounded plot data from the archived phase-partition replay."""
import argparse
import contextlib
import csv
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from hashlib import sha256
import importlib.util
import io
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


def decimal_endpoint(value, upper=False):
    """Convert an exact binary interval endpoint to an outward decimal bound."""
    negative, mantissa, exponent, _ = value
    with localcontext() as ctx:
        ctx.prec = 20
        ctx.rounding = ROUND_CEILING if upper else ROUND_FLOOR
        numerator = Decimal(-mantissa if negative else mantissa)
        if exponent >= 0:
            return str(Decimal(int(numerator) << exponent))
        return str(numerator / Decimal(1 << -exponent))


def outward(value):
    lower, upper = value._mpi_
    return decimal_endpoint(lower), decimal_endpoint(upper, upper=True)


def read_archive(archive, root):
    with ZipFile(archive) as zf:
        manifest = json.loads(zf.read("MANIFEST_SHA256.json"))
        for name in ("check_flux.py", "verify_parameter_window.py", "ESM_2_v5.zip", "replay.log"):
            data = zf.read(name)
            if sha256(data).hexdigest() != manifest[name]:
                raise ValueError(f"SHA-256 mismatch for {name}")
            (root / name).write_bytes(data)
    helper = root / "verify_parameter_window.py"
    spec = importlib.util.spec_from_file_location("parameter_window", helper)
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    return verifier.unpack(root / "ESM_2_v5.zip", root / "source")


def read_package(root):
    manifest = json.loads((root / "MANIFEST_SHA256.json").read_text())
    for name, digest in manifest.items():
        if name.startswith(("certified_contour/", "phase_partition/")):
            if sha256((root / name).read_bytes()).hexdigest() != digest:
                raise ValueError(f"SHA-256 mismatch for {name}")
    return root / "certified_contour", root / "phase_partition"


def collect(source, root):
    lines = []
    code = (root / "check_flux.py").read_text()
    anchor = "    if count==4:\n        assert slopes[0].b<0<slopes[1].a\n"
    if code.count(anchor) != 1:
        raise ValueError("Expected one phase derivative check in the archived verifier")
    instrumented = code.replace(anchor, anchor + (
        "    if name.startswith('scan-'):\n"
        "        phase_rows.append((name, phi_a, phi_b, inc, total, shares, slopes))\n"
    ))
    sys.path.insert(0, str(source / "full_contour" / "code"))
    sys.argv = ["check_flux.py", str(source)]
    log = io.StringIO()
    with contextlib.redirect_stdout(log):
        exec(compile(instrumented, str(root / "check_flux.py"), "exec"), {"phase_rows": lines})
    if log.getvalue() != (root / "replay.log").read_text():
        raise ValueError("Archived phase replay and the instrumented run differ")
    if len(lines) != 27:
        raise ValueError(f"Expected 27 phase cells, found {len(lines)}")
    return lines


def write_csv(destination, rows):
    header = ["cell", "phi_low_rad", "phi_high_rad"]
    for name in ("a1", "a2", "a_total", "a2_share", "a1_slope", "a2_slope"):
        header.extend((f"{name}_low", f"{name}_high"))
    with destination.open("w", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(header)
        for name, lo, hi, (a1, a2), total, (_, share2), (slope1, slope2) in rows:
            endpoints = [str(Decimal(q.numerator) / Decimal(q.denominator)) for q in (lo, hi)]
            writer.writerow([name, *endpoints, *(bound for quantity in
                            (a1, a2, total, share2, slope1, slope2) for bound in outward(quantity))])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, help="Original phase archive or unpacked ESM package root")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.source.is_dir():
        source, phase = read_package(args.source.resolve())
        write_csv(args.output, collect(source, phase))
    else:
        with TemporaryDirectory() as path:
            root = Path(path)
            source = read_archive(args.source, root)
            write_csv(args.output, collect(source, root))


if __name__ == "__main__":
    main()
