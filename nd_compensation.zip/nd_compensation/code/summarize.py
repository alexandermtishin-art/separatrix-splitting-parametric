"""Check mapped crossings and compare direct areas with the frozen model."""
from decimal import Decimal as D, localcontext
import json
import math
from pathlib import Path

DATA = Path(__file__).resolve().parents[1] / "data"


def read(name):
    return json.loads((DATA/(name+".json")).read_text())


def measure(run):
    roots = list(map(D,run["roots"]))
    areas = list(map(D,run["signed_lobe_areas"]))
    assert all(x*y<0 for x,y in zip(areas,areas[1:]))
    pairs = run["root_pairing"]
    assert pairs, "No complete fundamental interval"
    spans = {pair["image_index"]-pair["index"] for pair in pairs}
    assert spans in ({2},{4}), spans
    errors = [D(pair["q_error"])+D(pair["p_error"]) for pair in pairs]
    relative_pairing_error = max(errors)/min(b-a for a,b in zip(roots,roots[1:]))
    assert relative_pairing_error < D("0.02"), relative_pairing_error
    cycles = [areas[pair["index"]:pair["image_index"]] for pair in pairs]
    incoming = [sum(a for a in cycle if a>0) for cycle in cycles]
    return {
        "incoming_lobes": spans.pop()//2,
        "complete_intervals": len(cycles),
        "incoming_area": sum(incoming)/len(incoming),
        "area_spread": max(incoming)-min(incoming),
        "root_mapping_error": max(errors),
        "root_mapping_error_over_min_spacing": relative_pairing_error,
        "arc_check_error": D(run["interpolation_pointcheck_error"]),
    }


def model_area(p, c):
    a,b = (2*float(p[k]) for k in ("normalized_a","normalized_b"))
    n = 32768
    total = 0.
    for j in range(n):
        t = (j+.5)*math.tau/n
        total += max(0., a*math.sin(t)+b*math.cos(t)+math.sin(2*t))
    return c*D(str(total*math.pi/n))


def main():
    with localcontext() as ctx:
        ctx.prec = 58
        plan=read("frozen_protocol")
        c=D(plan["calibration"]["local_W2"])
        followup=DATA/"frozen_followup.json"
        if followup.is_file():
            plan["points"].update(read("frozen_followup"))
        out={}
        for name,p in plan["points"].items():
            nominal=(DATA/(name+".json")).is_file()
            refined=(DATA/(name+"_refined.json")).is_file()
            if not (nominal or refined):
                continue
            result=measure(read(name+"_refined" if refined else name))
            if nominal and refined:
                base=measure(read(name))
                result["relative_refinement"]=abs(base["incoming_area"]-result["incoming_area"])/result["incoming_area"]
                result["same_count_on_refinement"]=base["incoming_lobes"]==result["incoming_lobes"]
            if "predicted_incoming_lobes" in p:
                predicted=model_area(p,c)
                result["model_area"]=predicted
                result["relative_model_error"]=abs(predicted-result["incoming_area"])/result["incoming_area"]
                result["predicted_count"]=p["predicted_incoming_lobes"]
            out[name]=result
        print(json.dumps(out,indent=2,default=str))


if __name__=="__main__":
    main()
