from pathlib import Path
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
plan=json.loads((ROOT/"data/frozen_protocol.json").read_text())["points"]
summary=json.loads((ROOT/"data/summary.json").read_text())
fig,(ax,bx)=plt.subplots(1,2,figsize=(8,4),layout="constrained")
fig.suptitle("Counter-rotating pump control of separatrix transport", fontsize=14, weight="bold")
labels=[r"$1$",r"$6/7$",r"$\rho_{\mathrm{pred}}$",r"$\rho_0$"]
areas=[4.5953552e-8,5.7579023e-10,1.3523773e-11,1.1643086e-12]
colors=["#8b95a3","#8b95a3","#1b6b8f","#a37338"]
ax.bar(labels,np.array(areas)-1e-13,bottom=1e-13,color=colors,width=.63)
ax.set_yscale("log")
ax.set_ylim(1e-13,1e-7)
ax.set_title(r"Incoming area per period at $\epsilon=0.20$", fontsize=11)
ax.set_xlabel("Pump setting")
ax.set_ylabel("Canonical area")
ax.grid(axis="y",alpha=.22)
ax.annotate("42.58-fold vs 6/7",xy=(2,areas[2]),xytext=(.96,4.4e-9),
            color="#1b6b8f",fontsize=9,arrowprops={"arrowstyle":"->","color":"#1b6b8f"})
t=np.linspace(0,2*np.pi,512)
bx.fill(np.cos(t)**3,np.sin(t)**3,color="#e7f0f7",zorder=0)
bx.plot(np.cos(t)**3,np.sin(t)**3,color="#445367",lw=1.4,label="Two-harmonic boundary")
for name,p in plan.items():
    if "normalized_a" not in p or name not in summary:
        continue
    n=summary[name]["incoming_lobes"]
    bx.scatter(float(p["normalized_a"]),float(p["normalized_b"]),s=31,
               color="#1b6b8f" if n==2 else "#a34b27",marker="o" if n==2 else "s",zorder=3)
bx.scatter([],[],s=31,color="#1b6b8f",label="2 incoming lobes")
bx.scatter([],[],s=31,color="#a34b27",marker="s",label="1 incoming lobe")
bx.set(xlim=(-1.16,1.43),ylim=(-1.12,1.45),aspect="equal",
       xlabel=r"Amplitude error $a/(2c)$",ylabel=r"Phase error $b/(2c)$")
bx.set_title("Predicted boundary and full-flow checks",fontsize=11)
bx.legend(fontsize=7.5,loc="lower left",framealpha=.95,edgecolor="none")
for axis in (ax,bx):
    axis.spines[["top","right"]].set_visible(False)
fig.savefig(ROOT/"Graphical_Abstract_Nonlinear_Dynamics.png",dpi=200,facecolor="white")
