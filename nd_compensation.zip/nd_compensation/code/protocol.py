"""Freeze point predictions, then run geometry at those points."""
from concurrent.futures import ProcessPoolExecutor
from decimal import Decimal as D, getcontext
import argparse
import json
from pathlib import Path

from lobe_area import compute

DATA = Path(__file__).resolve().parents[1] / "data"


def plan():
    getcontext().prec = 75
    rho0 = D("0.855429150290891485620876648735970618556058078946733")
    c = D("1.1643086389833e-12")
    rho_axis = 2*c/D("3.362e-7")
    phi_axis = 2*c/D("2.960e-7")
    points = {}
    for cut, a, b in (("amplitude", D(1), D(0)), ("phase", D(0), D(1)),
                      ("diagonal", 1/(2*D(2).sqrt()), 1/(2*D(2).sqrt()))):
        levels = ("0.7", "1.3") if cut != "diagonal" else ("0.7", "0.97", "1.03", "1.3")
        for level in levels:
            k = D(level)
            points[cut + "_" + level.replace(".", "")] = {
                "epsilon": "0.20", "rho": str(rho0 + k*a*rho_axis),
                "phase": str(k*b*phi_axis), "detuning": "0",
                "predicted_incoming_lobes": 2 if k<1 else 1,
                "astroid_ray_fraction": level, "normalized_a": str(k*a),
                "normalized_b": str(k*b),
            }
    for e, labels, matched in (("0.16", ("original", "leading", "predicted"), False),
                               ("0.20", ("leading", "predicted"), True)):
        epsilon = D(e)
        for label in labels:
            rho = {"original":D(1), "leading":D(6)/7,
                   "predicted":D(6)/7-D("0.0438483117759323797304930479039366131895338584871905612877561723")*epsilon**2}[label]
            points[("matched_" if matched else "depth016_")+label] = {
                "epsilon": e, "rho": str(rho), "phase": "0",
                "detuning": str((rho*rho-1)*epsilon**2/16 if matched else D(0)),
            }
    return {"calibration": {"rho0":str(rho0), "rho_axis":str(rho_axis),
                            "phi_axis":str(phi_axis), "local_W2":str(c)},
            "criteria": "Held-out lobe counts; incoming area within 10 percent at 0.7/1.3 of predicted boundary; near-boundary points diagnostic.",
            "points":points}


def run(item):
    name, p, refined = item
    label = name + ("_refined" if refined else "")
    print("START", label, flush=True)
    result = compute(p["epsilon"], p["rho"], phase=p["phase"], detuning=p["detuning"],
                     degree=48 if refined else 36, dps=55 if refined else 48,
                     order=42 if refined else 34, steps=12 if refined else 8,
                     launch="1e-12" if refined else "1e-10")
    (DATA/(label+".json")).write_text(json.dumps(result,indent=2)+"\n")
    print("DONE", label, len(result["roots"]), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("cases", nargs="*")
    parser.add_argument("--refined",action="store_true")
    parser.add_argument("--freeze",action="store_true")
    parser.add_argument("--workers",type=int,default=8)
    args=parser.parse_args()
    path=DATA/"frozen_protocol.json"
    if args.freeze:
        with path.open("x") as output:
            json.dump(plan(),output,indent=2)
    else:
        points=json.loads(path.read_text())["points"]
        followup=DATA/"frozen_followup.json"
        if followup.is_file():
            points.update(json.loads(followup.read_text()))
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            list(pool.map(run, ((name,points[name],args.refined) for name in args.cases or points)))
