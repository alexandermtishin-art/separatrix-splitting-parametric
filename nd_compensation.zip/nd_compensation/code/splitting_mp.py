"""Direct Taylor integration of H_rho using gmpy2 MPFR arithmetic.

Exploratory research. Energy coordinate hF*u*s is local, not an exact
global splitting invariant; higher harmonics need a separate audit.
"""
import argparse
import json
import time
from pathlib import Path

import gmpy2 as g


class Integrator:
    def __init__(self, eps, rho, dps=40, order=36, steps=12, detuning='0',phase='0'):
        g.get_context().precision = int(dps*3.321928094887363)+16
        self.dps=dps;self.order=order;self.steps=steps
        self.eps=g.mpfr(eps);self.rho=g.mpfr(rho)
        self.detuning=g.mpfr(detuning)
        self.phase=g.mpfr(phase);self.cphase=g.cos(self.phase);self.sphase=g.sin(self.phase)
        self.pi=g.const_pi();self.dt=self.pi/steps
        self.zero=g.mpfr(0);self.one=g.mpfr(1)

    def step(self,q,p,c,s,linear=False):
        Q=[q];P=[p];C=[c];S=[s];NN=[]
        a=self.eps/2
        b=self.rho*self.eps/2
        w=1+self.detuning
        for k in range(self.order):
            cp=sum((C[j]*P[k-j] for j in range(k+1)),self.zero)
            cq=sum((C[j]*Q[k-j] for j in range(k+1)),self.zero)
            sq=sum((S[j]*Q[k-j] for j in range(k+1)),self.zero)
            sp=sum((S[j]*P[k-j] for j in range(k+1)),self.zero)
            if linear:
                pn=nq=self.zero
            else:
                NN.append(sum((Q[j]*Q[k-j]+P[j]*P[k-j]
                               for j in range(k+1)),self.zero)/2)
                pn=sum((P[j]*NN[k-j] for j in range(k+1)),self.zero)
                nq=sum((Q[j]*NN[k-j] for j in range(k+1)),self.zero)
            cpf=cp*self.cphase-sp*self.sphase
            cqf=cq*self.cphase-sq*self.sphase
            sqf=sq*self.cphase+cq*self.sphase
            spf=sp*self.cphase+cp*self.sphase
            Q.append((w*P[k]-pn+a*(cp-sq)+b*(-cpf+sqf))/(k+1))
            P.append((-w*Q[k]+nq-3*a*cq+a*sp-b*(cqf+spf))/(k+1))
            C.append(-2*S[k]/(k+1));S.append(2*C[k]/(k+1))
        def ev(x):
            v=x[-1]
            for a in reversed(x[:-1]):v=v*self.dt+a
            return v
        return ev(Q),ev(P),ev(C),ev(S)

    def strobe(self,q,p,linear=False):
        c,s=self.one,self.zero
        for _ in range(self.steps):q,p,c,s=self.step(q,p,c,s,linear)
        return q,p

    def floquet(self):
        a,c=self.strobe(self.one,self.zero,True)
        b,d=self.strobe(self.zero,self.one,True)
        det=a*d-b*c;tr=a+d
        disc=g.sqrt(tr*tr/4-det)
        l1=tr/2+disc;l2=tr/2-disc
        lu=l1 if abs(l1)>abs(l2) else l2;ls=det/lu
        eu=[b,lu-a];norm=g.sqrt(eu[0]**2+eu[1]**2)
        eu=[x/norm for x in eu]
        if eu[0]<0:eu=[-x for x in eu]
        es=[b,ls-a];om=eu[0]*es[1]-eu[1]*es[0]
        es=[x/om for x in es]
        return eu,es,lu,g.log(abs(lu))/self.pi,det

    def measure(self,nph=8,u0='1e-10',harmonics=3):
        eu,es,lu,hf,det=self.floquet();u0=g.mpfr(u0)
        lnlu=g.log(abs(lu));values=[];return_radii=[]
        start=time.time()
        for j in range(nph):
            uu=u0*g.exp(lnlu*j/nph);q,p=uu*eu[0],uu*eu[1]
            left=False;prev2=prev=None
            for k in range(3000):
                q,p=self.strobe(q,p)
                r2=q*q+p*p
                if r2>g.mpfr('.04'):left=True
                if left:
                    u=q*es[1]-p*es[0];s=eu[0]*p-eu[1]*q
                    item=(r2,u*s)
                    if prev2 is not None and prev[0]<prev2[0] and prev[0]<r2 and prev[0]<g.mpfr('.0009'):
                        values.append(prev[1]);return_radii.append(g.sqrt(prev[0]));break
                    prev2,prev=prev,item
            else:raise RuntimeError('No return')
            print('PHASE',j,format(values[-1],'.18g'),'seconds',round(time.time()-start,2),flush=True)
        mean=sum(values,self.zero)/nph;co=[]
        for m in range(1,harmonics+1):
            sn=2*sum((v*g.sin(2*self.pi*j*m/nph) for j,v in enumerate(values)),self.zero)/nph
            cs=2*sum((v*g.cos(2*self.pi*j*m/nph) for j,v in enumerate(values)),self.zero)/nph
            co.append((hf*sn,hf*cs))
        residual=self.zero
        for j,v in enumerate(values):
            approx=mean+sum(((sn*g.sin(2*self.pi*j*m/nph)+cs*g.cos(2*self.pi*j*m/nph))/hf
                             for m,(sn,cs) in enumerate(co,1)),self.zero)
            residual=max(residual,hf*abs(v-approx))
        h=g.sqrt((self.eps/2)**2-(self.rho**2*self.eps**2/16-self.detuning)**2)
        alpha=g.acos((self.rho**2*self.eps**2/16-self.detuning)/(self.eps/2))
        mel=4*self.pi*self.eps*g.sinh(alpha/h)/g.sinh(self.pi/h)
        fmt=lambda x:format(x,'.35g')
        return dict(eps=fmt(self.eps),rho=fmt(self.rho),dps=self.dps,
                    order=self.order,steps=self.steps,u0=fmt(u0),nph=nph,
                    detuning=fmt(self.detuning),phase=fmt(self.phase),hF=fmt(hf),monodromy_det_error=fmt(det-1),
                    harmonics=[dict(sine=fmt(a),cosine=fmt(b),amplitude=fmt(g.sqrt(a*a+b*b))) for a,b in co],
                    residual=fmt(residual),mean=fmt(hf*mean),melnikov_reference=fmt(mel),
                    normalized_first=fmt(g.sqrt(co[0][0]**2+co[0][1]**2)/mel),
                    values=[fmt(hf*x) for x in values],max_return_radius=fmt(max(return_radii)),
                    elapsed_seconds=time.time()-start)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('eps');p.add_argument('rho')
    p.add_argument('--dps',type=int,default=40);p.add_argument('--order',type=int,default=36)
    p.add_argument('--steps',type=int,default=12);p.add_argument('--nph',type=int,default=8)
    p.add_argument('--u0',default='1e-10');p.add_argument('--detuning',default='0');p.add_argument('--phase',default='0')
    p.add_argument('--output',required=True);a=p.parse_args()
    g.get_context().precision=int(a.dps*3.321928094887363)+16
    rho=str(g.mpfr(6)/7) if a.rho=='6/7' else a.rho
    it=Integrator(a.eps,rho,a.dps,a.order,a.steps,a.detuning,a.phase)
    r=it.measure(a.nph,a.u0,min(3,(a.nph-1)//2))
    Path(a.output).write_text(json.dumps(r,indent=2))
    print('RESULT',json.dumps(r),flush=True)
