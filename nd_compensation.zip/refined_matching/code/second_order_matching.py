"""Formal second-order zero Fourier mode and its outer matching datum.

Computes a finite triangular subsystem of the exact extended equations.
No exponentially accurate full-system matching is asserted.
"""
from pathlib import Path
import json
import sympy as s

tau,z,e,r,U,d=s.symbols('tau z epsilon rho U d',nonzero=True)
ii=s.I
N0=ii/(U*tau);w0=-ii/(2*tau)
M=s.Matrix([[-1,2/U],[U,0]])
X=s.Matrix(s.symbols('XN Xw'));Ym=s.Matrix(s.symbols('YmN Ymw'))
Yp=s.Matrix(s.symbols('YpN Ypw'));Zm=s.Matrix(s.symbols('ZmN Zmw'))
Z0=s.Matrix(s.symbols('Z0N Z0w'))
N=N0+r*X[0]*z**2+e*(Ym[0]/z+Yp[0]*z)+e**2*(Zm[0]/z**2+Z0[0])
w=w0+r*X[1]*z**2+e*(Ym[1]/z+Yp[1]*z)+e**2*(Zm[1]/z**2+Z0[1])
# At order epsilon^2 only inverse-w coefficients at epsilon^0 enter.
# To reach k=0 or -2 only powers z^0 and z^2 are needed.
ratio=N0/w0+r*z**2*(X[0]/w0-N0*X[1]/w0**2)
FN=-2*ii*N*w*(1+r*z**2)+ii*e**2*ratio*(1+r/z**2)/8
Fw=2*ii*w*(U*N+w*(1+r*z**2)+e*(z+1/z)/2)+2*ii*d*e**2*w+ii*e**2*(1+r/z**2)/8
F=s.Matrix([FN,Fw])
def coeff(expr,n,k):return s.expand(expr).coeff(e,n).coeff(z,k)
def block(n,k,unknown,divide=1):
 return s.simplify(s.Matrix([coeff(v,n,k)/divide for v in F])-M*unknown/tau)
sources={'X':block(0,2,X,r),'Ym':block(1,-1,Ym),
 'Yp':block(1,1,Yp),'Zm':block(2,-2,Zm),'Z0':block(2,0,Z0)}
unknowns={'X':X,'Ym':Ym,'Yp':Yp,'Zm':Zm,'Z0':Z0}
ks={'X':2,'Ym':-1,'Yp':1,'Zm':-2}
solutions={};subs={}
def power_coeff(expr,p):return s.expand(expr).coeff(tau,p)
def solve_nonzero(src,k,pmax,pmin=-6):
 out=s.zeros(2,1);higher=s.zeros(2,1)
 for p in range(pmax,pmin-1,-1):
  b=s.Matrix([power_coeff(v,p) for v in src])
  cp=s.simplify((b-((p+1)*s.eye(2)-M)*higher)/(2*ii*k))
  out+=cp*tau**p;higher=cp
 return s.simplify(out)
for name,pmax in [('X',-2),('Ym',-1),('Yp',-1),('Zm',0)]:
 src=s.simplify(sources[name].subs(subs,simultaneous=True))
 sol=solve_nonzero(src,ks[name],pmax)
 residual=s.expand(s.diff(sol,tau)+2*ii*ks[name]*sol-M*sol/tau-src)
 assert all(s.simplify(power_coeff(v,p))==0 for v in residual for p in range(pmax,-7,-1))
 solutions[name]=sol
 subs.update(dict(zip(unknowns[name],sol)))
source0=s.expand(sources['Z0'].subs(subs,simultaneous=True))
b={p:s.simplify(s.Matrix([power_coeff(v,p) for v in source0])) for p in range(0,-4,-1)}
Pplus=s.simplify((M+2*s.eye(2))/3);Pminus=s.eye(2)-Pplus
assert s.simplify(Pplus*b[0])==s.zeros(2,1)
growing_part=b[0]/3
constant=s.simplify(-M.inv()*b[-1])
inv_tau=s.simplify((-s.eye(2)-M).inv()*b[-2])
logcoef=s.simplify(Pminus*b[-3])
part_inv_tau2=s.simplify(-Pplus*b[-3]/3)
assert s.simplify((-2*s.eye(2)-M)*part_inv_tau2+logcoef-b[-3])==s.zeros(2,1)

# Only the leading outer homoclinic can contribute epsilon^2 * tau.
# Its exact re-expansion fixes this coefficient independently of rho,d.
outer_growing=s.Matrix([-ii/(6*U),-ii/24])
kappa=s.simplify(outer_growing[0]-growing_part[0])
assert s.simplify(outer_growing-growing_part-kappa*s.Matrix([1,U]))==s.zeros(2,1)
assert kappa==-ii/(12*U)
out=dict(operator=str(M),sources={k:[str(v) for v in val] for k,val in sources.items()},
 algebraic_nonzero_harmonics={k:[str(v) for v in val] for k,val in solutions.items()},
 zero_mode_source={str(k):[str(v) for v in val] for k,val in b.items()},
 zero_mode_growing_particular=[str(v) for v in growing_part],
 outer_selected_growing_coefficient=[str(v) for v in outer_growing],
 outer_selected_kappa=str(kappa),zero_mode_constant=[str(v) for v in constant],
 zero_mode_inverse_tau=[str(v) for v in inv_tau],
 resonant_log_coefficient=[str(v) for v in logcoef],
 particular_inverse_tau_squared=[str(v) for v in part_inv_tau2],
 caveat='Formal matching coefficient only; no uniform sectorial estimates or Stokes matching theorem.')
path=Path(__file__).resolve().parents[1]/'data/second_order_matching.json'
path.write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k not in ['sources','algebraic_nonzero_harmonics']},indent=2),flush=True)
