"""Formal logarithmic normalization of the growing variational mode.

Uses the same finite Fourier closure as second_order_matching.py.
The carrier exp(-2i tau) exp(2i s) is annihilated by D.
"""
from pathlib import Path
import json
import sympy as s
import second_order_matching as b

tau,z,e,r,U,d=b.tau,b.z,b.e,b.r,b.U,b.d
a=s.symbols('a');ii=s.I;M=b.M
v=s.Matrix([1,U]);baseN=b.N0+a*tau;basew=b.w0+a*U*tau
dv={k:s.Matrix(s.symbols('v'+k+'N v'+k+'w')) for k in ['X','Ym','Yp','Zm','Z0']}
bg=dict(b.solutions)
bg['Z0']=tau*b.outer_growing+b.constant+b.inv_tau/tau
vv={k:bg[k]+a*dv[k] for k in bg}
N=baseN+r*vv['X'][0]*z**2+e*(vv['Ym'][0]/z+vv['Yp'][0]*z)+e**2*(vv['Zm'][0]/z**2+vv['Z0'][0])
w=basew+r*vv['X'][1]*z**2+e*(vv['Ym'][1]/z+vv['Yp'][1]*z)+e**2*(vv['Zm'][1]/z**2+vv['Z0'][1])
ratio=baseN/basew+r*z**2*(vv['X'][0]/basew-baseN*vv['X'][1]/basew**2)
FN=-2*ii*N*w*(1+r*z**2)+ii*e**2*ratio*(1+r/z**2)/8
Fw=2*ii*w*(U*N+w*(1+r*z**2)+e*(z+1/z)/2)+2*ii*d*e**2*w+ii*e**2*(1+r/z**2)/8
VF=s.Matrix([s.diff(x,a).subs(a,0) for x in [FN,Fw]])
def source(n,k,name,divide=1):
 return s.simplify(s.Matrix([b.coeff(x,n,k)/divide for x in VF])-M*dv[name]/tau)
srcs={'X':source(0,2,'X',r),'Ym':source(1,-1,'Ym'),
 'Yp':source(1,1,'Yp'),'Zm':source(2,-2,'Zm'),'Z0':source(2,0,'Z0')}
subs={};sols={}
for name,pmax in [('X',0),('Ym',1),('Yp',1),('Zm',2)]:
 src=s.simplify(srcs[name].subs(subs,simultaneous=True))
 sol=b.solve_nonzero(src,b.ks[name],pmax,-4)
 residual=s.expand(s.diff(sol,tau)+2*ii*b.ks[name]*sol-M*sol/tau-src)
 assert all(s.simplify(b.power_coeff(v,p))==0 for v in residual for p in range(pmax,-5,-1))
 sols[name]=sol;subs.update(dict(zip(dv[name],sol)))
source0=s.expand(srcs['Z0'].subs(subs,simultaneous=True))
forcing={p:s.simplify(s.Matrix([b.power_coeff(x,p) for x in source0])) for p in [2,1,0]}
log=s.simplify(b.Pplus*forcing[0]);mu=s.simplify(log[0])
assert s.simplify(log-mu*v)==s.zeros(2,1)
out=dict(growing_mode='tau*(1,U)',formal_carrier='exp(-2i*tau)*exp(2i*s)',
 zero_mode_source={str(k):[str(x) for x in val] for k,val in forcing.items()},
 growing_tau_log_coefficient=[str(x) for x in log],relative_log_coefficient=str(mu),
 qualification='Formal variational coefficient, not a bound or a full-system Stokes matching formula. Only the algebraic part of the leading mode is normalized here.')
p=Path(__file__).resolve().parents[1]/'data/variational_log.json';p.write_text(json.dumps(out,indent=2))
print('VARIATIONAL_RESULT',json.dumps(out,indent=2),flush=True)
