"""Closed finite formal hierarchy needed for epsilon^3 Fourier index +1.

Derives equations, not their sectorial solutions or Stokes constants.
"""
from pathlib import Path
import json
import sympy as s

t,z,e,r,U,d=s.symbols('tau z epsilon rho U d',nonzero=True)
ii=s.I;N0=ii/(U*t);w0=-ii/(2*t)
M=s.Matrix([[-1,2/U],[U,0]])
grades=[('X2',0,2),('X4',0,4),('Ym',1,-1),('Yp',1,1),('Y3',1,3),
        ('Zm',2,-2),('Z0',2,0),('Zp',2,2),('Tm3',3,-3),('Tm1',3,-1),('Tp1',3,1)]
vec={name:s.Matrix(s.symbols(name+'N '+name+'w')) for name,n,k in grades}
N=N0+sum(e**n*z**k*vec[name][0] for name,n,k in grades)
w=w0+sum(e**n*z**k*vec[name][1] for name,n,k in grades)
NB=N0+z**2*vec['X2'][0]+z**4*vec['X4'][0]
WB2=vec['X2'][1]/w0;WB4=vec['X4'][1]/w0
inv=(1-WB2*z**2+(WB2**2-WB4)*z**4)/w0
inv2=(1-2*WB2*z**2+(3*WB2**2-2*WB4)*z**4)/w0**2
N1=vec['Ym'][0]/z+vec['Yp'][0]*z+vec['Y3'][0]*z**3
w1=vec['Ym'][1]/z+vec['Yp'][1]*z+vec['Y3'][1]*z**3
ratio=NB*inv+e*(N1*inv-NB*w1*inv2)
FN=-2*ii*N*w*(1+r*z**2)+ii*e**2*ratio*(1+r/z**2)/8
Fw=2*ii*w*(U*N+w*(1+r*z**2)+e*(z+1/z)/2)+2*ii*d*e**2*w+ii*e**2*(1+r/z**2)/8
F=[s.expand(FN),s.expand(Fw)]
previous=set();rows=[]
all_sources={}
for name,n,k in grades:
 src=(s.Matrix([x.coeff(e,n).coeff(z,k) for x in F])-M*vec[name]/t).applyfunc(s.cancel)
 deps=set().union(*(x.free_symbols for x in src)) & set().union(*(set(v) for v in vec.values()))
 assert deps<=previous,(name,deps-previous)
 names=[nm for nm,nn,kk in grades if set(vec[nm])&deps]
 rows.append(dict(name=name,epsilon_order=n,fourier_index=k,
     operator='d_tau + %s*i - M/tau'%(2*k),depends_on=names,
     source=[str(x) for x in src]))
 all_sources[name]=src
 previous.update(vec[name])
import second_order_matching as b
rename={}
for name,target in [('X2','X'),('Ym','Ym'),('Yp','Yp'),('Zm','Zm'),('Z0','Z0')]:
 for left,right in zip(vec[name],b.unknowns[target]):rename[left]=r*right if name=='X2' else right
for name,target in [('X2','X'),('Ym','Ym'),('Yp','Yp'),('Zm','Zm'),('Z0','Z0')]:
 lhs=all_sources[name].subs(rename,simultaneous=True)
 rhs=b.sources[target]*(r if name=='X2' else 1)
 assert all(s.cancel(x)==0 for x in lhs-rhs)
out=dict(base=[str(N0),str(w0)],linear_matrix=str(M),
 normalization='X2 here includes rho, unlike the normalized X in second_order_matching.py',
 equations=rows,number_of_nonbase_blocks=len(rows),
 target='Stokes jump of Tp1 after outer-selected Z0 growing mode and a stated pole gauge.',
 status='Closed formal differential hierarchy. Sectorial solutions, epsilon^3 Stokes coefficient, and full-system uniform remainder are not computed.')
p=Path(__file__).resolve().parents[1]/'data/third_order_hierarchy.json';p.write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k!='equations'},indent=2))
for row in rows:print(row['name'],row['epsilon_order'],row['fourier_index'],row['depends_on'])
