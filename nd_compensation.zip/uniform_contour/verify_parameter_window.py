#!/usr/bin/env python3
"""Verify a uniform parameter window from the archived Kerr contour certificate."""
import argparse
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile


def digest(data):
    return sha256(data).hexdigest()


def unpack(archive, directory):
    directory.mkdir(exist_ok=False, parents=True)
    with ZipFile(archive) as z:
        manifest = json.loads(z.read("MANIFEST_SHA256.json"))
        for name in manifest:
            if name.startswith("certified_contour/"):
                data = z.read(name)
                assert digest(data) == manifest[name], name
                dest = directory / name
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(data)
    return directory / "certified_contour"


def launch_bound():
    from mpmath import iv
    from wide_launch import CENTER, SCALES, SKIP, fixed_case, fast_linear, cb, ONE, point

    eta = point("8e-6")
    lam, nu, A = fast_linear(fixed_case(*CENTER))
    rho = point(CENTER[0])
    r_rho, r_phi = map(point, SCALES)
    db = (point(".2") * r_rho + eta * (rho + r_rho)) / 2
    dA = point("2.5") * eta + 2 * db * iv.exp(r_phi) + rho / 5 * (iv.exp(r_phi) - 1)
    base_norm = point(".3") + rho / 10 * iv.sqrt(2)
    assert (base_norm + dA).b < point(".43").a
    dm = iv.pi * iv.exp(point(".43") * iv.pi) * dA
    tr = A[0][0] + A[1][1]
    root = 2 * lam - tr
    dt = 2 * dm
    disc_change = 2 * abs(tr) * dt + dt**2
    assert disc_change.b < (root**2).a
    dl = ((dt + disc_change / root) / 2).b
    lo, hi = (lam - dl).a, (lam + dl).b
    assert lo > 1
    gap = abs(A[0][1]) - dm
    assert gap.a > 0
    stable_slope = (ONE / lam - A[0][0]) / A[0][1]
    dnu = (dl + dm + abs(nu) * dm) / gap
    ds = (dl / (lam * lo) + dm + abs(stable_slope) * dm) / gap
    separation = abs(stable_slope - nu) - ds - dnu
    assert separation.a > 0
    assert (abs(stable_slope) + abs(nu) + ds + dnu).b < 3
    assert ((ONE + abs(stable_slope) + ds) / separation).b < 3
    assert ((ONE + abs(nu) + dnu) / separation).b < 3
    assert (abs(ONE + nu**2) - (2 * abs(nu) + dnu) * dnu).a > 1
    assert (K_ball := cb.K / lo**2 + cb.GROWTH * (1 + cb.K * cb.R**2)**3 / lo**3).b < cb.K
    pre = cb.R / lo * (1 + cb.K * (cb.R / lo)**2)
    assert pre.b < point(".003").a
    assert (contraction := ONE / lo**2 + cb.SLOPE_GROWTH * pre**2 / lo**3).b < point(".70").a
    launch = point("1e-12") * hi**(SKIP + 1) * iv.exp(point(".16") * dl / lo)
    assert launch.b < cb.R.a
    assert (launch_norm := 6 * launch * (1 + cb.K * launch**2)).b < point(".014").a
    # Cauchy on the complex line through both extra parameters.
    return eta, point(".014") / (eta / 2), {
        "linear_perturbation_upper": cb.pos(dA),
        "eigenvalue_displacement_upper": cb.pos(dl),
        "chart_invariance_bound": cb.pos(K_ball),
        "chart_contraction_upper": cb.pos(contraction),
        "launch_argument_upper": cb.pos(launch),
        "launch_norm_upper": cb.pos(launch_norm),
    }


def inflate(root, half_width):
    from mpmath import iv
    from wide_panels import PERIODS, Q_CENTERS, SKIP, cb, point

    eta, launch_lipschitz, bounds = launch_bound()
    radius = point(half_width)
    assert 0 < radius.a and radius.b < (eta / 2).a
    log = (root / "SOURCE_REBUILD.log").read_text()
    launch = {(int(i), int(a)): Fraction(b)
              for i, a, b in re.findall(r"^launch (\d+) (\d+) \S+ (\S+)$", log, re.M)}
    finish = {(int(i), int(a)): Fraction(b)
              for i, a, b in re.findall(r"^integrated (\d+) (\d+) (\S+)$", log, re.M)}
    expected = {(i, a) for i in range(len(Q_CENTERS)) for a in range(2)}
    assert launch.keys() == finish.keys() == expected
    outputs = json.loads((root / "SOURCE_REBUILD.json").read_text())
    assert outputs["json_outputs"] == outputs["byte_identical_outputs"] == 54
    assert (1 / (iv.pi / 24))**point(".5") + (1 / (3 * iv.pi / 24))**point(".5") + point("1e-7") < 5
    assert (5 * radius).b < point("1e-7").a
    records = []
    for i, a in sorted(expected):
        relative = f"full_contour/data/wide-{i:02d}-{a}.json"
        path = root / relative
        raw = path.read_bytes()
        expected_hash = outputs["file_hashes"][f"certified_contour/{relative}"]["regenerated_sha256"]
        assert digest(raw) == expected_hash
        data = json.loads(raw)
        assert Fraction(data["end_error"]) == finish[i, a]
        duration = (PERIODS[a] - SKIP) * iv.pi
        growth = point(finish[i, a] / (launch[i, a] * Fraction(".999999")))
        # Compare exact trajectories in a 1e-8 tube about the base flow.
        # The added logarithmic norm is <= 50*1e-8 + 5*r < 1e-6.
        extra = (launch_lipschitz + 25 * duration) * radius * growth * iv.exp(duration * point("1e-6"))
        assert extra.b < point("1e-8").a
        data["end_error"] = cb.pos(point(data["end_error"]) + extra)
        path.write_text(json.dumps(data, indent=2) + "\n")
        records.append(dict(index=i, arc=a, original_sha256=expected_hash,
                            augmented_sha256=digest(path.read_bytes()),
                            growth_upper=cb.pos(growth), additional_error_upper=cb.pos(extra)))
    return bounds, records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--radius", default="1e-28")
    parser.add_argument("--minimum-clearance", default="4e-4",
                        help="positive normalized clearance required for the fixed tolerance rectangle")
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()
    root = unpack(args.archive, args.directory.resolve())
    binary = root / "build/transport_polynomial"
    binary.parent.mkdir()
    subprocess.run(["g++", "-O3", "-std=gnu++17", "-ffp-contract=off",
                    str(root / "code/transport_polynomial.cpp"), "-lquadmath", "-o", str(binary)], check=True)
    src = root / "full_contour/code"
    sys.path.insert(0, str(src))
    bounds, records = inflate(root, args.radius)
    subprocess.run([sys.executable, str(src / "verify_wide.py"), "--workers", str(args.workers)], check=True)
    assert re.fullmatch(r"\d+(?:\.\d+)?(?:e-\d+)?", args.minimum_clearance)
    assert 0 < Fraction(args.minimum_clearance) <= Fraction("4e-4")
    if args.minimum_clearance != "4e-4":
        stitch = src / "stitch.py"
        source = stitch.read_text()
        assert source.count('"4e-4"') == 2
        stitch.write_text(source.replace('"4e-4"', f'"{args.minimum_clearance}"'))
    subprocess.run([sys.executable, str(src / "stitch.py")], check=True)
    certificate = root / "full_contour/data/closed-contour-certificate.json"
    result = dict(base_archive_sha256=digest(args.archive.read_bytes()), simultaneous_half_width=args.radius,
                  launch=bounds, arc_bounds=records, certificate_sha256=digest(certificate.read_bytes()),
                  certificate=json.loads(certificate.read_text()))
    (args.directory / "parameter_window_result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
