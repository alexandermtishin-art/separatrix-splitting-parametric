"""Integrate jointly parametrized Kerr arcs with a first-order depth/detuning jet."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import subprocess
import sys

from mpmath import iv

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("root",type=Path)
parser.add_argument("cache",type=Path)
parser.add_argument("output",type=Path)
parser.add_argument("--scale",default="1e-16")
parser.add_argument("--panels",nargs="+",type=int,default=list(range(14)))
parser.add_argument("--workers",type=int,default=8)
args = parser.parse_args()
root, cache, output = (p.resolve() for p in (args.root,args.cache,args.output))
src = root/"full_contour/code"
sys.path.insert(0,str(src))
import wide_panels as wp
from verify_charts import point, ZERO, ONE

cb = wp.cb
wp.X = 20
V = wp.base.V = wp.V
EPS = F(".2")
S = F(args.scale)
SUPPORT = wp.base.support(V)
STEP = F("1e-11")
ETA = F("8e-6")
N = len(wp.NODES)
UNIT = iv.mpf([-1,1])


def load_charts(lane):
    raw = json.loads((cache/f"charts-{lane}.json").read_text())
    assert len(raw)==N*N
    def box(x):
        return iv.make_mpf(tuple(map(tuple,x)))
    return [{**{k:box(r[k]) for k in ("lambda","slope","chart_error")},
             "poly":[[box(x) for x in row] for row in r["poly"]]} for r in raw]


def transport_field(arc):
    scales = (wp.SCALES[0],(1-2*arc)*wp.SCALES[1])
    (h,eh,ea,sym), linear = wp.base.coefficients(wp.CENTER,scales)
    ratio = point(S/EPS)
    out = []
    conversion = ZERO
    for row, start in enumerate(range(0,len(linear),len(SUPPORT))):
        base = linear[start:start+len(SUPPORT)]
        step = row//4 % (cb.T+1)
        mat = row%4
        depth = [ratio*point(x) for x in base]
        detuning = [ZERO]*len(SUPPORT)
        if step==0 and mat in (1,2):
            detuning[0] = (3-2*mat)*point(h)*point(S)
        extras = depth+detuning
        printed = list(map(cb.approximant,extras))
        conversion += sum((cb.abs_distance(x,t) for x,t in zip(extras,printed)),ZERO)
        out.extend(base+printed)
    # A at zero detuning is proportional to depth at all controls.
    # Use the shared reference remainder scaled by that same affine factor.
    return [h,eh,cb.pos(point(ea)*(ONE+ratio)+conversion+point(eh)*point(S)),
            cb.pos(point(sym)+5*point(S))],out


def launch(center, periods, arc):
    lanes = []
    for lane, chart in enumerate(CHARTS):
        if arc:
            chart = [chart[i*N+N-1-j] for i,j in product(range(N),repeat=2)]
        coeff, error = wp.launch(chart,center,periods)
        if lane:
            radius = point(wp.OUTER/max(wp.SCALES))
            size = point(max(map(abs,wp.NODES)))
            lagrange = radius/(radius-1)*((ONE+size)/(radius-size))**N
            error += point(".004")*lagrange*(2+lagrange)
        lanes.append((coeff,error))
    scaled = point(S/(2*STEP))
    stride = (wp.X+1)*len(SUPPORT)
    rows = []
    error = lanes[0][1]+scaled*sum((bound for _,bound in lanes[1:]),ZERO)
    for comp in (0,1):
        block = slice(comp*stride,(comp+1)*stride)
        rows.extend(lanes[0][0][block])
        for lo in (1,3):
            a,b = [lanes[j][0][block] for j in (lo,lo+1)]
            coeff = [scaled*(point(x)-point(y)) for x,y in zip(a,b)]
            txt = list(map(cb.approximant,coeff))
            error += sum((cb.abs_distance(x,t) for x,t in zip(coeff,txt)),ZERO)
            rows.extend(txt)
    # Coefficient majorants from the common four-dimensional launch disk.
    t, h = point(S/ETA), point(STEP/ETA)
    omitted = point(".028")*(t*t*(3-2*t)/(ONE-t)**2+2*t*h*h/(ONE-h*h))
    return rows,error+omitted


def integrate(job):
    index, arc = job
    d = json.loads((src.parent/"data"/f"wide-{index:02d}-{arc}.json").read_text())
    assert d["period"]==wp.PERIODS[arc] and F(d["q_center"])==wp.Q_CENTERS[index]
    initial, error = launch(F(d["x_center"]), d["period"], arc)
    assert len(initial)==6*(wp.X+1)*len(SUPPORT)
    header, linear = FIELDS[arc]
    assert len(linear)==cb.M*(cb.T+1)*4*3*len(SUPPORT)
    msg = f"{wp.X} {V} {d['period']-wp.SKIP}\n"+" ".join(header+[cb.pos(error)]+linear+initial)+"\n"
    proc = subprocess.run([output/"transport_uniform"],input=msg,text=True,capture_output=True)
    if proc.returncode:
        raise RuntimeError((index,arc,proc.stderr))
    rows = proc.stdout.splitlines()
    err, defect = rows[0].split()
    d.update(x_degree=wp.X,ambient_scale=str(S),initial_error=cb.pos(error),
             end_error=cb.pos(point(err)*(ONE+cb.BINARY_PAD)),defect=defect,
             coefficients=[row.split() for row in rows[1:]])
    (output/f"arc-{index}-{arc}.json").write_text(json.dumps(d,indent=2)+"\n")
    print("transport",index,arc,d["initial_error"],d["end_error"],flush=True)


if __name__=="__main__":
    assert 0<S<ETA/2
    info = json.loads((cache/"launch_bound.json").read_text())
    assert F(info["control_disk"])==wp.OUTER and F(info["extra_disk"])==ETA and F(info["step"])==STEP
    assert F(info["launch_norm"])<F(".014") and F(info["narrow_bound"]["launch_norm_upper"])<F(".014")
    output.mkdir(parents=True,exist_ok=False)
    subprocess.run(["g++","-O3","-std=gnu++17","-ffp-contract=off","-mfma","-DFAST_TWO_FOLD",
                    "-I"+str(src),str(Path(__file__).with_name("transport_uniform.cpp")),
                    "-lquadmath","-o",str(output/"transport_uniform")],check=True)
    CHARTS = [load_charts(k) for k in range(5)]
    FIELDS = [transport_field(a) for a in (0,1)]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        list(pool.map(integrate,product(args.panels,(0,1))))
