#include <quadmath.h>
#include <algorithm>
#include <array>
#include <cassert>
#include <cfenv>
#include <iostream>
#include <string>
#include <vector>

#ifdef FAST_TWO_FOLD
#include "twofold.hpp"
using Q=Twofold;
Q input(__float128 x){return Q::from_quad(x);}
__float128 output(Q x){return x.binary128();}
const Q pad=input(1e-22Q), guard_coefficient=input(1e-26Q), underflow=input(1e-280Q);
#else
using Q=__float128;
Q input(Q x){return x;}
Q output(Q x){return x;}
const Q pad=1e-25Q, guard_coefficient=1e-27Q, underflow=1e-1000Q;
#endif
using Vec=std::vector<Q>;
using State=std::array<Vec,2>;
constexpr int T=24, M=24;
// Keep the full reference space and a smaller affine-parameter space.
constexpr int weighted_degree=36;
constexpr int weight(int x,int v,int w,int lane){return x+4*(v+w)+20*(lane!=0);}
Q read_q(){std::string s;assert(bool(std::cin>>s));return input(strtoflt128(s.c_str(),nullptr));}
void write_q(Q x){char s[110];quadmath_snprintf(s,sizeof(s),"%.39Qe",output(x));std::cout<<s<<" ";}
Q norm(Q a,Q b){const Q s=a*a+b*b;Q v=sqrtq(s)*(1+pad);assert(finiteq(s)&&v*v>=s*(1+pad));return v;}
Q l1(const Vec& a){Q total=0;for(Q x:a)total+=fabsq(x);return total;}

struct Product{
    int out,left,right;
};
struct Monomial { int x, v, w, lane; };

std::vector<Monomial> basis(int X,int V){
    std::vector<Monomial> result;
    for(int lane=0;lane<3;++lane)
        for(int n=0;n<=V;++n) for(int w=0;w<=n;++w)
            for(int x=0;x<=X;++x)
                if(weight(x,n-w,w,lane)<=weighted_degree) result.push_back({x,n-w,w,lane});
    return result;
}

int index(int x,int v,int w,int lane,int X,int V){
    const int n=v+w;
    return (lane*(V+1)*(V+2)/2+n*(n+1)/2+w)*(X+1)+x;
}

std::vector<Product> retained(int X1,int V1,int X2,int V2,int X,int V){
    const auto a=basis(X1,V1),b=basis(X2,V2);
    std::vector<int> target(3*(X+1)*(V+1)*(V+2)/2,-1);
    const auto output_basis=basis(X,V);
    for(int k=0;k<int(output_basis.size());++k){
        const auto m=output_basis[k];
        target[index(m.x,m.v,m.w,m.lane,X,V)]=k;
    }
    std::vector<Product> result;
    for(int i=0;i<int(a.size());++i) for(int j=0;j<int(b.size());++j){
        int x=a[i].x+b[j].x,v=a[i].v+b[j].v,w=a[i].w+b[j].w;
        const int lane=a[i].lane+b[j].lane;
        if(a[i].lane&&b[j].lane) continue;
        if(x<=X&&v+w<=V&&weight(x,v,w,lane)<=weighted_degree)
            result.push_back({target[index(x,v,w,lane,X,V)],i,j});
    }
    return result;
}

Q cubic_high(const Vec& coefficients){
    const int degree=coefficients.size()-1;
    Q tail=0;
    for(int i=0;i<=degree;++i)for(int j=0;j<=degree;++j)
        for(int k=std::max(0,degree+1-i-j);k<=degree;++k)
            tail+=coefficients[i]*coefficients[j]*coefficients[k];
    return tail;
}

using Linear=std::array<std::array<std::array<Vec,4>,T+1>,M>;
struct Integrator{
    int X,V;
    Q h,h_error,a_error,sym;
    Linear linear;
    std::vector<Monomial> monomials,linear_monomials;
    int space;
    std::vector<Product> square,cube,lin;
    Integrator(int x,int v,Q step,Q step_error,Q lin_error,Q symmetric)
        :X(x),V(v),h(step),h_error(step_error),a_error(lin_error),sym(symmetric),
        monomials(basis(x,v)),linear_monomials(basis(0,v)),space(monomials.size()),
        square(retained(x,v,x,v,x,v)),cube(square),lin(retained(0,v,x,v,x,v)){}

    State step(const State& initial,int k,Q& error,Q& max_defect) const{
        std::array<State,T+1> u;
        std::array<Vec,T+1> n;
        for(auto& p:u)for(auto& c:p)c.resize(space);
        for(auto& p:n)p.resize(space);
        u[0]=initial;
        Q dq=0,dp=0;
        for(int j=0;j<=T;++j){
            for(int a=0;a<=j;++a){
                int b=j-a;
                for(const auto& m:square)
                    n[j][m.out]+=(u[a][0][m.left]*u[b][0][m.right]+u[a][1][m.left]*u[b][1][m.right])/2;
            }
            Vec f(space),g(space);
            for(int a=0;a<=j;++a){
                int b=j-a;
                for(const auto& m:lin){
                    const auto& A=linear[k][a];
                    f[m.out]+=A[0][m.left]*u[b][0][m.right]+A[1][m.left]*u[b][1][m.right];
                    g[m.out]+=A[2][m.left]*u[b][0][m.right]+A[3][m.left]*u[b][1][m.right];
                }
                // Scaling a density once per pair of time coefficients
                // keeps the innermost convolution compact.
                Vec hn=n[a];
                for(Q& t:hn)t*=h;
                for(const auto& m:cube){
                    f[m.out]-=hn[m.left]*u[b][1][m.right];
                    g[m.out]+=hn[m.left]*u[b][0][m.right];
                }
            }
            if(j<T)for(int i=0;i<space;++i){
                u[j+1][0][i]=f[i]/(j+1);u[j+1][1][i]=g[i]/(j+1);
            }else{dq+=l1(f);dp+=l1(g);}
        }
        State end{Vec(space),Vec(space)};
        std::array<Q,T+1> size{},sizeA{};
        Vec x_majorant(X+1),v_majorant(V+1),linear_v(V+1),ambient(2),linear_ambient(2);
        Vec weighted(weighted_degree+1),weighted_linear(weighted_degree+1);
        Q total=0,totalA=0,linear_tail=0,cubic_tail=0,center=0,variation=0;
        for(int j=0;j<=T;++j){
            for(int i=0;i<space;++i){
                end[0][i]+=u[j][0][i];end[1][i]+=u[j][1][i];
            }
            size[j]=fmaxq(l1(u[j][0]),l1(u[j][1]));
            const auto& a=linear[k][j];
            sizeA[j]=fmaxq(l1(a[0])+l1(a[1]),l1(a[2])+l1(a[3]));
            for(int i=0;i<int(linear_monomials.size());++i){
                const auto m=linear_monomials[i];
                const Q bound=fmaxq(fabsq(a[0][i])+fabsq(a[1][i]),fabsq(a[2][i])+fabsq(a[3][i]));
                linear_v[m.v+m.w]+=bound;
                linear_ambient[m.lane!=0]+=bound;
                weighted_linear[weight(0,m.v,m.w,m.lane)]+=bound;
            }
            for(int i=0;i<space;++i){
                const auto m=monomials[i];
                Q bound=fmaxq(fabsq(u[j][0][i]),fabsq(u[j][1][i]));
                x_majorant[m.x]+=bound; v_majorant[m.v+m.w]+=bound;
                ambient[m.lane!=0]+=bound;
                weighted[weight(m.x,m.v,m.w,m.lane)]+=bound;
            }
            total+=size[j];totalA+=sizeA[j];
            center+=norm(u[j][0][0],u[j][1][0]);
            for(int i=1;i<space;++i)variation+=norm(u[j][0][i],u[j][1][i]);
        }
        // Products of marginal l1 bounds dominate all omitted coefficients.
        // Counting a term in two discarded-degree directions is harmless.
        cubic_tail+=cubic_high(x_majorant)+cubic_high(v_majorant);
        for(int i=0;i<=V;++i)for(int j=V+1-i;j<=V;++j)
            linear_tail+=linear_v[i]*v_majorant[j];
        cubic_tail+=cubic_high(ambient)+cubic_high(weighted);
        linear_tail+=linear_ambient[1]*ambient[1];
        for(int i=0;i<=weighted_degree;++i)
            for(int j=weighted_degree+1-i;j<=weighted_degree;++j)
                linear_tail+=weighted_linear[i]*weighted[j];
        for(int a=0;a<=T;++a)for(int b=0;b<=T;++b){
            if(a+b>T)linear_tail+=sizeA[a]*size[b];
            for(int c=std::max(0,T+1-a-b);c<=T;++c)
                cubic_tail+=size[a]*size[b]*size[c];
        }
        Q cubic=total*total*total;
        Q guard=guard_coefficient*(total+totalA*total+cubic)+underflow;
        Q defect=(dq+dp+2*(linear_tail+h*cubic_tail+a_error*total+h_error*cubic+guard))*(1+pad);
        const Q cap=input(1e-7Q);
        Q near=(variation+cap)*(1+pad);
        Q rate=((h+h_error)*(sym+center*center/2+1.5*(2*center+near)*near))*(1+pad);
        assert(rate<.5);
        error=((error+defect)/(1-rate))*(1+pad);
        assert(error<cap&&finiteq(error));
        max_defect=fmaxq(max_defect,defect);
        return end;
    }
};

int main(){
    static_assert(FLT128_MANT_DIG==113);
    assert(std::fegetround()==FE_TONEAREST);
#ifdef FAST_TWO_FOLD
    static_assert(std::numeric_limits<double>::is_iec559 && std::numeric_limits<double>::digits==53);
#endif
    int X,V,N;
    assert(bool(std::cin>>X>>V>>N));
    assert(X>=1&&X<=20&&V>=1&&V<=4&&N>=1);
    Q h=read_q(),he=read_q(),ae=read_q(),sym=read_q(),error=read_q();
    Integrator flow(X,V,h,he,ae,sym);
    for(auto& t:flow.linear)for(auto& j:t)for(auto& a:j){
        a.resize(flow.linear_monomials.size());for(auto& c:a)c=read_q();
    }
    State u{Vec(flow.space),Vec(flow.space)};
    for(auto& a:u){
        int k=0;
        for(int lane=0;lane<3;++lane)
            for(int n=0;n<=V;++n)for(int w=0;w<=n;++w)for(int i=0;i<=X;++i){
                const Q x=read_q();
                if(weight(i,n-w,w,lane)<=weighted_degree)a[k++]=x;
                else error+=fabsq(x)*(1+pad);
            }
        assert(k==flow.space);
    }
#ifdef FAST_TWO_FOLD
    const Q conversion=input(1e-30Q);
    Q a_size=0;
    for(const auto& t:flow.linear)for(const auto& j:t)for(const auto& a:j)
        a_size+=l1(a);
    flow.a_error+=conversion*a_size;
    flow.h_error+=conversion*fabsq(h);
    flow.sym*=1+conversion;
    error+=conversion*(l1(u[0])+l1(u[1]));
#endif
    Q defect=0;
    for(int j=0;j<N;++j)for(int k=0;k<M;++k)u=flow.step(u,k,error,defect);
    write_q(error);write_q(defect);std::cout<<"\n";
    for(const auto& a:u){
        int k=0;
        for(int lane=0;lane<3;++lane)
            for(int n=0;n<=V;++n)for(int w=0;w<=n;++w)for(int i=0;i<=X;++i)
                write_q(weight(i,n-w,w,lane)<=weighted_degree ? a[k++] : Q(0));
        std::cout<<"\n";
    }
}
