"""Validated launch samples for first-order dependence on depth and detuning."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import subprocess
import sys

from mpmath import iv

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("root", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--workers", type=int, default=8)
parser.add_argument("--base-cache", type=Path)
args = parser.parse_args()
root, output = args.root.resolve(), args.output.resolve()
sys.path.insert(0, str(root/"full_contour/code"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import wide_launch as wl
from verify_charts import point, ONE, ZERO

ETA = F("8e-6")
STEP = F("1e-11")
EPS = F("0.2")
LAUNCH_LIMIT = F(".014")
DISK = wl.OUTER
NODES = wl.NODES
cb = wl.cb


def bound():
    wl.OUTER = DISK
    columns = wl.wide_monodromy()
    a, c = columns[0]
    b, d = columns[1]
    lam, nu, central = wl.fast_linear(wl.fixed_case(*wl.CENTER))
    t = central[0][0]+central[1][1]
    root = 2*lam-t
    delta_a = 5*point(STEP)
    assert (point(".3")+point(wl.CENTER[0])*point(".1")*iv.sqrt(2)
            +wl.base.matrix_change(wl.CENTER,(DISK,DISK),1)+delta_a).b<point(".43").a
    delta_m = iv.pi*iv.exp(point(".43")*iv.pi)*delta_a

    def displacement(entry, value):
        coeff, error = entry
        return abs(coeff[0]-value)+sum(map(abs, coeff[1:]),ZERO)+error+delta_m

    dv = [[displacement(a,central[0][0]), displacement(b,central[0][1])],
          [displacement(c,central[1][0]), displacement(d,central[1][1])]]
    dt = dv[0][0]+dv[1][1]
    disc = 2*abs(t)*dt+dt**2
    assert disc.b<(root**2).a
    dl = ((dt+disc/root)/2).b
    lo, hi = (lam-dl).a, (lam+dl).b
    assert lo>1
    s = (ONE/lam-central[0][0])/central[0][1]
    gap = abs(central[0][1])-dv[0][1]
    assert gap.a>0
    dn = (dl+dv[0][0]+abs(nu)*dv[0][1])/gap
    ds = (dl/(lam*lo)+dv[0][0]+abs(s)*dv[0][1])/gap
    sep = abs(s-nu)-dn-ds
    assert sep.a>0 and (abs(s)+abs(nu)+dn+ds).b<3
    assert ((ONE+abs(s)+ds)/sep).b<3 and ((ONE+abs(nu)+dn)/sep).b<3
    assert (abs(ONE+nu**2)-(2*abs(nu)+dn)*dn).a>1
    assert (cb.K/lo**2+cb.GROWTH*(1+cb.K*cb.R**2)**3/lo**3).b<cb.K
    pre = cb.R/lo*(1+cb.K*(cb.R/lo)**2)
    assert pre.b<point(".003").a
    contraction = ONE/lo**2+cb.SLOPE_GROWTH*pre**2/lo**3
    assert contraction.b<point(".70").a
    launch = point(wl.CASE["launch"])*hi**(wl.SKIP+1)*iv.exp(point(".16")*dl/lo)
    assert launch.b<cb.R.a
    size = 6*launch*(1+cb.K*launch**2)
    assert size.b<point(LAUNCH_LIMIT).a,size
    from verify_parameter_window import launch_bound
    narrow_bound = launch_bound()[2]
    return dict(narrow_bound=narrow_bound,delta_monodromy=cb.pos(delta_m),contraction=cb.pos(contraction),
                launch_argument=cb.pos(launch),launch_norm=cb.pos(size),
                control_disk=str(DISK),extra_disk=str(ETA),step=str(STEP))


def chart_job(job):
    lane, v, w = job
    de, dd = SHIFTS[lane]
    case = {**wl.fixed_case(wl.CENTER[0]+wl.SCALES[0]*v,wl.CENTER[1]+wl.SCALES[1]*w),
            "eps":str(EPS+de),"detuning":str(dd)}
    cb.linear_data = wl.fast_linear
    c = cb.local_chart(case)
    return {**{k:c[k]._mpi_ for k in ("lambda","slope","chart_error")},
            "poly":[[z._mpi_ for z in row] for row in c["poly"]]}


SHIFTS = ((0,0),(STEP,0),(-STEP,0),(0,STEP),(0,-STEP))

if __name__=="__main__":
    output.mkdir(parents=True,exist_ok=False)
    cb.EXE = output/"transport_polynomial"
    wl.SOLVER = output/"transport_two_controls"
    for source,binary in ((root/"code/transport_polynomial.cpp",cb.EXE),
                          (root/"contour/code/transport_two_controls.cpp",wl.SOLVER)):
        subprocess.run(["g++","-O3","-std=gnu++17","-ffp-contract=off",str(source),
                        "-lquadmath","-o",str(binary)],check=True)
    info = bound()
    (output/"launch_bound.json").write_text(json.dumps(info,indent=2)+"\n")
    print("validated common launch disk", info,flush=True)
    first = 0
    if args.base_cache:
        cache = json.loads(args.base_cache.read_text())
        assert len(cache)==len(NODES)**2
        (output/"charts-0.json").write_text(json.dumps(cache)+"\n")
        first = 1
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for lane in range(first,len(SHIFTS)):
            jobs = ((lane,v,w) for v,w in product(NODES,repeat=2))
            charts = list(pool.map(chart_job,jobs))
            (output/f"charts-{lane}.json").write_text(json.dumps(charts)+"\n")
            print("validated slice",lane,len(charts),flush=True)
