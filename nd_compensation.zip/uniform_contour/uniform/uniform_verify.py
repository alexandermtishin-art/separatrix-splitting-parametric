"""Verify the complete Kerr contour uniformly in depth and detuning."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import sys
from types import ModuleType

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("root",type=Path)
parser.add_argument("panels",type=Path)
parser.add_argument("output",type=Path)
parser.add_argument("--indices",nargs="+",type=int,default=list(range(14)))
parser.add_argument("--workers",type=int,default=8)
args = parser.parse_args()
root, archive, output = (p.resolve() for p in (args.root,args.panels,args.output))
sys.path.insert(0,str(root/"full_contour/code"))
import verify_wide as vw
import stitch
from verify_charts import point, interval, ZERO, ONE

X = vw.X = vw.N = 20
V = vw.V
cb, tm = vw.cb, vw.tm
tm.DEG_Q, tm.DEG_C = X,V
R = point(vw.REAL_X)
Z0 = (0,0,0)


def size(poly):
    return sum(map(abs,poly.values()),ZERO).b


def partial(poly,order):
    for _ in range(order):
        poly = {(i-1,v,w):i*a for (i,v,w),a in poly.items() if i}
    return poly


def derivative_bound(poly,order):
    return sum((abs(a)*R**i for (i,v,w),a in partial(poly,order).items()),ZERO).b


def collapse(models, error=ZERO):
    base,*lanes = models
    return tm.Taylor(base,error+sum(map(size,lanes),ZERO))


def inverse_guess(q, slope, target, algebra):
    z0 = vw.inverse_candidate(q[0],slope,target).p
    a = algebra.compose(partial(q[0],1),z0)
    m = cb.approximant(slope)
    unit = algebra.from_poly({Z0:ONE})
    # Polynomial geometric series for a candidate only. Its residual is
    # verified below, including every neglected power and rounding error.
    approx = {k:-x/point(m) for k,x in algebra.export(a)[0].items()}
    approx[Z0] = approx.get(Z0,ZERO)+ONE
    factor = algebra.from_poly(approx)
    recip = unit
    for _ in range(10):
        recip = algebra.plus(algebra.product(recip,factor),unit)
    r = []
    for p in q[1:]:
        value = algebra.product(algebra.compose(p,z0),recip)
        r.append({k:-x/point(m) for k,x in algebra.export(value)[0].items()})
    return [z0,*r]


def compose(raw,z,algebra):
    z0,*extra = z
    base = algebra.compose(raw[0],z0)
    dx = algebra.compose(partial(raw[0],1),z0)
    lanes = [algebra.plus(algebra.compose(p,z0),algebra.product(dx,algebra.from_poly(dz)))
             for p,dz in zip(raw[1:],extra)]
    packed = list(map(algebra.export,[base,*lanes]))
    zn = sum(map(size,extra),ZERO)
    tail = derivative_bound(raw[0],2)*zn**2/2
    tail += sum((derivative_bound(p,1) for p in raw[1:]),ZERO)*zn
    return [p for p,e in packed],(sum((e for p,e in packed),ZERO)+tail).b


def graph(panel):
    q0 = F(panel["q_center"])
    basis = [(i,v,w) for v,w in vw.base.support(V) for i in range(X+1)]
    count = len(basis)
    def parse(row):
        assert len(row)==3*count
        return [{key:point(s)+abs(point(s))*cb.BINARY_PAD*tm.UNIT
                 for key,s in zip(basis,row[j*count:(j+1)*count])} for j in range(3)]
    q,p = map(parse,panel["coefficients"])
    err = point(panel["end_error"]).b
    slope = q[0][1,0,0]
    assert ((1-2*panel["arc"])*slope).a>0
    m = abs(slope).a
    qvar = {k:a for k,a in q[0].items() if k!=(1,0,0)}
    vary = sum((derivative_bound(a,1) for a in [qvar,*q[1:]]),ZERO)+err/(ONE-R)
    contraction = (vary/m).b
    offset = abs(q[0][Z0]-point(q0))
    offset += sum((abs(a) for k,a in q[0].items() if k[0]==0 and k!=Z0),ZERO)
    offset += sum((abs(a) for lane in q[1:] for k,a in lane.items() if k[0]==0),ZERO)
    assert contraction<point(".2").a
    assert ((offset+point(vw.RQ)+err)/m+contraction*R).b<R.a
    algebra = vw.Algebra(X,V)
    z = inverse_guess(q,slope,q0,algebra)
    assert sum(map(size,z),ZERO).b<R.a
    residual,re = compose(q,z,algebra)
    for key,target in ((Z0,q0),((1,0,0),vw.RQ)):
        residual[0][key] = residual[0].get(key,ZERO)-point(target)
    ie = (sum(map(size,residual),ZERO)+re+err)/(m*(ONE-contraction))
    pmod,pe = compose(p,z,algebra)
    pe = (pe+err+sum((derivative_bound(lane,1) for lane in p),ZERO)*ie).b
    return pmod,pe,collapse(z,ie),collapse(q,err),panel


def panel_proof(index):
    raw = [(archive/f"arc-{index}-{a}.json").read_bytes() for a in (0,1)]
    panels = list(map(json.loads,raw))
    q0 = vw.Q_CENTERS[index]
    for a,p in enumerate(panels):
        assert p["index"]==index and p["arc"]==a and F(p["q_center"])==q0
        assert p["period"]==vw.PERIODS[a]
        assert tuple(map(F,p["center"]))==vw.CENTER and tuple(map(F,p["scale"]))==vw.SCALES
        assert F(p["x_radius"])==vw.RX and p["x_degree"]==X and p["control_degree"]==V
    assert F(panels[0]["ambient_scale"])==F(panels[1]["ambient_scale"])>0
    out,ret = map(graph,panels)
    gap = [(tm.Taylor(a)+tm.Taylor(b)).p for a,b in zip(out[0],ret[0])]
    d = collapse(gap,out[1]+ret[1])
    outgoing = (None,*out[2:])
    returning = (None,*ret[2:])
    b = vw.Q_HALF/vw.RQ
    slabs = []
    anchors = {name:[] for name in ("center","top")}
    for i in range(vw.SUBDIVISIONS):
        a,z = [-b+2*b*F(j,vw.SUBDIVISIONS) for j in (i,i+1)]
        try:
            record = vw.prove_slab(d,outgoing,returning,interval(a,z),point((a+z)/2))
        except AssertionError as error:
            raise AssertionError(index,i,cb.pos(d.error),error) from error
        record["physical_q"] = list(map(str,(q0+vw.RQ*a,q0+vw.RQ*z)))
        slabs.append(record)
        for name,w in (("center",ZERO),("top",point(vw.CONTROL))):
            box = (interval(a,z),ZERO,w)
            value,slope = [vw.derivative(d,order,box) for order in vw.ORDERS]
            anchors[name].append(dict(q=record["physical_q"],sign=int(value.a>0)-int(value.b<0),
                                      slope=int(slope.a>0)-int(slope.b<0)))
    boundary = {}
    if index in (0,len(vw.Q_CENTERS)-1):
        x_seam = F("-.88") if index==0 else F("-.38")
        x = point((x_seam-F(panels[0]["x_center"]))/vw.RX)
        assert abs(x).b<point(vw.REAL_X).a
        full = (x,vw.real_interval(0,vw.CONTROL),vw.real_interval(0,vw.CONTROL))
        qb = vw.derivative(outgoing[2],Z0,full)
        assert qb.a>point(q0-vw.Q_HALF).b and qb.b<point(q0+vw.Q_HALF).a
        y = vw.derivative(returning[1],Z0,((qb-point(q0))/point(vw.RQ),*full[1:]))
        boundary = dict(physical_q_for_launch_seam=str(qb),
                        stable_launch_at_seam=str(point(panels[1]["x_center"])+point(vw.RX)*y))
        for name,w in (("center",ZERO),("top",point(vw.CONTROL))):
            boundary[name] = str(vw.derivative(outgoing[2],Z0,(x,ZERO,w)))
    result = dict(index=index,boundary=boundary,anchors=anchors,graph_error=cb.pos(d.error),
                  affine_gap_norm=cb.pos(sum(map(size,gap[1:]),ZERO)),
                  separate_affine_norm=cb.pos(sum((size(lane) for branch in (out,ret)
                                                   for lane in branch[0][1:]),ZERO)),
                  q_range=list(map(str,(q0-vw.Q_HALF,q0+vw.Q_HALF))),
                  x_ranges=[list(map(str,(F(p["x_center"])-vw.RX*vw.REAL_X,
                                          F(p["x_center"])+vw.RX*vw.REAL_X))) for p in panels],
                  panel_sha256=[sha256(r).hexdigest() for r in raw],slabs=slabs)
    for a,r in enumerate(raw):
        (output/"data"/f"wide-{index:02d}-{a}.json").write_bytes(r)
    (output/"data"/f"wide-{index:02d}-certificate.json").write_text(json.dumps(result,indent=2)+"\n")
    print("verified",index,result["graph_error"],result["affine_gap_norm"],flush=True)
    return F(panels[0]["ambient_scale"])


if __name__=="__main__":
    (output/"data").mkdir(parents=True,exist_ok=False)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        scales = set(pool.map(panel_proof,args.indices))
    assert len(scales)==1
    if args.indices==list(range(len(vw.Q_CENTERS))):
        # Keep the original physical tolerance box. Use the weaker positive
        # clearance already used for the earlier depth/detuning certificate.
        source = Path(stitch.__file__).read_text()
        assert source.count('"4e-4"')==2
        verifier = ModuleType("uniform_stitch")
        exec(compile(source.replace('"4e-4"','"1e-4"'),stitch.__file__,"exec"),verifier.__dict__)
        verifier.HERE = output/"code"
        result = verifier.prove()
        radii = [point(r/s) for r,s in zip(map(F,result["robust_box"]["half_width"]),vw.SCALES)]
        panels = [json.loads((output/"data"/f"wide-{i:02d}-certificate.json").read_text())
                  for i in args.indices]
        clearance = min(max((abs(point(box)).a-r).a for box,r in zip(row["controls"],radii))
                        for panel in panels for row in panel["slabs"])
        result["measured_lower_clearance"] = cb.pos(point(".999999")*clearance)
        result["depth_and_detuning_half_width"] = str(scales.pop())
        (output/"result.json").write_text(json.dumps(result,indent=2)+"\n")
        print("complete closed-contour certificate",flush=True)
