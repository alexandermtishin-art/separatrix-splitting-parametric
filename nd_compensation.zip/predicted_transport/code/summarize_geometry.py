"""Compare the direct lobe areas and check the stroboscopic normalization."""
from decimal import Decimal, localcontext
import json
from pathlib import Path

import gmpy2 as g
import mpmath as mp

from lobe_area import evaluate


ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"


def read(name):
    return json.loads((DATA / (name + ".json")).read_text())


def inverse(coefficients, q):
    left = evaluate(coefficients, g.mpfr(-1))[0]
    right = evaluate(coefficients, g.mpfr(1))[0]
    x = -1 + 2 * (q - left) / (right - left)
    for _ in range(24):
        value, slope = evaluate(coefficients, x)
        change = (value - q) / slope
        x -= change
        if abs(change) < g.mpfr("1e-58"):
            return x
    raise RuntimeError("Branch-coordinate inversion did not converge")


def verify_branch_quadrature(run):
    # The product p(x) q'(x) has degree at most 2d-1, where d is
    # the interpolation degree. Integrate each arc in its own parameter.
    g.get_context().precision = 260
    mp.mp.dps = 76
    nodes, weights = mp.gauss_quadrature(run["degree"], "legendre")
    nodes = [g.mpfr(str(node)) for node in nodes]
    weights = [g.mpfr(str(weight)) for weight in weights]
    roots = [g.mpfr(value) for value in run["roots"]]
    arcs = [
        [[g.mpfr(value) for value in component] for component in arc]
        for arc in run["interpolation_coefficients"].values()
    ]
    areas = [g.mpfr(0) for _ in roots[:-1]]
    for q_arc, p_arc in arcs:
        endpoints = [inverse(q_arc, q) for q in roots]
        for i, (a, b) in enumerate(zip(endpoints[:-1], endpoints[1:])):
            mid, half = (a + b) / 2, (b - a) / 2
            for node, weight in zip(nodes, weights):
                x = mid + half * node
                areas[i] += half * weight * evaluate(p_arc, x)[0] * evaluate(q_arc, x)[1]
    reference = [g.mpfr(value) for value in run["signed_lobe_areas"]]
    return format(max(abs(a - b) for a, b in zip(areas, reference)), ".17g")


def reduce_run(run, source, historical_step=None):
    lobes = list(map(Decimal, run["signed_lobe_areas"]))
    assert all(a * b < 0 for a, b in zip(lobes[:-1], lobes[1:])), source
    pairing = run.get("root_pairing")
    if pairing is None:
        pairs = [(j, j + historical_step) for j in range(len(lobes) + 1 - historical_step)]
        position_error = None
    else:
        pairs = [(pair["index"], pair["image_index"]) for pair in pairing]
        assert len(pairs) >= 2 and all(k - j == 2 for j, k in pairs), source
        position_error = max(Decimal(pair["q_error"]) + Decimal(pair["p_error"]) for pair in pairing)
        roots = list(map(Decimal, run["roots"]))
        separation = min(b - a for a, b in zip(roots[:-1], roots[1:]))
        assert position_error < separation * Decimal("1e-6"), source
    cycles = [lobes[j:k] for j, k in pairs]
    incoming = [sum(a for a in cycle if a > 0) for cycle in cycles]
    assert all(area > 0 for area in incoming), source
    count = {sum(area > 0 for area in cycle) for cycle in cycles}
    assert len(count) == 1, source
    return {
        "source": source + ".json",
        "rho": run["rho"],
        "root_count": len(lobes) + 1,
        "cycles": pairs,
        "incoming_lobes_per_cycle": count.pop(),
        "incoming_area_mean": sum(incoming) / len(incoming),
        "incoming_area_cycle_spread": max(incoming) - min(incoming),
        "maximum_net_signed_area": max(abs(sum(cycle)) for cycle in cycles),
        "maximum_mapped_root_l1_error": position_error,
        "maximum_arc_pointcheck_error": Decimal(run["interpolation_pointcheck_error"]),
    }


def main():
    with localcontext() as context:
        context.prec = 60
        original = reduce_run(read("historical_original"), "historical_original", 2)
        tuned = reduce_run(read("historical_tuned"), "historical_tuned", 4)
        runs = {}
        convergence = {}
        for setting in ("leading", "predicted"):
            for level in ("d40", "d56", "refined"):
                name = setting + "_" + level
                result = read(name)
                runs[name] = reduce_run(result, name)
                if level == "refined":
                    runs[name]["maximum_branch_quadrature_difference"] = verify_branch_quadrature(result)
            area = [runs[setting + "_" + level]["incoming_area_mean"]
                    for level in ("d40", "d56", "refined")]
            convergence[setting] = {
                "degree_40_to_56_relative": abs(area[1] - area[0]) / area[1],
                "nominal_to_refined_relative": abs(area[2] - area[1]) / area[2],
            }
        leading = runs["leading_refined"]["incoming_area_mean"]
        predicted = runs["predicted_refined"]["incoming_area_mean"]
        summary = {
            "epsilon": "0.20",
            "detuning": "0",
            "phase": "0",
            "historical_controls": {"original": original, "numerically_tuned": tuned},
            "runs": runs,
            "convergence": convergence,
            "area_reduction_leading_to_predicted": leading / predicted,
            "area_reduction_original_to_predicted": original["incoming_area_mean"] / predicted,
            "area_reduction_original_to_leading": original["incoming_area_mean"] / leading,
            "predicted_over_numerically_tuned": predicted / tuned["incoming_area_mean"],
        }
        (DATA / "geometry_summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
        print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
