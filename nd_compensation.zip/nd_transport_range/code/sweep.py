"""Freeze and evaluate the finite-depth transport check in the original flow."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from decimal import Decimal, localcontext
import json
from pathlib import Path

from lobe_area import compute
from summarize import measure


DATA = Path(__file__).resolve().parents[1] / "data"
PLAN = DATA / "frozen_grid.json"
DEPTHS = ("0.14", "0.15", "0.17", "0.18", "0.19", "0.21", "0.22", "0.24")
MATCHED_DEPTHS = ("0.16", "0.18", "0.22")


def freeze():
    with localcontext() as ctx:
        ctx.prec = 70
        base = Decimal(6) / 7
        cubic_shift = Decimal("0.0438483117759323797304930479039366131895338584871905612877561723")
        points = {}
        for mode, depths in (("zero", DEPTHS), ("matched", MATCHED_DEPTHS)):
            for depth in depths:
                eps = Decimal(depth)
                for label, rho in (("lead", base), ("pred", base - cubic_shift * eps**2)):
                    delta = Decimal(0) if mode == "zero" else (rho**2 - 1) * eps**2 / 16
                    points[f"{mode}_{depth.replace('.', '')}_{label}"] = {
                        "epsilon": depth, "rho": str(rho), "delta": str(delta), "phase": "0"
                    }
    DATA.mkdir(exist_ok=True)
    with PLAN.open("x") as output:
        json.dump({
            "points": points,
            "comparison": "Incoming area per fundamental interval, at fixed predicted setting versus 6/7. No fitted setting.",
            "criterion": "Report every point, one or two lobes, and the sign of the area change. For ratio claims require complete root pairing and refinement agreement.",
            "refinement": "Independently refine both settings at 0.14, 0.18, 0.24 (zero detuning) and 0.22 (matched). Report sampled depths only.",
        }, output, indent=2)
        output.write("\n")


def run(item):
    name, p, refined, narrow_chart = item
    dest = DATA / (name + ("_refined" if refined else "") + ".json")
    if dest.exists():
        return
    print("START", dest.stem, flush=True)
    result = compute(
        p["epsilon"], p["rho"], detuning=p["delta"], phase=p["phase"],
        span="1.5" if narrow_chart else "2",
        degree=44 if refined else 32, dps=53 if refined else 47,
        order=39 if refined else 32, steps=10 if refined else 8,
        launch="1e-12" if refined else "1e-10",
    )
    with localcontext() as ctx:
        ctx.prec = 56
        result["measured"] = measure(result)
    dest.write_text(json.dumps(result, default=str, indent=2) + "\n")
    print("DONE", dest.stem, result["measured"], flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--freeze", action="store_true")
    parser.add_argument("--refined", action="store_true")
    parser.add_argument("--narrow-chart", action="store_true")
    parser.add_argument("--workers", type=int, default=7)
    parser.add_argument("cases", nargs="*")
    args = parser.parse_args()
    if args.freeze:
        freeze()
    else:
        points = json.loads(PLAN.read_text())["points"]
        names = args.cases or points
        if args.refined and not args.cases:
            names = [n for n in points if n.rsplit("_", 1)[0] in {
                "zero_014", "zero_018", "zero_024", "matched_022"
            }]
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            list(pool.map(run, ((name, points[name], args.refined, args.narrow_chart) for name in names)))
