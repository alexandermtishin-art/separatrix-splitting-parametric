"""Combine the frozen finite-depth sweep with the earlier sampled depths."""
from decimal import Decimal, localcontext
import json
from pathlib import Path


BASE = Path(__file__).resolve().parents[1]
DATA = BASE / "data"


def summary():
    plan = json.loads((DATA / "frozen_grid.json").read_text())["points"]
    prior = json.loads((BASE.parent / "nd_compensation" / "data" / "summary.json").read_text())
    values, refinements = {}, []
    with localcontext() as ctx:
        ctx.prec = 45
        for name in plan:
            base_path = DATA / f"{name}.json"
            refined_path = DATA / f"{name}_refined.json"
            sample = json.loads(base_path.read_text())["measured"]
            if refined_path.exists():
                refined = json.loads(refined_path.read_text())["measured"]
                a, b = [Decimal(m["incoming_area"]) for m in (sample, refined)]
                refinements.append({
                    "name": name, "relative_area_change": str(abs(a - b) / b),
                    "same_count": sample["incoming_lobes"] == refined["incoming_lobes"],
                })
                sample = refined
            values[name] = sample
        values.update({
            "zero_016_lead": prior["depth016_leading"],
            "zero_016_pred": prior["depth016_predicted"],
            "zero_020_lead": {"incoming_area": "5.7579023e-10", "incoming_lobes": 1},
            "zero_020_pred": {"incoming_area": "1.3523773e-11", "incoming_lobes": 1},
            "matched_020_lead": prior["matched_leading"],
            "matched_020_pred": prior["matched_predicted"],
        })
        rows = {"zero": {}, "matched": {}}
        for key, item in sorted(values.items()):
            mode, depth, setting = key.split("_")
            record = rows[mode].setdefault(depth, {})
            record[setting] = {"area": item["incoming_area"], "lobes": item["incoming_lobes"]}
        for subset in rows.values():
            for record in subset.values():
                record["reduction"] = str(Decimal(record["lead"]["area"]) / Decimal(record["pred"]["area"]))
        return {"depth_comparisons": rows, "refinement_checks": refinements}


if __name__ == "__main__":
    print(json.dumps(summary(), indent=2))
