"""Test the inner-derived setting directly in the full driven oscillator."""
import argparse
import json
from pathlib import Path

import gmpy2 as g
from splitting_mp import Integrator


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("epsilon")
    parser.add_argument("--output", required=True, type=Path)
    options = parser.parse_args()
    data = Path(__file__).resolve().parents[1] / "data"
    result = json.loads((data / "refined.json").read_text())
    g.get_context().precision = 210
    epsilon = g.mpfr(options.epsilon)
    c3 = g.mpfr(result["projections"][-1]["C3"]["re"])
    scaled_shift = c3 / (14 * g.const_pi() / 9)
    rho = g.mpfr(6) / 7 + scaled_shift * epsilon**2
    flow = Integrator(str(epsilon), str(rho), 48, 44, 16, "0")
    measurement = flow.measure(8, "1e-10")
    options.output.write_text(json.dumps({
        "epsilon": options.epsilon,
        "predicted_rho": str(rho),
        "shift_from_inner_C3": str(scaled_shift),
        "measurement": measurement,
    }, indent=2))
    print("PREDICTED", options.epsilon, str(rho), measurement["harmonics"][0]["amplitude"], flush=True)


if __name__ == "__main__":
    main()
