"""Symbolic identities for the pole-centred detuning response."""
import json
from pathlib import Path

import sympy as s


ROOT = Path(__file__).resolve().parents[1]
x, U, d, rho = s.symbols("x U d rho")
M = s.Matrix([[-1, 2 / U], [U, 0]])
A = s.Matrix([[1, 2 / U], [-U, -2]])
B = s.Matrix([[0, 0], [-U / 2, -1]])
q = s.Matrix([-1 / U, -s.Rational(1, 2)])


def vector(name):
    return s.Matrix(s.symbols(name + "N " + name + "w"))


def bilinear(first, second):
    return s.Matrix([
        0,
        -U**2 * first[0] * second[0] - U * (first[0] * second[1] + first[1] * second[0]),
    ])


def check(left, right):
    assert all(s.cancel(entry) == 0 for entry in left - right)


def main():
    equations = json.loads((ROOT / "third_order_hierarchy.json").read_text())["equations"]
    source = {
        record["name"]: s.Matrix([
            s.sympify(entry).subs(s.Symbol("tau"), -s.I * x) / s.I
            for entry in record["source"]
        ])
        for record in equations
    }
    check(B + B * M - M * B, A)
    variations = {d: 1}
    for name, change in (
        ("Z0", q),
        ("Zp", x * B * vector("X2")),
        ("Tm1", x * B * vector("Ym")),
    ):
        variations.update(dict(zip(vector(name), change)))

    def response(name):
        return s.Matrix([
            sum(s.diff(entry, key) * value for key, value in variations.items())
            for entry in source[name]
        ])

    check(response("Z0"), -M * q / x)
    check(response("Zm"), s.zeros(2, 1))
    check(response("Tm3"), s.zeros(2, 1))
    for output, input_name in (("Zp", "X2"), ("Tm1", "Ym")):
        check(response(output), A * vector(input_name) + x * B * source[input_name])

    first, second = vector("X2"), vector("Ym")
    bilinear_derivative = (
        x * (2 * bilinear(first, second) + bilinear(M * first, second)
             + bilinear(first, M * second) - M * bilinear(first, second))
        + x**2 * (bilinear(source["X2"], second) + bilinear(first, source["Ym"]))
    )
    check(response("Tp1"), A * vector("Yp") + x * B * source["Yp"] + bilinear_derivative)
    growing = s.Matrix([1, U])
    tangent = s.Matrix([1, -U / 2])
    assert s.cancel(s.det(s.Matrix.hstack(B * growing, tangent)) /
                    s.det(s.Matrix.hstack(growing, tangent))) == -1
    print("All coefficient identities and transverse cancellation checked exactly.")


if __name__ == "__main__":
    main()
