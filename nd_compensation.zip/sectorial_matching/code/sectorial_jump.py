"""Evaluate sectorial jumps for the finite inner hierarchy, using x=i*tau."""
import argparse
import json
from pathlib import Path
import time

import gmpy2 as g
import sympy as s


ROOT = Path(__file__).resolve().parents[1]
HIERARCHY = ROOT / "third_order_hierarchy.json"


def load_sources(rho, detuning):
    records = json.loads(HIERARCHY.read_text())["equations"]
    x, tau = s.symbols("x tau")
    names = {
        s.Symbol(record["name"] + suffix): (record["name"], component)
        for record in records for component, suffix in enumerate(("N", "w"))
    }
    parameters = {
        tau: -s.I * x,
        s.Symbol("U"): -1,
        s.Symbol("rho"): s.Rational(rho),
        s.Symbol("d"): s.Rational(detuning),
    }
    for record in records:
        terms = []
        for component in record["source"]:
            expression = s.expand(s.sympify(component).subs(parameters) / s.I)
            entries = []
            for term in s.Add.make_args(expression):
                if not term:
                    continue
                powers = term.as_powers_dict()
                exponent = int(powers.pop(x, 0))
                factors = tuple(sorted(
                    names[symbol] for symbol in powers if symbol in names
                    for _ in range(int(powers[symbol]))
                ))
                constant = term.subs({x: 1, **{symbol: 1 for symbol in names}})
                assert constant.is_Rational
                entries.append((g.mpq(str(constant)), exponent, factors))
            terms.append(entries)
        record["terms"] = terms
    return records


def laurent_multiply(left, right):
    result = {}
    for p, a in left.items():
        for q, b in right.items():
            result[p + q] = result.get(p + q, 0) + a * b
    return result


def laurent_source(record, series):
    result = [{}, {}]
    products = {(): {0: g.mpq(1)}}
    for destination, terms in zip(result, record["terms"]):
        for coefficient, exponent, factors in terms:
            if factors not in products:
                value = products[()]
                for name, component in factors:
                    value = laurent_multiply(value, series[name][component])
                products[factors] = value
            for power, value in products[factors].items():
                key = power + exponent
                destination[key] = destination.get(key, 0) + coefficient * value
    return result


def matrix(pair):
    first, second = pair
    return -first - 2 * second, -first


def eigen_components(pair):
    first, second = pair
    return (first - 2 * second) / 3, (2 * first + 2 * second) / 3


def physical_components(plus, minus):
    return plus + minus, -plus + minus / 2


def matching_data(records, depth):
    highest_power = {"X2": -2, "Ym": -1, "Yp": -1, "Zm": 0, "Z0": 1}
    series = {}
    log_coefficient = None
    for record in records:
        name = record["name"]
        if name not in highest_power:
            continue
        source = laurent_source(record, series)
        result = [{}, {}]
        k = record["fourier_index"]
        higher = (g.mpq(0), g.mpq(0))
        limit = -depth if name == "Z0" else -depth - 12
        for p in range(highest_power[name], limit - 1, -1):
            if k:
                mh = matrix(higher)
                value = tuple(
                    (source[j].get(p, g.mpq(0)) + mh[j] - (p + 1) * higher[j]) / (2 * k)
                    for j in range(2)
                )
                higher = value
            else:
                plus, minus = eigen_components(
                    tuple(source[j].get(p - 1, g.mpq(0)) for j in range(2))
                )
                if p == 1:
                    value = (g.mpq(1, 6), g.mpq(-1, 24))
                    assert plus == 0 and eigen_components(value)[1] * 3 == minus
                elif p == -2:
                    value = physical_components(-plus / 3, g.mpq(0))
                    log_coefficient = physical_components(g.mpq(0), minus)
                else:
                    value = physical_components(plus / (p - 1), minus / (p + 2))
            for j in range(2):
                result[j][p] = value[j]
        series[name] = result
    return series, log_coefficient


def initial_value(name, x, matching, logarithm, zero_depth, pole_gauge):
    result = []
    for component in range(2):
        value = sum(
            coefficient * x ** p for p, coefficient in matching[name][component].items()
            if p >= -zero_depth
        )
        if name == "Z0":
            value += logarithm[component] * g.log(x) / x**2
            value += pole_gauge * (1 if component == 0 else g.mpq(1, 2)) / x**2
        result.append(value)
    return result


def multiply(left, right, order):
    result = [g.mpc(0) for _ in range(order)]
    for i, a in enumerate(left[:order]):
        if a:
            for j, b in enumerate(right[:order - i]):
                result[i + j] += a * b
    return result


def power_series(x, exponent, order):
    values = [x**exponent]
    for k in range(1, order):
        values.append(values[-1] * (exponent - k + 1) / (k * x))
    return values


def polynomial_source(record, previous, powers, order):
    result = [[g.mpc(0) for _ in range(order)] for _ in range(2)]
    products = {}
    for component, terms in enumerate(record["terms"]):
        for coefficient, exponent, factors in terms:
            key = (exponent, factors)
            if key not in products:
                if factors:
                    name, index = factors[0]
                    value = previous[name][index]
                    for other_name, other_index in factors[1:]:
                        value = multiply(value, previous[other_name][other_index], order)
                    if exponent:
                        value = multiply(value, powers[exponent], order)
                else:
                    value = powers[exponent]
                products[key] = value
            value = products[key]
            for index, entry in enumerate(value[:order]):
                result[component][index] += coefficient * entry
    return result


def solution_jet(value, source, x, k, order):
    jet = [[g.mpc(entry)] for entry in value]
    for n in range(order):
        vn = jet[0][n], jet[1][n]
        mv = matrix(vn)
        for component in range(2):
            rhs = mv[component] - (n + 2 * k * x) * vn[component] + x * source[component][n]
            if n:
                rhs += source[component][n - 1] - 2 * k * jet[component][n - 1]
            jet[component].append(rhs / ((n + 1) * x))
    return jet


def horner(coefficients, h):
    value = g.mpc(0)
    for coefficient in reversed(coefficients):
        value = coefficient + h * value
    return value


def continue_to_real(records, point, values, order):
    a = point.imag
    count = max(1, int(g.ceil(a * 2)))
    h = -g.mpc(0, a / count)
    state = dict(values)
    for index in range(count):
        x = point + h * index
        powers = {p: power_series(x, p, order) for p in range(-3, 5)}
        jets = {}
        for record in records:
            name = record["name"]
            source = polynomial_source(record, jets, powers, order)
            jets[name] = solution_jet(state[name], source, x, record["fourier_index"], order)
        state = {name: [horner(jet, h) for jet in jets[name]] for name in jets}
    return state


def branch(records, radius, offset, order, depth, spacing, targets, pole_gauge):
    step = g.mpfr(spacing)
    segments = int(2 * radius / step)
    assert segments * step == 2 * radius
    points = [g.mpc(-radius + step * j, g.mpfr(offset)) for j in range(segments + 1)]
    powers = [
        {p: power_series(x, p, order) for p in range(-3, 5)}
        for x in points
    ]
    matching, logarithm = matching_data(records, depth)
    point_jets = [{} for _ in points]
    for record in records:
        name = record["name"]
        k = record["fourier_index"]
        indices = range(segments + 1) if k > 0 else range(segments, -1, -1)
        direction = step if k > 0 else -step
        if k <= 0 and name in matching:
            value = initial_value(name, points[-1], matching, logarithm, depth, pole_gauge)
        else:
            value = [g.mpc(0), g.mpc(0)]
        start = time.monotonic()
        for j in indices:
            source = polynomial_source(record, point_jets[j], powers[j], order)
            jet = solution_jet(value, source, points[j], k, order)
            point_jets[j][name] = jet
            value = [horner(component, direction) for component in jet]
        print("SOLVED", name, f"{time.monotonic() - start:.2f}s", flush=True)
    result = {}
    for target in targets:
        index = int((target + radius) / step)
        assert points[index].real == target
        values = {name: [entry[0] for entry in jet] for name, jet in point_jets[index].items()}
        result[target] = continue_to_real(records, points[index], values, order)
    return result


def graded_product(left, right):
    result = {}
    for (n, k), a in left.items():
        for (m, l), b in right.items():
            key = n + m, k + l
            if key[0] <= 3 and -key[0] <= key[1] <= 4 - key[0]:
                result[key] = result.get(key, 0) + a * b
    return result


def projected_jump(records, values, x):
    x = g.mpfr(x)
    fields = [{(0, 0): 1 / x}, {(0, 0): 1 / (2 * x)}]
    derivatives = [{(0, 0): -1 / x**2}, {(0, 0): -1 / (2 * x**2)}]
    delta = [{}, {}]
    scalar_jets = {name: [[value] for value in pair] for name, pair in values.items()}
    powers = {p: [x**p] for p in range(-3, 5)}
    for record in records:
        name = record["name"]
        k = record["fourier_index"]
        grade = record["epsilon_order"], k
        source = polynomial_source(record, scalar_jets, powers, 1)
        value = values[name]
        mv = matrix(value)
        for j in range(2):
            fields[j][grade] = value[j]
            delta[j][grade] = value[j].conjugate() - value[j]
            derivatives[j][grade] = mv[j] / x - 2 * k * value[j] + source[j][0]
    left = graded_product(delta[0], derivatives[1])
    right = graded_product(delta[1], derivatives[0])
    determinant = {key: left.get(key, 0) - right.get(key, 0) for key in left.keys() | right.keys()}
    base = fields[1][0, 0]
    perturbation = {key: -value / base for key, value in fields[1].items() if key != (0, 0)}
    inverse = {(0, 0): 1 / base}
    term = dict(inverse)
    for _ in range(7):
        term = graded_product(term, perturbation)
        for key, value in term.items():
            inverse[key] = inverse.get(key, 0) + value
    symplectic = graded_product(determinant, inverse)
    factor = g.exp(2 * x) / g.mpc(0, 3)
    return {f"C{n}": factor * symplectic.get((n, 1), 0) for n in (1, 3)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--rho", default="6/7")
    parser.add_argument("--detuning", default="0")
    parser.add_argument("--pole-gauge", default="0")
    parser.add_argument("--radius", type=int, default=64)
    parser.add_argument("--offset", default="3")
    parser.add_argument("--spacing", default=".5")
    parser.add_argument("--order", type=int, default=36)
    parser.add_argument("--depth", type=int, default=64)
    parser.add_argument("--digits", type=int, default=70)
    parser.add_argument("--targets", nargs="+", type=int, default=[8, 12, 16, 20])
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    g.get_context().precision = int(args.digits * 3.322) + 16
    records = load_sources(args.rho, args.detuning)
    started = time.monotonic()
    values = branch(
        records, args.radius, args.offset, args.order, args.depth, args.spacing,
        args.targets, g.mpq(args.pole_gauge)
    )
    results = []
    for target in args.targets:
        projection = projected_jump(records, values[target], target)
        result = {
            "x": target,
            **{name: {"re": str(value.real), "im": str(value.imag)} for name, value in projection.items()},
        }
        results.append(result)
        print("PROJECTION", json.dumps(result), flush=True)
    config = vars(args).copy()
    config.pop("output")
    args.output.write_text(json.dumps({
        "configuration": config,
        "projections": results,
        "wall_seconds": time.monotonic() - started,
    }, indent=2))


if __name__ == "__main__":
    main()
