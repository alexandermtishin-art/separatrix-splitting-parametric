"""Aggregate the sectorial and independent full-oscillator checks."""
import json
from pathlib import Path

import mpmath as mp


DATA = Path(__file__).resolve().parents[1] / "data"
mp.mp.dps = 70


def read(name):
    return json.loads((DATA / (name + ".json")).read_text())


def coefficient(case, name):
    return mp.mpf(read(case)["projections"][-1][name]["re"])


def number(value):
    return mp.nstr(value, 42)


def main():
    c1_direct = 4 * mp.pi / 3
    c3 = coefficient("refined", "C3")
    shift = c3 / (14 * mp.pi / 9)
    calibration = {
        "rho0_C1_error": abs(coefficient("calibration_rho0", "C1") - c1_direct),
        "rho1_C1_error": abs(coefficient("original", "C1") + 2 * mp.pi / 9),
        "rho6over7_refined_C1_residual": abs(coefficient("refined", "C1")),
        "C3_refinement_change": abs(c3 - coefficient("compensated", "C3")),
        "C3_pole_gauge_change_at_compensation": abs(c3 - coefficient("gauge", "C3")),
        "rho0_pole_gauge_law_error": abs(
            coefficient("gauge_rho0", "C3") - coefficient("calibration_rho0", "C3")
            - c1_direct / 2
        ),
        "C3_static_match_change": abs(c3 - coefficient("static_match", "C3")),
        "C3_unit_detuning_change": abs(c3 - coefficient("detuning_unit", "C3")),
    }
    assert max(calibration.values()) < mp.mpf("1e-24")
    roots = read("prior_full_system_roots")["rows"]
    extrapolations = []
    for count in (2, 3, 4):
        squares = [mp.mpf(row["eps"])**2 for row in roots[:count]]
        offsets = [mp.mpf(row["scaled_shift"]) for row in roots[:count]]
        matrix = mp.matrix([[square**j for j in range(count)] for square in squares])
        intercept = mp.lu_solve(matrix, mp.matrix(offsets))[0]
        extrapolations.append({
            "points": count, "intercept": number(intercept),
            "difference_from_inner_prediction": number(intercept - shift),
        })
    full_cases = []
    for name in ("008", "020"):
        case = read("predicted_" + name)
        baseline = mp.mpf(read("baseline_" + name)["harmonics"][0]["amplitude"])
        amplitude = mp.mpf(case["measurement"]["harmonics"][0]["amplitude"])
        full_cases.append({
            "epsilon": case["epsilon"], "predicted_rho": case["predicted_rho"],
            "baseline_first_harmonic": number(baseline),
            "predicted_first_harmonic": number(amplitude),
            "amplitude_reduction": number(baseline / amplitude),
        })
    summary = {
        "formal_C3_rho6over7": number(c3),
        "predicted_scaled_tuning_shift": number(shift),
        "conditional_normalized_residual": number(abs(c3) / c1_direct),
        "calibration_errors": {name: number(value) for name, value in calibration.items()},
        "prior_root_extrapolations": extrapolations,
        "full_oscillator_checks": full_cases,
        "scope": "Numerical convergence evidence and local Fourier amplitudes. "
                 "Uniform full-system matching and numerical interval certification remain open.",
    }
    (DATA / "comparison_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
