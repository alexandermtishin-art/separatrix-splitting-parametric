# Separatrix splitting of parametrically pumped oscillators beyond the Kerr approximation

Code and data for the manuscript of the same title (A.M. Tishin).

Requirements: Python 3.10+, numpy, scipy, numba, mpmath (with gmpy2 for speed), sympy, matplotlib.

## Layout

- `code/` — all scripts. Paths are relative to the package root; data are written to `data/`.
- `data/` — numerical results used in the tables and figures.
- `figures/` — figures of the manuscript.

## What reproduces what

| Result | Script | Output |
|---|---|---|
| Direct splitting, double precision (Sec. 3; Tables 2, 3, 8; Fig. 2) | `split.py`, `gather.py` | `data/splitting.json` |
| Direct splitting, 34-digit Taylor integrator (Tables 2, 3) | `split_mp.py`, `run_mp.sh` (`bash run_mp.sh M`, `bash run_mp.sh M0`) | `data/mp_M.txt`, `data/mp_M0.txt` |
| Phase-invariant oscillator M_E with the Duffing energy–action law (Tables 2–4) | `model_MD.py`, `run_MD.py` | `data/MD.json` |
| Action–angle Melnikov integral, Eq. (10) (Sec. 5, Table 3) | `ell_exact.py`, `ell_cheb.py`, `ell_h2.py`, `ell_D.py`, `gather_theory.py`, `gather_theory2.py` (eps = 0.20–0.32) | `data/theory.json` |
| m = 4 channel check (Sec. 5.2) | `channel4.py` | `data/channel4.txt` |
| Second-order static term (App. B) | `heff.py` (symbolic), `duffing_omega_check.py` (numerical check at beta = 0.1) | printed |
| Singular time, Eqs. (11)–(14), Table 4 (c0, a1, b1, d1 from `data/resid_small.json`), Fig. 3 | `imtstar_exact.py`, `imt_sextic.py`, `param_free.py`, `imt_small.py`, `fig_data2.py` | `data/singular_time.txt`, `data/resid_small.json`, `data/fig_data2.json` |
| Constant kappa fixed at one pump depth, free-exponent fit, local exponent (Sec. 6.1–6.2, Table 5, Eq. (15)) | `kappa_calib.py` | printed |
| Convergence of the 34-digit splitting at eps = 0.06, 0.08, 0.10 (Table C1); 34-digit M at eps = 0.20 (`data/mp_M020.txt`) | `split_mp2.py` with `NSTEP`, `U0` environment variables and dps argument | `data/conv_mp.txt` |
| Sextic oscillators (Table 4) | `test_sextic.py`, `test_sextic_neg.py` | `data/sextic.txt`, `data/sextic_neg.txt` |
| Layer width (Table 7) | `width.py` (`python3 code/width.py all 200000`) | `data/width_all.json`, `data/width_all.txt` |
| Passage times and Lyapunov exponents, flow (Table 8, App. C) | `table7_many.py` (32 independent orbits per case; uses `table7_flow.py`); step and start checks: `table7_flow.py` (`python3 code/table7_flow.py 80 1e-4 M24`), `lyap8.py` | `data/table7_many.json`, `data/table7_many.txt`, `data/table5_y8_*` |
| Passage times and Lyapunov exponents, separatrix map (Table 8, Sec. 7.2) | `map_table7_matched.py` (32 runs matched to the flow passage count); `map_table7.py` (runs of 10^6 iterations, last column) | `data/map_table7_matched.json`, `data/map_table7.json` |
| Kerr-separatrix Melnikov quadratures (Table 2, Sec. 4) | `gather.py`, `melD.py`, `melS.py`; with and without the detuning: `ks_detuned.py` | `data/splitting.json`, `data/ks_detuned.json` |
| Softening nonlinearity, U < 0 (Sec. 6.3, Table 6, Fig. 4) | `test_soft.py`, `test_pendulum.py`, `soft_diag.py` (`small`, `fail`, `conv`, `osc`, `osc2`, `grid1`, `grid2`, `g17a`, `g17b`, `bisect`), `imt_pend.py`, `fig4.py` | `data/soft.json`, `data/pendulum.txt`, `data/soft_diag_*.txt`, `data/soft_grid*.txt`, `data/soft_all.json`, `data/table5_rows.md` |
| Softening cases in 34 digits | `split_mp2.py` with beta = -4/3 | `data/mp_soft*.txt`, `data/mp_g26_010.txt` |
| Model D in 34 digits (Sec. 5.3) | `split_mp2.py D eps 16` | `data/mp_D.txt` |
| Free frequency of the softening sextic oscillators, secondary resonance, reconnection estimate and lobe excursion (Sec. 6.3) | `soft_actions.py`, `soft_lobe.py`, `soft_reconnect.py` | printed |
| Lobe area of the separatrix, map vs K0 (App. B) | `lobe_area.py` (`python3 code/lobe_area.py 0.10 0.12 0.14 0.16 0.24`) | `data/lobe_area.txt` |
| 34-digit integrator with sextic term, arbitrary beta, model D | `split_mp2.py` (`python3 code/split_mp2.py M\|M0\|D eps nph [beta gamma dps]`) | printed |
| Decomposition of the second-order static term (Sec. 5.3, 6.1) | `h2_diag.py` | printed |
| Layer width from the separatrix map (Table 7) | `map_width.py` | printed |
| Figures | `fig1.py`, `fig_data.py`, `fig_data2.py`, `figs2.py`, `fig4.py` | `figures/` |

Units: small-amplitude frequency 1, pump frequency 2, Kerr coefficient U = 1 (beta = 4/3).

## License

MIT (see `LICENSE`).
