import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Model C flow: Lyapunov sum and saddle-passage count accumulated per segment (to test stationarity)."""
import numpy as np, sys
from numba import njit
sys.path.insert(0,HERE)
from core import f as fC
@njit(cache=True)
def series(a0r, a0i, eps, nu, U, Ttr, Tseg, nseg, dt, nlo, nhi):
    par = np.array([1.0, eps, nu, 0.0, 0.0])
    y = np.zeros(6); y[0] = a0r; y[1] = a0i; y[2] = 1.0
    t = 0.0
    for i in range(int(Ttr/dt)):
        k1 = fC(t, y, 1, par, U); k2 = fC(t+dt/2, y+dt/2*k1, 1, par, U); k3 = fC(t+dt/2, y+dt/2*k2, 1, par, U); k4 = fC(t+dt, y+dt*k3, 1, par, U)
        y = y + dt/6*(k1+2*k2+2*k3+k4); t += dt
        if i % 50 == 0:
            nr = np.sqrt(y[2]**2+y[4]**2); y[2] /= nr; y[4] /= nr
    nr = np.sqrt(y[2]**2+y[4]**2); y[2] /= nr; y[4] /= nr
    S = np.zeros(nseg); NP = np.zeros(nseg); armed = False
    nst = int(Tseg/dt)
    for k in range(nseg):
        for i in range(nst):
            k1 = fC(t, y, 1, par, U); k2 = fC(t+dt/2, y+dt/2*k1, 1, par, U); k3 = fC(t+dt/2, y+dt/2*k2, 1, par, U); k4 = fC(t+dt, y+dt*k3, 1, par, U)
            y = y + dt/6*(k1+2*k2+2*k3+k4); t += dt
            n = y[0]**2 + y[1]**2
            if n > nhi: armed = True
            if armed and n < nlo:
                NP[k] += 1; armed = False
            if (i+1) % 50 == 0:
                nr = np.sqrt(y[2]**2+y[4]**2); S[k] += np.log(nr); y[2] /= nr; y[4] /= nr
    return S, NP
