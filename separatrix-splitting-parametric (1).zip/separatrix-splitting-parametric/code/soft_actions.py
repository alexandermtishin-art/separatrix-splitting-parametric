import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Accurate actions of frequency minimum and return to resonance for V=q^2/2-q^4/3+g q^6/6;
width of the secondary resonance zone; maximal action reached by the unstable manifold (gamma=26/15)."""
import sys, numpy as np
from scipy.integrate import quad, solve_ivp
from scipy.optimize import brentq, minimize_scalar
b=-4/3
def funcs(A,g):
    V=lambda q: q*q/2+b*q**4/4+g*q**6/6; E=V(A)
    f=lambda th: 2*(E-V(A*np.sin(th)))
    T=4*quad(lambda th: A*np.cos(th)/np.sqrt(f(th)),0,np.pi/2,limit=400,epsabs=1e-13,epsrel=1e-12)[0]
    J=(2/np.pi)*quad(lambda th: A*np.cos(th)*np.sqrt(f(th)),0,np.pi/2,limit=400,epsabs=1e-13,epsrel=1e-12)[0]
    Q2=None
    return J,2*np.pi/T,E
for g in [8/15,17/15,26/15]:
    om=lambda A: funcs(A,g)[1]
    r=minimize_scalar(om,bounds=(0.05,2.5),method='bounded',options={'xatol':1e-10}); Amin=r.x
    A1=brentq(lambda A: om(A)-1,Amin,4.0,xtol=1e-12)
    J1,_,E1=funcs(A1,g); Jm,omm,_=funcs(Amin,g)
    # omega'(J) at J1
    dA=1e-4; Jp,op,_=funcs(A1+dA,g); Jq,oq,_=funcs(A1-dA,g); dom=(op-oq)/(Jp-Jq)
    print('gamma %.4f  omin %.4f at J %.4f ; omega=1 at J %.4f (E %.4f) ; domega/dJ %.3f'%(g,omm,Jm,J1,E1,dom),flush=True)
print('--- secondary resonance vs primary separatrix (first order K = F + (eps/2) Q2 cos2psi)')
from scipy.integrate import solve_ivp
def Q2of(A,g):
    # q(t) over one period from turning point, Fourier coeff of q^2 at 2*theta
    J,om,E=funcs(A,g); T=2*np.pi/om
    s=solve_ivp(lambda t,y:[y[1],-(y[0]+b*y[0]**3+g*y[0]**5)],(0,T),[A,0],rtol=1e-12,atol=1e-14,dense_output=True)
    t=np.linspace(0,T,4001)[:-1]; q=s.sol(t)[0]
    return 2*np.mean(q*q*np.cos(2*om*t))
for g in [8/15,17/15,26/15]:
    om=lambda A: funcs(A,g)[1]
    Amin=minimize_scalar(om,bounds=(0.05,2.5),method='bounded',options={'xatol':1e-10}).x
    A1=brentq(lambda A: om(A)-1,Amin,4.0,xtol=1e-12); J1,_,E1=funcs(A1,g); F=E1-J1; Q2=Q2of(A1,g)
    print('gamma %.4f J2 %.4f F(J2) %.4f Q2 %.4f  eps_c=-2F/Q2 = %.3f'%(g,J1,F,Q2,-2*F/Q2))
