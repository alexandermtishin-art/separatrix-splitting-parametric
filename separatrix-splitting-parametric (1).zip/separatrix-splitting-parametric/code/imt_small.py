import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
import sys, json, numpy as np
sys.argv=['x']
import importlib.util
spec=importlib.util.spec_from_file_location('S',''+HERE+'imt_sextic.py')
src=open(''+HERE+'imt_sextic.py').read().split('TAB={}')[0]
ns={}; exec(src,ns)
gams=[0.0,8/15,17/15,26/15,34/15]
ns['TAB']={g:ns['table'](g,Amax=40.0,N=800) for g in gams}
# small-A extension: table starts at A=1e-3 (J~5e-7) fine for eps>=1e-4
eps=np.geomspace(1e-4,0.28,30); out={}
for g in gams:
    p=17/9-5*g/3
    R=[2*(ns['imt'](e,g)-ns['imt'](e,g,False))-p*np.log(1/e) for e in eps]
    out[str(g)]=R
    X=np.c_[np.ones_like(eps),eps,eps*np.log(eps),eps**2]; m=eps<0.1
    co=np.linalg.lstsq(X[m],np.array(R)[m],rcond=None)[0]; co2=np.linalg.lstsq(X[m][:,[0,1,3]],np.array(R)[m],rcond=None)[0]
    res4=np.abs(X[m]@co-np.array(R)[m]).max(); res3=np.abs(X[m][:,[0,1,3]]@co2-np.array(R)[m]).max()
    print('gamma %.4f p %+.3f  R(1e-4)=%.4f R(1e-3)=%.4f R(1e-2)=%.4f | fit c+a e+b e ln e+d e^2: c=%.4f a=%.2f b=%.2f (maxres %.1e) | without e ln e: maxres %.1e'%(g,p,R[0],R[np.argmin(abs(eps-1e-3))],R[np.argmin(abs(eps-1e-2))],co[0],co[1],co[2],res4,res3),flush=True)
json.dump({'eps':eps.tolist(),'R':out},open(''+DATA+'resid_small.json','w'))
