import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Final data for the manuscript: Mathieu-Duffing (M), phase-invariant control (M0), lab model D, D0, S, and model C."""
import sys, json, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import split
from scipy.integrate import solve_ivp
from melD import homoclinic, kick
from melS import kickS
nu=2.0; U=1.0; b0=4/3
orig=split.rhs; origmono=split.monodromy
def rhs(model,eps,s=0.0):
    if model=='M':
        return lambda t,y:[y[1],-(1+2*eps*np.cos(nu*t))*y[0]-b0*y[0]**3]
    if model=='M0':
        def f(t,y):
            q,p=y; n=0.5*(q*q+p*p); return [p*(1+U*n),-(1+2*eps*np.cos(nu*t))*q-U*n*q]
        return f
    if model=='D0':
        def f(t,y):
            Om=1+eps*np.cos(nu*t); q,p=y; n=0.5*(q*q+p*p); return [p*(1+U*n),-Om*Om*q-U*n*q]
        return f
    return orig(model,eps,s)
def monoM(eps):
    f=lambda t,y:(np.array([[0,1],[-(1+2*eps*np.cos(nu*t)),0]])@y.reshape(2,2)).ravel()
    M=solve_ivp(f,(0,split.Tp),np.eye(2).ravel(),rtol=1e-13,atol=1e-15,method='DOP853').y[:,-1].reshape(2,2)
    w,V=np.linalg.eig(M); i=np.argmax(abs(w)); eu=np.real(V[:,i]); es=np.real(V[:,1-i]); L=np.real(w[i])
    es=es/(eu[0]*es[1]-eu[1]*es[0]); return eu,es,L,np.log(abs(L))/split.Tp
split.rhs=rhs
def melRWA_M(eps,inv=False):
    """first-order Melnikov in RWA frame for M (all counter-rotating terms kept); inv: phase-invariant Kerr"""
    g=eps*nu/4; d=0.0; t,c=homoclinic(g,d,U); n=abs(c)**2; grad=d*np.conj(c)+U*n*np.conj(c)+g*c
    t0s=np.linspace(0,2*np.pi/nu,24,endpoint=False); res=[]
    for t0 in t0s:
        tt=t+t0; a=c*np.exp(-1j*nu*tt/2)
        adot=-1j*a-1j*(eps*np.cos(nu*tt)/2)*2*(a+np.conj(a))
        adot+= -1j*U*n*a if inv else -1j*(b0/16)*4*(a+np.conj(a))**3
        cdot=(adot+1j*nu/2*a)*np.exp(1j*nu*tt/2); cp=cdot-(-1j*(d+U*n)*c-1j*g*np.conj(c))
        res.append(np.trapezoid(2*np.real(grad*cp),t))
    X=np.c_[np.sin(nu*t0s),np.cos(nu*t0s)]; co=np.linalg.lstsq(X,np.array(res),rcond=None)[0]
    return float(np.hypot(*co))
out={}
for eps in [0.13,0.14,0.16,0.18,0.20,0.22,0.24,0.26,0.28,0.32]:
    r={}
    split.monodromy=monoM
    for m in ['M','M0']:
        s=split.splitting(m,eps,0.0,nph=16,u0=1e-6); r[m]=s['W1']; r[m+'_res']=s['fitres']
    r['hF_M']=s['hF']
    split.monodromy=origmono
    for m,sv in [('D',0),('D0',0),('S',2),('C',0)]:
        s=split.splitting(m,eps,float(sv),nph=16,u0=1e-6); r[m]=s['W1']; r[m+'_res']=s['fitres']
    r['hF_D']=s['hF']
    r['melRWA_M']=melRWA_M(eps); r['melRWA_M0']=melRWA_M(eps,True)
    r['melRWA_D']=float(kickS(eps,0)); r['melRWA_S']=float(kickS(eps,2)); r['melRWA_C']=float(kick('C',eps)[0])
    out[eps]=r
    print(eps,{k:('%.4e'%v) for k,v in r.items() if not k.endswith('_res')},flush=True)
    json.dump({str(k):v for k,v in out.items()},open(''+DATA+'splitting.json','w'),indent=1)
