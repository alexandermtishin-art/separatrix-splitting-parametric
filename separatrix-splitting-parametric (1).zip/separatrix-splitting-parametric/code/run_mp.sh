for e in 0.14 0.12 0.10 0.09 0.08 0.07 0.06; do python3 -I split_mp.py $1 $e 8 | grep RESULT; done
