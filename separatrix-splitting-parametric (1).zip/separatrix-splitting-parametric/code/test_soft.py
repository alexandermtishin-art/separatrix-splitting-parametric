import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""U<0: V = q^2/2 + beta q^4/4 + gamma q^6/6 with beta=-4/3 (U=-1); control M0 with U=-1.
Predicted p = -(4/3) omega2/(U|U|) = 4 c3, c3 = -17 beta^2/64 + 5 gamma/12 = -17/36 + 5 gamma/12."""
import sys, json, numpy as np
sys.path.insert(0,HERE)
import split
from split import nu
from scipy.integrate import solve_ivp
b0=-4/3; U=-1.0
def monoM(eps):
    f=lambda t,y:(np.array([[0,1],[-(1+2*eps*np.cos(nu*t)),0]])@y.reshape(2,2)).ravel()
    M=solve_ivp(f,(0,split.Tp),np.eye(2).ravel(),rtol=1e-13,atol=1e-15,method='DOP853').y[:,-1].reshape(2,2)
    w,V=np.linalg.eig(M); i=np.argmax(abs(w)); eu=np.real(V[:,i]); es=np.real(V[:,1-i]); L=np.real(w[i])
    es=es/(eu[0]*es[1]-eu[1]*es[0]); return eu,es,L,np.log(abs(L))/split.Tp
split.monodromy=monoM
def rhs(model,eps,s=0.0):
    if model=='M0':
        def f(t,y):
            q,p=y; n=0.5*(q*q+p*p); return [p*(1+U*n),-(1+2*eps*np.cos(nu*t))*q-U*n*q]
        return f
    g=float(model[1:])
    return lambda t,y:[y[1],-(1+2*eps*np.cos(nu*t))*y[0]-b0*y[0]**3-g*y[0]**5]
split.rhs=rhs
gams={'8/15':8/15,'17/15':17/15,'26/15':26/15}
out={}
for eps in [0.14,0.16,0.20,0.24,0.28]:
    r0=split.splitting('M0',eps,nph=16,u0=1e-6); row={'M0':(r0['W1'],r0['fitres'])}
    for lab,g in gams.items():
        r=split.splitting('G%.12f'%g,eps,nph=16,u0=1e-6); row[lab]=(r['W1'],r['fitres'])
    out[eps]=row
    print('eps %.2f  M0 %.4e | '%(eps,row['M0'][0])+' | '.join('g=%s: %.4e ratio %.4e (res %.0e)'%(k,v[0],v[0]/row['M0'][0],v[1]) for k,v in row.items() if k!='M0'),flush=True)
    json.dump({str(k):v for k,v in out.items()},open(''+DATA+'soft.json','w'))
