import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Exact elliptic action-angle Melnikov, Chebyshev-tabulated in x=A^2 (accuracy ~1e-14)."""
import sys, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from numpy.polynomial import chebyshev as C
from scipy.integrate import solve_ivp
import ell_exact as EE
NM=EE.NM; XMAX=1.6; DEG=90
xs=XMAX*(1-np.cos(np.pi*(np.arange(400)+0.5)/400))/2   # Chebyshev nodes on [0,XMAX]
def fit(vals): return C.chebfit(2*xs/XMAX-1,vals,DEG)
J,om,Q0,Q=EE.basic(np.sqrt(xs))
cJ=fit(J); com=fit(om); cJx=fit(J/xs); cR2=fit(Q[0]/J); cQ0=fit(Q0); cQ=[fit(Q[i]) for i in range(NM)]
dc=lambda c: C.chebder(c)*2/XMAX
cJd=dc(cJ); cQ0d=dc(cQ0); cQd=[dc(c) for c in cQ]
def ev(c,x): return C.chebval(2*x/XMAX-1,c)
def funcs(x):
    dJ=ev(cJd,x)
    return ev(cJ,x),ev(com,x),ev(cQ0,x),np.array([ev(c,x) for c in cQ]),dJ,ev(cQ0d,x)/dJ,np.array([ev(c,x) for c in cQd])/dJ
xt=np.linspace(1e-4,XMAX*0.95,50); Je,ome,Q0e,Qe=EE.basic(np.sqrt(xt)); Jf,omf,Q0f,Qf,_,_,_=funcs(xt)
print('cheb max err: J %.1e om %.1e Q2 %.1e Q4 %.1e'%(abs(Je-Jf).max(),abs(ome-omf).max(),abs(Qe[0]-Qf[0]).max(),abs(Qe[1]-Qf[1]).max()),flush=True)
def homoclinic(eps,d2,span=16,N=60001):
    def rhs(t,y):
        x,psi=y; z=2*x/XMAX-1
        dJ=C.chebval(z,cJd); om=C.chebval(z,com); Jv=x*C.chebval(z,cJx); Q2=Jv*C.chebval(z,cR2); dQ2=C.chebval(z,cQd[0])/dJ
        Jdot=eps*Q2*np.sin(2*psi); psidot=om-1+d2+(eps/2)*dQ2*np.cos(2*psi)
        return [Jdot/dJ,psidot]
    e=lambda t,y: y[1]-np.pi/2; e.terminal=True; h=eps/2
    s=solve_ivp(rhs,(0,300/h),[1e-12,0.5*np.arccos(np.clip(-2*d2/eps,-1,1))],events=e,rtol=1e-13,atol=1e-26,method='DOP853',dense_output=True)
    tt=s.t_events[0][0]; tl=np.linspace(-span/h,0,N); tl=tl[tt+tl>0]
    y=s.sol(tt+tl); x,psi=y
    t=np.r_[tl,-tl[-2::-1]]; x=np.r_[x,x[-2::-1]]; psi=np.r_[psi,np.pi-psi[-2::-1]]
    return t,x,psi
def melnikov(eps,d2,nt0=24,span=16):
    t,x,psi=homoclinic(eps,d2,span)
    J,om,Q0,Q,dJ,dQ0,dQ=funcs(x)
    K0J=om-1+d2+(eps/2)*dQ[0]*np.cos(2*psi); K0p=-eps*Q[0]*np.sin(2*psi)
    m=2*np.arange(1,NM+1)[:,None]; t0s=np.linspace(0,np.pi,nt0,endpoint=False); res=[]
    for t0 in t0s:
        T=t+t0; th=psi+T; c2=np.cos(2*T)
        Pp=-eps*c2*np.sum(m*Q*np.sin(m*th),0)+eps*Q[0]*np.sin(2*psi)
        PJ=eps*c2*(dQ0+np.sum(dQ*np.cos(m*th),0))-(eps/2)*dQ[0]*np.cos(2*psi)
        res.append(np.trapezoid(-K0J*Pp+K0p*PJ,t))
    res=np.array(res); X=np.c_[np.sin(2*t0s),np.cos(2*t0s),np.sin(4*t0s),np.cos(4*t0s),np.ones(nt0)]
    co=np.linalg.lstsq(X,res,rcond=None)[0]
    return np.hypot(co[0],co[1]),np.hypot(co[2],co[3]),np.abs(res-X@co).max()
if __name__=='__main__':
    direct={0.14:1.4559e-12,0.16:3.4785e-11,0.20:3.2481e-09,0.24:7.2775e-08,0.28:7.1140e-07}
    for eps,Wd in direct.items():
        for d2 in [0.0,-eps**2/16]:
            for span in ([16,13] if d2==0 else [16]):
                W,W2,r=melnikov(eps,d2,span=span)
                print('eps %.2f d2 %+.5f span %d  ellMel %.4e  direct %.4e  ratio %.3f  (2nd %.1e res %.1e)'%(eps,d2,span,W,Wd,Wd/W,W2,r),flush=True)
