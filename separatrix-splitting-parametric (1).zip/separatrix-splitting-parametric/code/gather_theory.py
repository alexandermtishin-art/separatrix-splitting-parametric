import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
import sys, json, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import ell_cheb as B0
import ell_h2 as H
import ell_D as DD
out={}
for eps in [0.13,0.14,0.16,0.18,0.20,0.22,0.24,0.26,0.28,0.32]:
    r={}
    r['ell1_M']=float(B0.melnikov(eps,0.0)[0])          # elliptic first order, no static 2nd-order term
    r['ell2_M']=float(H.melnikov(eps)[0])                # + full static second-order H2
    t,x,psi=H.homoclinic(eps); J,om,Q0,Q,dJ,dQ0,dQ=H.B.funcs(x)
    r['FT_M']=float(2*eps*abs(np.trapezoid(Q0*np.cos(2*t),t)))
    r['FT_M_qJ']=float(2*eps*abs(np.trapezoid(J*np.cos(2*t),t)))
    r['ell2_D']=float(DD.melnikov(eps)[0])
    out[eps]=r; print(eps,{k:'%.4e'%v for k,v in r.items()},flush=True)
    json.dump({str(k):v for k,v in out.items()},open(''+DATA+'theory.json','w'),indent=1)
