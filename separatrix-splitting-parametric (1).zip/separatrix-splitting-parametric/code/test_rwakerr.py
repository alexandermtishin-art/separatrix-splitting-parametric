import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Hypothesis test: lab-frame Duffing with Kerr replaced by its phase-invariant average (U/2) n0^2, n0=(q^2+p^2)/2."""
import sys, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import split
from split import splitting, nu, U
from melD import homoclinic
def rhs_D0(model,eps,s=0.0):
    if model!='D0': return orig(model,eps,s)
    def f(t,y):
        Om=1+eps*np.cos(nu*t); q,p=y; n=0.5*(q*q+p*p)
        return [p*(1+U*n), -Om*Om*q-U*n*q]
    return f
orig=split.rhs; split.rhs=rhs_D0
def kickD0(eps,O0=1.0):
    g=eps*nu/4; d=O0-nu/2+eps**2*O0/4
    t,c=homoclinic(g,d,U); n=abs(c)**2; grad=d*np.conj(c)+U*n*np.conj(c)+g*c
    t0s=np.linspace(0,2*np.pi/nu,24,endpoint=False); res=[]
    for t0 in t0s:
        tt=t+t0; a=c*np.exp(-1j*nu*tt/2)
        mod=(O0/4)*(2*eps*np.cos(nu*tt)+eps**2*np.cos(nu*tt)**2)
        adot=-1j*O0*a-1j*mod*2*(a+np.conj(a))-1j*U*n*a
        cdot=(adot+1j*nu/2*a)*np.exp(1j*nu*tt/2)
        cp=cdot-(-1j*(d+U*n)*c-1j*g*np.conj(c))
        res.append(np.trapezoid(2*np.real(grad*cp),t))
    X=np.c_[np.sin(nu*t0s),np.cos(nu*t0s)]; co=np.linalg.lstsq(X,np.array(res),rcond=None)[0]
    return np.hypot(*co)
for eps in [0.16,0.20,0.24]:
    r=splitting('D0',eps,nph=16); m=kickD0(eps)
    print('D0 eps %.2f direct %.4e  melnikov %.4e  ratio %.3f  fitres %.1e'%(eps,r['W1'],m,r['W1']/m,r['fitres']),flush=True)
