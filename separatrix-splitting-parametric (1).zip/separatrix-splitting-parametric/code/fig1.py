import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Figures for ms3. Palette: categorical slots of the dataviz reference instance; markers give secondary encoding."""
import json, re, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'serif','font.serif':['DejaVu Serif'],'font.size':10,'axes.linewidth':0.8,
                     'axes.spines.top':False,'axes.spines.right':False,'legend.frameon':False,'lines.linewidth':1.6})
BLUE,ORANGE,AQUA,YELLOW,MAGENTA,GREEN='#2a78d6','#eb6834','#1baf7a','#eda100','#e87ba4','#008300'
INK='#222222'; GRID='#e6e6e3'
D=DATA
sp=json.load(open(D+'splitting.json'))
def col(key,emin=0.13,emax=0.32,exclude=()):
    e=sorted(float(k) for k in sp if emin<=float(k)<=emax and float(k) not in exclude)
    return np.array(e),np.array([sp[str(x) if str(x) in sp else repr(x)][key] for x in e])
def get(key,e): return sp[str(e)][key]

# Fig. 1

fd=json.load(open(D+'fig_data.json'))
fig,ax=plt.subplots(1,1,figsize=(5.2,3.2))
ph=np.array(fd['phase']); wM=np.array(fd['wM']); wM0=np.array(fd['wM0'])
pp=np.linspace(0,2*np.pi,400)
for w,c,m,lab in [(wM0,AQUA,'s','M$_0$ (phase-invariant Kerr)'),(wM*100,BLUE,'o','M (Duffing), $\\times100$')]:
    w=w*1e7; X=np.c_[np.ones_like(ph),np.sin(ph),np.cos(ph),np.sin(2*ph),np.cos(2*ph)]; co=np.linalg.lstsq(X,w,rcond=None)[0]
    ax.plot(pp,co[0]+co[1]*np.sin(pp)+co[2]*np.cos(pp)+co[3]*np.sin(2*pp)+co[4]*np.cos(2*pp),color=c,lw=1.4)
    ax.plot(ph,w,m,color=c,ms=5,mec='white',mew=0.8,label=lab)
ax.axhline(0,color=GRID,lw=0.8,zorder=0)
ax.set_xlabel('phase along the unstable manifold, $2\\pi j/N$'); ax.set_ylabel('$h_F\\,us$ at return ($10^{-7}$)')
ax.set_xlim(0,2*np.pi); ax.set_xticks([0,np.pi,2*np.pi]); ax.set_xticklabels(['0','$\\pi$','$2\\pi$'])
ax.legend(loc='upper right',fontsize=8.5)
fig.tight_layout(); fig.savefig(ROOT+'figures/fig1_samples.png',dpi=300); plt.close(fig)
print('ok')
