import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
import sys, re, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import imt_sextic as S
meas={}
for fn,keys in [(''+DATA+'sextic.txt',[0.0,8/15,17/15]),(''+DATA+'sextic_neg.txt',[34/15,(17/9+1)*3/5])]:
    for l in open(fn):
        if not l.startswith('eps'): continue
        e=float(l.split()[1]); rs=[float(x) for x in re.findall(r'ratio ([0-9.e+-]+)',l)]
        for g,r in zip(keys,rs): meas.setdefault(g,{})[e]=r
for g in sorted(meas):
    vals=[]
    for e,r in sorted(meas[g].items()):
        D=2*(S.imt(e,g)-S.imt(e,g,False)); vals.append(np.log(r)+D)
    vals=np.array(vals); pr=[ np.log(r) for e,r in sorted(meas[g].items())]
    print('gamma %.4f  ln(W/W0)+nu*Delta at eps=.14,.16,.20,.24,.28: %s   spread %.3f   (spread of ln(W/W0) alone %.3f)'%(g,' '.join('%.3f'%v for v in vals),vals.max()-vals.min(),max(pr)-min(pr)),flush=True)
