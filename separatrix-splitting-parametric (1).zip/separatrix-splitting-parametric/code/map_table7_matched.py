import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Table 7, map column with runs matched to the flow: 32 map runs per case, each with the number of
iterations equal to the mean number of passages of one flow orbit (10^5 pump periods)."""
import sys, json, numpy as np
sys.path.insert(0,HERE)
from map_table7 import run, cases
from width import mono
flow=json.load(open(DATA+'table7_many.json')); Tseg=1e4*np.pi
out={}
for lab,m,e,W in cases:
    k='%s_%.2f'%(lab,e); v=flow[k]
    S=np.array([x[0] for x in v]); N=np.array([x[1] for x in v])
    lamF=S.sum(1)/(10*Tseg); TF=10*Tseg/N.sum(1); npass=int(N.sum(1).mean())
    eu,es,h=mono(e,m); g=e/2; C=8*h**4/g**2; lam=2/h
    r=np.array([run(W,h,C,lam,npass,100+s) for s in range(32)])
    TM,LM=r[:,0],r[:,1]
    d=lambda a,b: 100*(a.mean()/b.mean()-1)
    se=lambda a: a.std(ddof=1)/np.sqrt(len(a))
    z=(LM.mean()-lamF.mean())/np.hypot(se(LM),se(lamF))
    out[k]=dict(npass=npass,T_flow=TF.mean(),sT_flow=se(TF),T_map=TM.mean(),sT_map=se(TM),lam_flow=lamF.mean(),slam_flow=se(lamF),lam_map=LM.mean(),slam_map=se(LM),devT=d(TM,TF),devL=d(LM,lamF),z=z)
    print('%s %.2f npass %d  T flow %.1f(%.1f) map %.1f(%.1f) dev %+.1f%% | lam flow %.4f(%.4f) map %.4f(%.4f) dev %+.0f%% z %.1f'%(lab,e,npass,TF.mean(),se(TF),TM.mean(),se(TM),d(TM,TF),lamF.mean(),se(lamF),LM.mean(),se(LM),d(LM,lamF),z),flush=True)
json.dump(out,open(DATA+'map_table7_matched.json','w'),indent=1)
