import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Eq. (10) quadratures for models M and D at given pump depths (one JSON file per depth)."""
import sys, json, numpy as np
sys.path.insert(0,HERE)
import ell_h2 as H
import ell_D as DD
for eps in [float(a) for a in sys.argv[1:]]:
    r={}
    r['ell2_M']=float(H.melnikov(eps)[0])
    t,x,psi=H.homoclinic(eps); J,om,Q0,Q,dJ,dQ0,dQ=H.B.funcs(x)
    r['FT_M']=float(2*eps*abs(np.trapezoid(Q0*np.cos(2*t),t)))
    r['FT_M_qJ']=float(2*eps*abs(np.trapezoid(J*np.cos(2*t),t)))
    r['ell2_D']=float(DD.melnikov(eps)[0])
    print(eps,{k:'%.4e'%v for k,v in r.items()},flush=True)
    json.dump(r,open(DATA+'theory_%.2f.json'%eps,'w'))
