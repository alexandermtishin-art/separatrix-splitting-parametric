import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Singular time (11) for V=q^2/2+b q^4/4+g q^6/6 from numerically computed action-angle functions."""
import numpy as np
from scipy.integrate import solve_ivp, quad
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq
b=4/3; U=1.0
def table(g,Amax=40.0,N=500):
    As=np.geomspace(1e-3,Amax,N); out=[]
    xg,wg=np.polynomial.legendre.leggauss(200)
    for A in As:
        E=A*A/2+b*A**4/4+g*A**6/6
        # q=A sin(phi): p=sqrt(2(E-V(A sin)))=A cos(phi) sqrt(R), R=1+b A^2 (1+s^2)/2+g A^4 (1+s^2+s^4)/3
        ph=(xg+1)*np.pi/4; w=wg*np.pi/4; s=np.sin(ph); c=np.cos(ph)
        R=1+b*A*A*(1+s*s)/2+g*A**4*(1+s*s+s**4)/3
        J=(2/np.pi)*np.sum(w*A*A*c*c*np.sqrt(R))
        T=4*np.sum(w/np.sqrt(R))                 # dt = dq/p = A c dphi/(A c sqrt R)
        om=2*np.pi/T
        # Q2: q^2 Fourier cos(2 theta), theta = om t ; t(phi)=cumulative
        ph2=np.linspace(0,np.pi/2,4001); s2=np.sin(ph2); R2=1+b*A*A*(1+s2*s2)/2+g*A**4*(1+s2*s2+s2**4)/3
        dt=1/np.sqrt(R2); tq=np.concatenate([[0],np.cumsum((dt[1:]+dt[:-1])/2*np.diff(ph2))])
        th=om*tq   # theta from 0 (q=0) to pi/2 (q=A)
        q2=(A*s2)**2
        # q^2 even about theta=pi/2 quarter symmetry: Q2 = (4/pi) int_0^{pi/2} q^2 cos(2 theta) d theta
        Q2=(4/np.pi)*np.trapezoid(q2*np.cos(2*th)*om*dt,ph2)
        out.append((J,E,om,Q2))
    J,E,om,Q2=np.array(out).T
    # sign: q=A sin(theta-ish) -> q^2 = A^2 sin^2 -> Q2 negative; use |Q2|
    return As,J,E,om,np.abs(Q2)
def imt(eps,g,exact=True):
    d2=-eps**2/16
    if not exact:
        Jm=2*(eps/2-d2)/U
        f=lambda J: 1/(eps*J*np.sqrt((2*(U*J*J/2+d2*J)/(eps*J))**2-1))
        return quad(lambda u: f(Jm+u*u)*2*u,0,10,limit=400)[0]+quad(lambda l: f(np.exp(l))*np.exp(l),np.log(Jm+100),np.log(1e12),limit=200)[0]
    As,J,E,om,Q2=TAB[g]
    lJ=np.log(J); sF=CubicSpline(lJ,np.log(E-J)); sQ=CubicSpline(lJ,np.log(Q2))
    Xf=lambda x: -2*(np.exp(sF(x))+d2*np.exp(x))/(eps*np.exp(sQ(x)))
    xm=brentq(lambda x: Xf(x)+1,np.log(J[2]),np.log(J[-3]))
    f=lambda x: np.exp(x)/(eps*np.exp(sQ(x))*np.sqrt(Xf(x)**2-1))
    I=quad(lambda u: f(xm+u*u)*2*u,0,np.sqrt(lJ[-1]-xm),limit=500)[0]
    # tail beyond table: integrand ~ dJ/(2E), E~ (g>0: J^{3/2}; g=0: J^{4/3})
    Jt=J[-1]; Et=E[-1]; a=np.log(E[-1]/E[-20])/np.log(J[-1]/J[-20])
    I+= Jt/(2*Et*(a-1))
    return I
TAB={}
for g in [0.0,8/15,17/15,(17/9+1)*3/5,34/15]:
    TAB[g]=table(g)
    p=17/9-5*g/3
    row=[]
    for eps in [0.04,0.06,0.10,0.14,0.20,0.28]:
        D=2*(imt(eps,g)-imt(eps,g,False)); row.append('%.3f'%(D-p*np.log(1/eps)))
    print('gamma %.4f  p_pred %+.3f   nu*Delta - p ln(1/eps) at eps=0.04,.06,.10,.14,.20,.28:'%(g,p),' '.join(row),flush=True)
