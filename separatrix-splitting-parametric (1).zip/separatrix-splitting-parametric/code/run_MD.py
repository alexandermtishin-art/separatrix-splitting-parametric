import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
import sys, json, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import split, model_MD as MDm
from split import nu
from scipy.integrate import solve_ivp, quad
from scipy.optimize import brentq
import ell_exact as EE
def monoM(eps):
    f=lambda t,y:(np.array([[0,1],[-(1+2*eps*np.cos(nu*t)),0]])@y.reshape(2,2)).ravel()
    M=solve_ivp(f,(0,split.Tp),np.eye(2).ravel(),rtol=1e-13,atol=1e-15,method='DOP853').y[:,-1].reshape(2,2)
    w,V=np.linalg.eig(M); i=np.argmax(abs(w)); eu=np.real(V[:,i]); es=np.real(V[:,1-i]); L=np.real(w[i])
    es=es/(eu[0]*es[1]-eu[1]*es[0]); return eu,es,L,np.log(abs(L))/split.Tp
split.monodromy=monoM
def rhs(model,eps,s=0.0):
    def f(t,y):
        q,p=y; n=0.5*(q*q+p*p); w=MDm.omega(n); return [w*p,-w*q-2*eps*np.cos(nu*t)*q]
    return f
split.rhs=rhs
# theory: K0 = F(n) + (eps/4)(Q^2-P^2) - eps^2 n/16 ; F'(n)=omega(n)-1
def theory(eps,span=16,N=60001):
    def r(t,y):
        X,Y=y; n=0.5*(X*X+Y*Y); Fp=MDm.omega(n)-1-eps*eps/16
        KX=Fp*X+eps/2*X; KY=Fp*Y-eps/2*Y
        return [-KY,KX]
    h=eps/2; d=-eps**2/16
    psi0=0.5*np.arccos(np.clip(-2*d/eps,-1,1)); a=1e-9
    ev=lambda t,y: y[0]; ev.terminal=True   # tip: psi=pi/2 <-> X=0
    s=solve_ivp(r,(0,400/h),[a*np.cos(psi0),a*np.sin(psi0)],events=ev,rtol=1e-13,atol=1e-22,method='DOP853',dense_output=True)
    tt=s.t_events[0][0]; tl=np.linspace(-span/h,0,N); tl=tl[tt+tl>0]; X,Y=s.sol(tt+tl); n=0.5*(X*X+Y*Y)
    t=np.r_[tl,-tl[-2::-1]]; n=np.r_[n,n[-2::-1]]
    return 2*eps*abs(np.trapezoid(n*np.cos(2*t),t))
# energy-action of Duffing for singular time
As=np.geomspace(1e-3,40,900); Jt,omt,Q0t,Qt=EE.basic(As); Et=As**2/2+EE.b*As**4/4
from scipy.interpolate import CubicSpline
lJ=np.log(Jt); sF=CubicSpline(lJ,np.log(Et-Jt))
def imt_MD(eps):
    d2=-eps**2/16
    Xf=lambda x: -2*(np.exp(sF(x))+d2*np.exp(x))/(eps*np.exp(x))
    xm=brentq(lambda x: Xf(x)+1,lJ[2],lJ[-3])
    f=lambda x: 1/(eps*np.sqrt(Xf(x)**2-1))
    I=quad(lambda u: f(xm+u*u)*2*u,0,np.sqrt(lJ[-1]-xm),limit=500)[0]
    a=np.log(Et[-1]-Jt[-1]); I+=Jt[-1]/(2*(Et[-1]-Jt[-1])*(4/3-1))
    return I
def imt_0(eps):
    d2=-eps**2/16; U=1.0; Jm=2*(eps/2-d2)/U
    f=lambda J: 1/(eps*J*np.sqrt((2*(U*J*J/2+d2*J)/(eps*J))**2-1))
    return quad(lambda u: f(Jm+u*u)*2*u,0,10,limit=400)[0]+quad(lambda l: f(np.exp(l))*np.exp(l),np.log(Jm+100),np.log(1e12),limit=200)[0]
out={}
for eps in [0.14,0.16,0.20,0.24,0.28]:
    Wd=split.splitting('MD',eps,nph=16,u0=1e-6)['W1']; Wt=theory(eps); D=2*(imt_MD(eps)-imt_0(eps))
    out[eps]=dict(W=Wd,Wth=Wt,Delta=D)
    print('eps %.2f  W_MD %.4e  W_th %.4e  ratio %.3f  Delta %.4f'%(eps,Wd,Wt,Wd/Wt,D),flush=True)
json.dump({str(k):v for k,v in out.items()},open(''+DATA+'MD.json','w'))
