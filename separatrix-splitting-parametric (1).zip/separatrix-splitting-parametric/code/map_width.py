import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
import numpy as np, json
from numba import njit
@njit(cache=True)
def run(W,lam,C,n,seed):
    np.random.seed(seed); w=(np.random.rand()-0.5)*1e-3*W; tau=np.random.rand()*2*np.pi; mx=0.0
    for k in range(n):
        w=w-W*np.sin(tau)
        if w==0.0: w=1e-300
        tau=(tau+lam*np.log(C/abs(w)))%(2*np.pi)
        a=abs(w)
        if a>mx: mx=a
    return mx
U=1.0; KG=0.9716
cases=[('M',0.20,3.2481e-9,0.099536,15546,4.894e-08),('M',0.28,7.1140e-7,0.13874,31175,1.130e-05),
       ('D',0.24,1.1524e-8,0.11751,19884,1.612e-07),('D',0.28,1.0794e-7,0.13607,25928,1.493e-06),('S',0.24,1.9127e-6,0.11751,28839,2.677e-05)]
for m,e,W,h,n,wf in cases:
    g=e/2 if m=='M' else e/2; C=8*h**4/(U*g*g); lam=2/h
    mx=np.array([run(W,lam,C,n,s) for s in range(8)])
    print('%s %.2f  flow %.3e  map max %.3e (min %.3e, max %.3e)  flow/map %.2f  map/(lamW/KG) %.2f'%(m,e,wf,mx.mean(),mx.min(),mx.max(),wf/mx.mean(),mx.mean()/(lam*W/KG)))
