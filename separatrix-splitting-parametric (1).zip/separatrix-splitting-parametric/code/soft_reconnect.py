import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Reconnection threshold for the softening sextics: smallest eps at which min_J G(J)=0 along cos2psi=+1,
G = F(J) - eps^2 J/16 + (eps/2) Q2(J) (first order: without the eps^2 term)."""
import numpy as np
from scipy.integrate import solve_ivp, quad
from scipy.optimize import brentq
b=-4/3
def orbit(A,g):
    V=lambda q: q*q/2+b*q**4/4+g*q**6/6; E=V(A)
    f=lambda th: 2*(E-V(A*np.sin(th)))
    T=4*quad(lambda th: A*np.cos(th)/np.sqrt(f(th)),0,np.pi/2,limit=400,epsabs=1e-13,epsrel=1e-12)[0]
    J=(2/np.pi)*quad(lambda th: A*np.cos(th)*np.sqrt(f(th)),0,np.pi/2,limit=400,epsabs=1e-13,epsrel=1e-12)[0]
    om=2*np.pi/T
    s=solve_ivp(lambda t,y:[y[1],-(y[0]+b*y[0]**3+g*y[0]**5)],(0,T),[A,0],rtol=1e-12,atol=1e-14,dense_output=True)
    t=np.linspace(0,T,2001)[:-1]; q=s.sol(t)[0]; Q2=2*np.mean(q*q*np.cos(2*om*t))
    return J,E-J,Q2
for g in [8/15,17/15,26/15]:
    As=np.linspace(0.02,2.2,500); R=np.array([orbit(A,g) for A in As]); J,F,Q2=R.T
    def minG(eps,second=True): return np.min((F-(eps**2*J/16 if second else 0)+eps*Q2/2)[J>eps/2])
    e1=brentq(lambda e: minG(e,False),0.02,1.0); e2=brentq(lambda e: minG(e,True),0.02,1.0)
    i=np.argmin(F/Q2)
    print('gamma %.4f  eps_r first order %.3f, with h0 %.3f ; min F/Q2 = %.4f at J %.3f (2|min F/Q2| = %.3f)'%(g,e1,e2,(F/Q2)[i],J[i],-2*(F/Q2)[i]),flush=True)
