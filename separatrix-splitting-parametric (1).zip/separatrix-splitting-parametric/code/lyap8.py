import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Maximal Lyapunov exponent of model M with the Yoshida 8th-order composition and its exact tangent map
(check of the RK4 value in Table 5). Also records energy-like drift via passage count."""
import sys, numpy as np
from numba import njit
sys.path.insert(0,HERE)
from width import DRIFT, KICK
@njit(cache=True)
def run(q,p,eps,b0,nper,nsub,DR,KI,nseg):
    dt=np.pi/nsub; t=0.0; dq=1.0; dp=0.0
    seg=np.zeros(nseg); per=nper//nseg; acc=0.0
    for k in range(nper):
        for j in range(nsub):
            for i in range(15):
                q+=DR[i]*dt*p; dq+=DR[i]*dt*dp; t+=DR[i]*dt
                c=np.cos(2.0*t)
                fq=-(1.0+2.0*eps*c)-3.0*b0*q*q
                p+=KI[i]*dt*(-(1.0+2.0*eps*c)*q-b0*q**3); dp+=KI[i]*dt*fq*dq
            q+=DR[15]*dt*p; dq+=DR[15]*dt*dp; t+=DR[15]*dt
        t=(k+1)*np.pi
        nrm=np.sqrt(dq*dq+dp*dp); acc+=np.log(nrm); dq/=nrm; dp/=nrm
        if (k+1)%per==0:
            seg[(k+1)//per-1]=acc/(per*np.pi); acc=0.0
    return seg
if __name__=='__main__':
    eps=float(sys.argv[1]); nper=int(sys.argv[2]); nsub=int(sys.argv[3]) if len(sys.argv)>3 else 40
    allseg=[]
    for ph in np.linspace(0,2*np.pi,8,endpoint=False)+0.3:
        a0=1e-4*np.exp(1j*ph)
        seg=run(np.sqrt(2)*a0.real,np.sqrt(2)*a0.imag,eps,4/3,nper,nsub,DRIFT,KICK,10)
        allseg.append(seg); print('phase %.2f  lambda %.5f'%(ph,seg.mean()),flush=True)
    a=np.array(allseg); m=a.mean(axis=1)
    print('eps %.2f nsub %d  lambda %.5f +- %.5f (orbits)  +- %.5f (segments)'%(eps,nsub,m.mean(),m.std(ddof=1)/np.sqrt(len(m)),a.ravel().std(ddof=1)/np.sqrt(a.size)))
