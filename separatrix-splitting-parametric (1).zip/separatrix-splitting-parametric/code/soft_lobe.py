import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""gamma=26/15, U=-1: maximal action along one excursion of the unstable manifold; first-order energy gap
between the primary separatrix (K=0) and the secondary saddle K_hyp=F(J2)+eps Q2(J2)/2."""
import sys, numpy as np
sys.path.insert(0,HERE)
from scipy.integrate import solve_ivp, quad
from scipy.interpolate import interp1d
import split
from split import nu
b=-4/3; g=26/15
V=lambda q: q*q/2+b*q**4/4+g*q**6/6
As=np.linspace(1e-3,1.2,600)
def Jof(A):
    E=V(A); return (2/np.pi)*quad(lambda th: A*np.cos(th)*np.sqrt(max(2*(E-V(A*np.sin(th))),0)),0,np.pi/2,limit=200)[0]
Js=np.array([Jof(A) for A in As]); Es=V(As); JofE=interp1d(Es,Js)
def mono(eps):
    f=lambda t,y:(np.array([[0,1],[-(1+2*eps*np.cos(nu*t)),0]])@y.reshape(2,2)).ravel()
    M=solve_ivp(f,(0,np.pi),np.eye(2).ravel(),rtol=1e-13,atol=1e-15,method='DOP853').y[:,-1].reshape(2,2)
    w,Vv=np.linalg.eig(M); i=np.argmax(abs(w)); return np.real(Vv[:,i])
for eps in [0.1025,0.13,0.145,0.155]:
    eu=mono(eps); y0=1e-6*eu
    rhs=lambda t,y:[y[1],-(1+2*eps*np.cos(nu*t))*y[0]-b*y[0]**3-g*y[0]**5]
    s=solve_ivp(rhs,(0,3000),y0,rtol=1e-11,atol=1e-14,method='DOP853',dense_output=True,max_step=0.2)
    t=np.arange(0,s.t[-1],np.pi); q,p=s.sol(t); r=np.hypot(q,p)
    i0=np.argmax(r>0.2); i1=i0+np.argmax(r[i0:]<0.03)
    tt=np.linspace(t[max(i0-20,0)],t[i1],40000); qq,pp=s.sol(tt); E=pp**2/2+V(qq)
    Kh=-0.0347+eps*0.4643/2
    print('eps %.4f  max action on excursion %.3f  returns after %d periods; first-order K_hyp = %.4f'%(eps,JofE(E.max()),i1-i0,Kh),flush=True)
