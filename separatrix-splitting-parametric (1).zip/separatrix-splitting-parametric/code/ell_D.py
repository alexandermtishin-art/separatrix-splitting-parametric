import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Elliptic theory for model D: Omega^2=(1+eps cos2t)^2 -> extra (eps^2/4)(1+cos4t) q^2 term."""
import sys, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import ell_h2 as H
from scipy.integrate import solve_ivp
B=H.B; C=H.C; XMAX=B.XMAX; NM=B.NM
def homoclinic(eps,span=16,N=60001):
    e2=eps*eps
    def rhs(t,y):
        x,psi=y; z=2*x/XMAX-1
        dJ=C.chebval(z,B.cJd); om=C.chebval(z,B.com); Jv=x*C.chebval(z,B.cJx); Q2=Jv*C.chebval(z,B.cR2); dQ2=C.chebval(z,B.cQd[0])/dJ
        Q4=C.chebval(z,B.cQ[1]); dQ4=C.chebval(z,B.cQd[1])/dJ; dQ0=C.chebval(z,B.cQ0d)/dJ
        H4=C.chebval(z,H.ch4); dH0=C.chebval(z,H.ch0d)/dJ; dH4=C.chebval(z,H.ch4d)/dJ
        Jdot=eps*Q2*np.sin(2*psi)+4*e2*(H4+Q4/8)*np.sin(4*psi)
        psidot=om-1+e2*(dH0+dQ0/4)+(eps/2)*dQ2*np.cos(2*psi)+e2*(dH4+dQ4/8)*np.cos(4*psi)
        return [Jdot/dJ,psidot]
    z=-1.0; dJ0=C.chebval(z,B.cJd); a=(C.chebval(z,H.ch0d)+C.chebval(z,B.cQ0d)/4)/dJ0
    psi0=0.5*np.arccos(np.clip(-2*e2*a/eps,-1,1))
    ev=lambda t,y: y[1]-np.pi/2; ev.terminal=True; h=eps/2
    s=solve_ivp(rhs,(0,300/h),[1e-12,psi0],events=ev,rtol=1e-13,atol=1e-26,method='DOP853',dense_output=True)
    tt=s.t_events[0][0]; tl=np.linspace(-span/h,0,N); tl=tl[tt+tl>0]; x,psi=s.sol(tt+tl)
    return np.r_[tl,-tl[-2::-1]],np.r_[x,x[-2::-1]],np.r_[psi,np.pi-psi[-2::-1]]
def melnikov(eps,nt0=24):
    t,x,psi=homoclinic(eps); e2=eps*eps
    J,om,Q0,Q,dJ,dQ0,dQ=B.funcs(x); z=2*x/XMAX-1
    H4=C.chebval(z,H.ch4); dH0=C.chebval(z,H.ch0d)/dJ; dH4=C.chebval(z,H.ch4d)/dJ
    K0J=om-1+e2*(dH0+dQ0/4)+(eps/2)*dQ[0]*np.cos(2*psi)+e2*(dH4+dQ[1]/8)*np.cos(4*psi)
    K0p=-eps*Q[0]*np.sin(2*psi)-4*e2*(H4+Q[1]/8)*np.sin(4*psi)
    m=2*np.arange(1,NM+1)[:,None]; t0s=np.linspace(0,np.pi,nt0,endpoint=False); res=[]
    for t0 in t0s:
        T=t+t0; th=psi+T; amp=eps*np.cos(2*T)+(e2/4)*(1+np.cos(4*T))
        Pp=-amp*np.sum(m*Q*np.sin(m*th),0)+eps*Q[0]*np.sin(2*psi)+(e2/2)*Q[1]*np.sin(4*psi)
        PJ=amp*(dQ0+np.sum(dQ*np.cos(m*th),0))-(eps/2)*dQ[0]*np.cos(2*psi)-(e2/4)*dQ0-(e2/8)*dQ[1]*np.cos(4*psi)
        res.append(np.trapezoid(-K0J*Pp+K0p*PJ,t))
    X=np.c_[np.sin(2*t0s),np.cos(2*t0s),np.sin(4*t0s),np.cos(4*t0s),np.ones(nt0)]
    co=np.linalg.lstsq(X,np.array(res),rcond=None)[0]
    return np.hypot(co[0],co[1]),np.hypot(co[2],co[3])
if __name__=='__main__':
  direct={0.14:2.5387e-13,0.16:5.9685e-12,0.20:5.3585e-10,0.24:1.1524e-08,0.28:1.0794e-07}
  for eps,Wd in direct.items():
    W,W2=melnikov(eps)
    print('D eps %.2f  ellTheory %.4e  direct %.4e  ratio %.3f (2nd %.1e)'%(eps,W,Wd,Wd/W,W2),flush=True)
