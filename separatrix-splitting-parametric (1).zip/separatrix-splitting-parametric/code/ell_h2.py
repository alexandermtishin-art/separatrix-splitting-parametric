import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Elliptic Melnikov with full second-order static correction H2 = eps^2 [h0(J) + h4(J) cos 4psi]."""
import sys, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import ell_cheb as B
from scipy.integrate import solve_ivp
C=B.C; XMAX=B.XMAX; xs=B.xs; NM=B.NM
z0=2*xs/XMAX-1
Qn=np.array([C.chebval(z0,B.cQ0)]+[C.chebval(z0,c) for c in B.cQ])        # index r/2 : Q_0,Q_2,...,Q_2NM
dJn=C.chebval(z0,B.cJd)
dQn=np.array([C.chebval(z0,B.cQ0d)]+[C.chebval(z0,c) for c in B.cQd])/dJn  # dQ/dJ
def c_(r):   # c_r / eps
    return (0.5 if r==0 else 0.25)*Qn[r//2], (0.5 if r==0 else 0.25)*dQn[r//2]
h0=np.zeros_like(xs); h4=np.zeros_like(xs)
for l in range(1,NM):
    k=2*l; a,ad=c_(k-2); b,bd=c_(k+2)
    h0+=-(1/k)*((k-2)*2*a*ad+(k+2)*2*b*bd)
    h4+=-(1/k)*2*((k-2)*a*bd+(k+2)*ad*b)
ch0=B.fit(h0); ch4=B.fit(h4)
# derivatives wrt J: d/dx then / dJ/dx
ch0d=C.chebder(ch0)*2/XMAX; ch4d=C.chebder(ch4)*2/XMAX
print('small-J check h0/J ->',h0[0]/C.chebval(z0[0],B.cJ),' (expect -1/16=-0.0625)',flush=True)
def homoclinic(eps,span=16,N=60001,lam=1.0):
    e2=lam*eps*eps
    def rhs(t,y):
        x,psi=y; z=2*x/XMAX-1
        dJ=C.chebval(z,B.cJd); om=C.chebval(z,B.com); Jv=x*C.chebval(z,B.cJx); Q2=Jv*C.chebval(z,B.cR2); dQ2=C.chebval(z,B.cQd[0])/dJ
        H4=C.chebval(z,ch4); dH0=C.chebval(z,ch0d)/dJ; dH4=C.chebval(z,ch4d)/dJ
        Jdot=eps*Q2*np.sin(2*psi)+4*e2*H4*np.sin(4*psi)
        psidot=om-1+e2*dH0+(eps/2)*dQ2*np.cos(2*psi)+e2*dH4*np.cos(4*psi)
        return [Jdot/dJ,psidot]
    z=-1.0; dh00=C.chebval(z,ch0d)/C.chebval(z,B.cJd)
    psi0=0.5*np.arccos(np.clip(-2*lam*eps*eps*dh00/eps,-1,1))
    ev=lambda t,y: y[1]-np.pi/2; ev.terminal=True; h=eps/2
    s=solve_ivp(rhs,(0,300/h),[1e-12,psi0],events=ev,rtol=1e-13,atol=1e-26,method='DOP853',dense_output=True)
    tt=s.t_events[0][0]; tl=np.linspace(-span/h,0,N); tl=tl[tt+tl>0]
    x,psi=s.sol(tt+tl)
    return np.r_[tl,-tl[-2::-1]],np.r_[x,x[-2::-1]],np.r_[psi,np.pi-psi[-2::-1]]
def melnikov(eps,lam=1.0,nt0=24,span=16):
    t,x,psi=homoclinic(eps,span,lam=lam); e2=lam*eps*eps
    J,om,Q0,Q,dJ,dQ0,dQ=B.funcs(x); z=2*x/XMAX-1
    H4=C.chebval(z,ch4); dH0=C.chebval(z,ch0d)/dJ; dH4=C.chebval(z,ch4d)/dJ
    K0J=om-1+e2*dH0+(eps/2)*dQ[0]*np.cos(2*psi)+e2*dH4*np.cos(4*psi)
    K0p=-eps*Q[0]*np.sin(2*psi)-4*e2*H4*np.sin(4*psi)
    m=2*np.arange(1,NM+1)[:,None]; t0s=np.linspace(0,np.pi,nt0,endpoint=False); res=[]
    for t0 in t0s:
        T=t+t0; th=psi+T; c2=np.cos(2*T)
        Pp=-eps*c2*np.sum(m*Q*np.sin(m*th),0)+eps*Q[0]*np.sin(2*psi)
        PJ=eps*c2*(dQ0+np.sum(dQ*np.cos(m*th),0))-(eps/2)*dQ[0]*np.cos(2*psi)
        res.append(np.trapezoid(-K0J*Pp+K0p*PJ,t))
    res=np.array(res); X=np.c_[np.sin(2*t0s),np.cos(2*t0s),np.sin(4*t0s),np.cos(4*t0s),np.ones(nt0)]
    co=np.linalg.lstsq(X,res,rcond=None)[0]
    return np.hypot(co[0],co[1]),np.hypot(co[2],co[3])
if __name__=='__main__':
    direct={0.14:1.4559e-12,0.16:3.4785e-11,0.20:3.2481e-09,0.24:7.2775e-08,0.28:7.1140e-07}
    for eps,Wd in direct.items():
        W,W2=melnikov(eps)
        print('eps %.2f  ellMel+H2 %.4e  direct %.4e  ratio %.3f (2nd %.1e)'%(eps,W,Wd,Wd/W,W2),flush=True)
