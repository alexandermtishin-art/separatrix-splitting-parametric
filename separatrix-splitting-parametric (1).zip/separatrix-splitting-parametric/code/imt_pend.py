import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Singular time for the cosine potential V=(1-cos(s q))/s^2, s^2=8 (U=-1): integrate (11) from the tip to the
free-pendulum separatrix J_b, where <q^2>(J) has a logarithmic branch point."""
import numpy as np, re
from scipy.integrate import quad
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq
s=np.sqrt(8.0); V=lambda q: (1-np.cos(s*q))/s**2
qb=np.pi/s
def row(A):
    xg,wg=np.polynomial.legendre.leggauss(400); ph=(xg+1)*np.pi/4; w=wg*np.pi/4; sn=np.sin(ph); cs=np.cos(ph)
    R=2*(V(A)-V(A*sn))/(A*A*cs*cs)
    J=(2/np.pi)*np.sum(w*A*A*cs*cs*np.sqrt(R)); T=4*np.sum(w/np.sqrt(R)); om=2*np.pi/T
    ph2=np.linspace(0,np.pi/2,20001)[:-1]; s2=np.sin(ph2); c2=np.cos(ph2); R2=2*(V(A)-V(A*s2))/(A*A*c2*c2)
    dt=1/np.sqrt(R2); tq=np.concatenate([[0],np.cumsum((dt[1:]+dt[:-1])/2*np.diff(ph2))]); th=om*tq
    Q2=(4/np.pi)*np.trapezoid((A*s2)**2*np.cos(2*th)*om*dt,ph2)
    return J,V(A),om,abs(Q2)
As=qb*(1-np.geomspace(1,1e-9,1500))[::-1]; As=np.sort(np.r_[np.geomspace(1e-3,0.5*qb,300),qb*(1-np.geomspace(0.5,1e-6,900))])
tab=np.array([row(A) for A in As]).T
good=np.isfinite(tab).all(0); tab=tab[:,good]
keep=np.r_[True,np.diff(tab[0])>1e-15]; tab=tab[:,keep]
J,E,om,Q2=tab; Jb=8/(np.pi*s*s); Jl=J[-1]
print('J_b approx',Jb,' (8/(pi s^2) =',8/(np.pi*s*s),')')
def imt(eps):
    d2=-eps**2/16; F=E-J
    X=2*(np.abs(F)-d2*J)/(eps*Q2)
    sX=CubicSpline(J,X); sQ=CubicSpline(J,Q2)
    Jm=brentq(lambda x: sX(x)-1,J[1],J[-5])
    f=lambda x: 1/(eps*sQ(x)*np.sqrt(sX(x)**2-1))
    return quad(lambda u: f(Jm+u*u)*2*u,0,np.sqrt(Jl-Jm),limit=800)[0]
def imt0(eps):
    d2=-eps**2/16; Jm=eps+2*d2
    X=lambda x: (x-2*d2)/eps; f=lambda x: 1/(eps*x*np.sqrt(X(x)**2-1))
    return quad(lambda u: f(Jm+u*u)*2*u,0,10,limit=400)[0]+quad(lambda l: f(np.exp(l))*np.exp(l),np.log(Jm+100),np.log(1e12),limit=200)[0]
for l in open(''+DATA+'pendulum.txt'):
    if l.startswith('eps'):
        e=float(l.split()[1]); r=float(re.findall(r'ratio ([0-9.e+-]+)',l)[0])
        D=2*(imt(e)-imt0(e)); print('eps %.2f ratio %.4e  Delta %.4f  ln r + Delta %.4f'%(e,r,D,np.log(r)+D),flush=True)
