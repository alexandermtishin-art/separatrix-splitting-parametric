import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Phase-invariant control with the exact Duffing energy-action function:
H = E_D(n) + eps cos(2t) q^2, n=(q^2+p^2)/2, E_D the action-energy function of p^2/2+q^2/2+beta q^4/4.
Equations: qdot = omega_D(n) p, pdot = -omega_D(n) q - 2 eps cos(2t) q."""
import sys, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import ell_exact as EE
from numpy.polynomial import chebyshev as C
# tabulate omega_D as a function of J on [0, JMAX] by Chebyshev fit in J
A=np.sqrt(np.linspace(0,1.6,4001)[1:]); J,om,Q0,Q=EE.basic(A)
J=np.r_[0,J]; om=np.r_[1,om]
JMAX=J[-1]
cw=C.chebfit(2*J/JMAX-1,om,120)
def omega(n):
    return C.chebval(2*n/JMAX-1,cw)
err=np.abs(omega(J)-om).max()
if __name__=='__main__':
    print('JMAX',JMAX,'fit err',err)
