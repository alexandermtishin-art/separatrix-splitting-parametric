import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Lobe area of the separatrix: stroboscopic map (unstable manifold of P^2, Yoshida-8) versus the
separatrix lobe of the resonance Hamiltonian K0 = E-J+(eps/2)Q2 cos2psi+eps^2[h0+h4 cos4psi].
The lobe area is a symplectic invariant, so it tests K0 at finite J independently of the
near-identity transformation to the rotating frame."""
import sys, numpy as np
from numba import njit
from scipy.integrate import quad
from scipy.optimize import brentq
sys.path.insert(0,HERE)
from width import DRIFT, KICK, mono
import ell_cheb as B
import ell_h2 as H
C=B.C; XMAX=B.XMAX
@njit(cache=True)
def frc(q,t,eps,b0,model):
    c=np.cos(2.0*t)
    return -(1.0+2.0*eps*c)*q-b0*q**3
@njit(cache=True)
def frcM0(q,p,t,eps):
    # M0: H = n + n^2/2 + eps cos2t q^2 is not separable; use RK8-free alternative below
    return 0.0
@njit(cache=True)
def orbit(q,p,eps,b0,nrec,nsub,DR,KI):
    dt=np.pi/nsub; t=0.0; out=np.empty((nrec,2))
    for k in range(nrec):
        for j in range(2*nsub):
            for i in range(15):
                q+=DR[i]*dt*p; t+=DR[i]*dt
                p+=KI[i]*dt*frc(q,t,eps,b0,0)
            q+=DR[15]*dt*p; t+=DR[15]*dt
        t=2*np.pi*(k+1); out[k,0]=q; out[k,1]=p
    return out
def map_area(eps,N=800,ua=1e-6,nsub=60,b0=4/3):
    eu,es,hF=mono(eps,0); L2=np.exp(2*np.pi*hF)        # |Lambda|^2 for P^2
    nrec=int(1.15*(2/hF)*np.log(1/ua)/(2*np.pi))+20
    us=ua*L2**(np.arange(N)/N)
    pts=np.array([orbit(u*eu[0],u*eu[1],eps,b0,nrec,nsub,DRIFT,KICK) for u in us])  # (N,nrec,2)
    curve=np.transpose(pts,(1,0,2)).reshape(-1,2)
    curve=np.r_[np.c_[us*eu[0],us*eu[1]],curve]
    r=np.hypot(curve[:,0],curve[:,1]); imax=np.argmax(r)
    i1=imax+np.argmax(r[imax:]<0.05*r[imax]); i2=i1+np.argmax(r[i1:]>0.1*r[imax])
    if i2==i1: i2=len(r)
    iend=i1+np.argmin(r[i1:i2])
    c=np.r_[[[0,0]],curve[:iend+1],[[0,0]]]
    return 0.5*abs(np.sum(c[:-1,0]*c[1:,1]-c[1:,0]*c[:-1,1]))
def K0_area(eps,which):
    """which: 'kerr' (E=J+J^2/2,Q2=J,h0=-J/16), 'lin' (Duffing E,Q2; h0=-J/16,h4=0), 'h0', 'full'"""
    def parts(x):
        z=2*x/XMAX-1
        J=x*C.chebval(z,B.cJx); E=None
        return z,J
    if which=='kerr':
        F=lambda J: J*J/2; Q2=lambda J: J; h0=lambda J:-J/16; h4=lambda J:0.0
        def X(J):
            return -2*(F(J)+eps**2*h0(J))/(eps*Q2(J))
        Jtip=brentq(lambda J: X(J)+1,1e-9,5)
        return quad(lambda J: np.pi-np.arccos(np.clip(X(J),-1,1)),0,Jtip,limit=200,epsabs=1e-14,epsrel=1e-13)[0]
    # Duffing: parametrize by x=A^2; F = E - J with E from omega: E(J)=int omega dJ -> use cheb of om and J
    # build E(x) by integrating omega dJ/dx
    xs=np.linspace(0,1.2,4001); z=2*xs/XMAX-1
    Jx=xs*C.chebval(z,B.cJx); om=C.chebval(z,B.com); dJ=C.chebval(z,B.cJd)
    from scipy.integrate import cumulative_trapezoid
    from numpy.polynomial import chebyshev as CC
    Fx=cumulative_trapezoid((om-1)*dJ,xs,initial=0)
    cF=CC.chebfit(z,Fx,90)
    def X(x):
        zz=2*x/XMAX-1; J=x*C.chebval(zz,B.cJx); Q2=J*C.chebval(zz,B.cR2); F=C.chebval(zz,cF)
        h0=-J/16 if which=='lin' else C.chebval(zz,H.ch0)
        h4=0.0 if which in ('lin','h0') else C.chebval(zz,H.ch4)
        # F + eps^2(h0-h4) + (eps/2)Q2 X + 2 eps^2 h4 X^2 = 0, root near the h4=0 solution
        a=2*eps**2*h4; b=eps*Q2/2; c=F+eps**2*(h0-h4)
        if a==0: return -c/b
        disc=np.sqrt(b*b-4*a*c); r1=(-b+disc)/(2*a); r2=(-b-disc)/(2*a)
        X0=-c/b
        return r1 if abs(r1-X0)<abs(r2-X0) else r2
    xtip=brentq(lambda x: X(x)+1,1e-9,1.19)
    f=lambda x: (np.pi-np.arccos(np.clip(X(x),-1,1)))*C.chebval(2*x/XMAX-1,B.cJd)
    return quad(f,0,xtip,limit=400,epsabs=1e-14,epsrel=1e-13)[0]
if __name__=='__main__':
    for eps in [float(a) for a in sys.argv[1:]]:
        Am=map_area(eps); Am2=map_area(eps,N=1600,nsub=80)
        r=[K0_area(eps,w) for w in ['lin','h0','full']]
        print('eps %.2f  map %.9f (N1600 %.9f)  K0 lin %.9f  h0 %.9f  full %.9f | rel dev: lin %.2e h0 %.2e full %.2e'%(
            eps,Am,Am2,*r,*(x/Am2-1 for x in r)),flush=True)
