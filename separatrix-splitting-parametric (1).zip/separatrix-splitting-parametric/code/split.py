import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Direct separatrix splitting of the stroboscopic (period 2pi/nu) map of lab-frame flows (q,p).
Energy kick of separatrix map = h_F * (u s) at return, with symplectically normalised Floquet coordinates."""
import numpy as np
from scipy.integrate import solve_ivp
nu=2.0; U=1.0; Tp=2*np.pi/nu
def rhs(model, eps, s=0.0):
    b0=4*U/3
    if model=='C':
        def f(t,y):
            Om=1+eps*np.cos(nu*t); q,p=y[0],y[1]; n=0.5*(Om*q*q+p*p/Om)
            return [p*(1+U*n/Om), -Om*q*(Om+U*n)]
    else:
        def f(t,y):
            Om=1+eps*np.cos(nu*t); q,p=y[0],y[1]
            return [p, -Om*Om*q-b0*Om**s*q**3]
    return f
def monodromy(eps):
    def f(t,y):
        Om=1+eps*np.cos(nu*t); M=y.reshape(2,2)
        return (np.array([[0,1],[-Om*Om,0]])@M).ravel()
    s=solve_ivp(f,(0,Tp),np.eye(2).ravel(),rtol=1e-13,atol=1e-15,method='DOP853')
    M=s.y[:,-1].reshape(2,2); w,V=np.linalg.eig(M); i=np.argmax(abs(w))
    eu=np.real(V[:,i]); es=np.real(V[:,1-i]); L=np.real(w[i])
    om=eu[0]*es[1]-eu[1]*es[0]; es=es/om        # omega(eu,es)=1
    hF=np.log(abs(L))/Tp
    return eu,es,L,hF
def coords(x,eu,es):
    # x = u eu + s es ;  u = omega(x,es), s = omega(eu,x)
    u=x[0]*es[1]-x[1]*es[0]; s=eu[0]*x[1]-eu[1]*x[0]; return u,s
def splitting(model,eps,s=0.0,u0=1e-5,nph=16,rtol=1e-13,maxper=400):
    f=rhs(model,eps,s); eu,es,L,hF=monodromy(eps)
    lnL=np.log(abs(L)); out=[]
    for j in range(nph):
        uu=u0*np.exp(lnL*j/nph); x=uu*eu; t=0.0; left=False; rec=[]
        for k in range(maxper):
            sol=solve_ivp(f,(t,t+Tp),x,rtol=rtol,atol=1e-18,method='DOP853'); x=sol.y[:,-1]; t+=Tp
            r=np.hypot(*x)
            if r>0.2: left=True
            if left:
                u,ss=coords(x,eu,es); rec.append((r,u*ss))
                if len(rec)>3 and rec[-1][0]>rec[-2][0] and rec[-2][0]<0.03: break
        rec=np.array(rec); km=np.argmin(rec[:,0])
        I=rec[max(km-1,0):km+2,1]
        out.append((I.mean(),I.std(),rec[km,0]))
    out=np.array(out); ph=2*np.pi*np.arange(nph)/nph
    X=np.c_[np.ones(nph),np.sin(ph),np.cos(ph),np.sin(2*ph),np.cos(2*ph)]
    co=np.linalg.lstsq(X,out[:,0],rcond=None)[0]
    return dict(W1=hF*np.hypot(co[1],co[2]),W2=hF*np.hypot(co[3],co[4]),mean=hF*co[0],
                fitres=hF*np.abs(out[:,0]-X@co).max(),Ijit=hF*out[:,1].max(),rmin=out[:,2].max(),hF=hF,a1=hF*co[1],b1=hF*co[2])
if __name__=='__main__':
    import sys
    for eps in [0.24,0.28,0.32]:
      for m,sv in [('C',0),('S',2),('D',0)]:
        r=splitting(m,eps,float(sv))
        print(m+' eps %.2f  W_nu %.3e W_2nu %.1e mean %.1e fitres %.1e jitter %.1e rmin %.1e'%(eps,r['W1'],r['W2'],r['mean'],r['fitres'],r['Ijit'],r['rmin']),flush=True)
