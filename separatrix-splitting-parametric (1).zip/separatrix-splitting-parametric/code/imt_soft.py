import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
import numpy as np, json
from scipy.integrate import quad
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq
b=-4/3; U=-1.0
def table(g,Amax=40.0,N=800):
    As=np.geomspace(1e-3,Amax,N); out=[]
    xg,wg=np.polynomial.legendre.leggauss(200)
    for A in As:
        E=A*A/2+b*A**4/4+g*A**6/6
        ph=(xg+1)*np.pi/4; w=wg*np.pi/4; s=np.sin(ph); c=np.cos(ph)
        R=1+b*A*A*(1+s*s)/2+g*A**4*(1+s*s+s**4)/3
        J=(2/np.pi)*np.sum(w*A*A*c*c*np.sqrt(R)); T=4*np.sum(w/np.sqrt(R)); om=2*np.pi/T
        ph2=np.linspace(0,np.pi/2,4001); s2=np.sin(ph2); R2=1+b*A*A*(1+s2*s2)/2+g*A**4*(1+s2*s2+s2**4)/3
        dt=1/np.sqrt(R2); tq=np.concatenate([[0],np.cumsum((dt[1:]+dt[:-1])/2*np.diff(ph2))]); th=om*tq
        Q2=(4/np.pi)*np.trapezoid((A*s2)**2*np.cos(2*th)*om*dt,ph2)
        out.append((J,E,om,abs(Q2)))
    return np.array(out).T
def imt(eps,tab):
    J,E,om,Q2=tab; d2=-eps**2/16; lJ=np.log(J)
    sF=CubicSpline(lJ,np.log(np.abs(E-J))); sQ=CubicSpline(lJ,np.log(Q2))
    Xf=lambda x: 2*(np.exp(sF(x))-d2*np.exp(x))/(eps*np.exp(sQ(x)))      # |X| for F<0 : X=-2(F+d2 J)/(eps Q2), F=-|F|
    xm=brentq(lambda x: Xf(x)-1,lJ[2],lJ[-3])
    f=lambda x: np.exp(x)/(eps*np.exp(sQ(x))*np.sqrt(Xf(x)**2-1))
    I=quad(lambda u: f(xm+u*u)*2*u,0,np.sqrt(lJ[-1]-xm),limit=500)[0]
    a=np.log(abs(E[-1]-J[-1])/abs(E[-20]-J[-20]))/np.log(J[-1]/J[-20])
    return I+J[-1]/(2*abs(E[-1]-J[-1])*(a-1))
def imt0(eps):
    d2=-eps**2/16; Jm=eps+2*d2   # tip: (|U|J - 2 d2)/eps = 1  with U=-1 -> J = eps + 2 d2
    X=lambda J: (J-2*d2)/eps
    f=lambda J: 1/(eps*J*np.sqrt(X(J)**2-1))
    return quad(lambda u: f(Jm+u*u)*2*u,0,10,limit=400)[0]+quad(lambda l: f(np.exp(l))*np.exp(l),np.log(Jm+100),np.log(1e12),limit=200)[0]
if __name__=='__main__':
    res={}
    for lab,g in [('8/15',8/15),('17/15',17/15),('26/15',26/15)]:
        tab=table(g); c3=-17/36+5*g/12; p=4*c3
        eps=np.array([1e-4,1e-3,0.01,0.04,0.08,0.14,0.16,0.20,0.24,0.28])
        D=np.array([2*(imt(e,tab)-imt0(e)) for e in eps]); R=D-p*np.log(1/eps)
        res[lab]=dict(p=p,eps=eps.tolist(),Delta=D.tolist())
        print('gamma %s p_pred %+.3f  Delta-p ln(1/eps): '%(lab,p)+' '.join('%.3f'%r for r in R),flush=True)
    json.dump(res,open(''+DATA+'soft_Delta.json','w'))
