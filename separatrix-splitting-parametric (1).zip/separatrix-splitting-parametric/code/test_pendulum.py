import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Cosine potential V=(1-cos(s q))/s^2, s^2=8 (U=-1): predicted p=1. Control: phase-invariant Kerr U=-1."""
import sys, numpy as np
sys.path.insert(0,HERE)
import split
from split import nu
from scipy.integrate import solve_ivp
s=np.sqrt(8.0); U=-1.0
def monoM(eps):
    f=lambda t,y:(np.array([[0,1],[-(1+2*eps*np.cos(nu*t)),0]])@y.reshape(2,2)).ravel()
    M=solve_ivp(f,(0,split.Tp),np.eye(2).ravel(),rtol=1e-13,atol=1e-15,method='DOP853').y[:,-1].reshape(2,2)
    w,V=np.linalg.eig(M); i=np.argmax(abs(w)); eu=np.real(V[:,i]); es=np.real(V[:,1-i]); L=np.real(w[i])
    es=es/(eu[0]*es[1]-eu[1]*es[0]); return eu,es,L,np.log(abs(L))/split.Tp
split.monodromy=monoM
def rhs(model,eps,sv=0.0):
    if model=='P0':
        def f(t,y):
            q,p=y; n=0.5*(q*q+p*p); return [p*(1+U*n),-(1+2*eps*np.cos(nu*t))*q-U*n*q]
        return f
    return lambda t,y:[y[1],-np.sin(s*y[0])/s-2*eps*np.cos(nu*t)*y[0]]
split.rhs=rhs
for eps in [0.10,0.11,0.12,0.13,0.14]:
    a=split.splitting('P',eps,nph=16,u0=1e-6); b=split.splitting('P0',eps,nph=16,u0=1e-6)
    print('eps %.2f  P %.4e (res %.1e)  P0 %.4e (res %.1e)  ratio %.4e  ratio/eps %.4f'%(eps,a['W1'],a['fitres'],b['W1'],b['fitres'],a['W1']/b['W1'],a['W1']/b['W1']/eps),flush=True)
