import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
import sys, json, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import split
from split import splitting, nu, U
orig=split.rhs
def rhs2(model,eps,s=0.0):
    if model=='D0':
        def f(t,y):
            Om=1+eps*np.cos(nu*t); q,p=y; n=0.5*(q*q+p*p)
            return [p*(1+U*n), -Om*Om*q-U*n*q]
        return f
    return orig(model,eps,s)
split.rhs=rhs2
out={}
for eps in [0.12,0.13,0.14,0.15,0.16,0.18,0.20,0.24,0.28,0.32,0.36,0.40]:
    r={m:splitting(m,eps,0.0,nph=16,u0=1e-6) for m in ['D','D0']}
    out[eps]={m:(r[m]['W1'],r[m]['fitres'],r[m]['rmin']) for m in r}
    print('eps %.2f  D %.4e (res %.1e)  D0 %.4e (res %.1e)  ratio %.4e  ratio/eps^2 %.4f'%(eps,r['D']['W1'],r['D']['fitres'],r['D0']['W1'],r['D0']['fitres'],r['D']['W1']/r['D0']['W1'],r['D']['W1']/r['D0']['W1']/eps**2),flush=True)
    json.dump({str(k):v for k,v in out.items()},open('scan_ratio.json','w'))
