import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Prediction p = -(4/3) omega2/U^2 = -4 c3 ; Duffing+sextic: c3 = -17/36 + 5 gamma/12 (beta=4/3, U=1).
gamma=17/15 -> p=0 ; gamma=8/15 -> p=1 ; gamma=0 -> p=17/9."""
import sys, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import split
from split import nu, U
from scipy.integrate import solve_ivp
b0=4/3
def monoM(eps):
    f=lambda t,y:(np.array([[0,1],[-(1+2*eps*np.cos(nu*t)),0]])@y.reshape(2,2)).ravel()
    M=solve_ivp(f,(0,split.Tp),np.eye(2).ravel(),rtol=1e-13,atol=1e-15,method='DOP853').y[:,-1].reshape(2,2)
    w,V=np.linalg.eig(M); i=np.argmax(abs(w)); eu=np.real(V[:,i]); es=np.real(V[:,1-i]); L=np.real(w[i])
    es=es/(eu[0]*es[1]-eu[1]*es[0]); return eu,es,L,np.log(abs(L))/split.Tp
split.monodromy=monoM
def rhs(model,eps,s=0.0):
    if model=='M0':
        def f(t,y):
            q,p=y; n=0.5*(q*q+p*p); return [p*(1+U*n),-(1+2*eps*np.cos(nu*t))*q-U*n*q]
        return f
    g=float(model[1:])   # 'G<gamma>'
    return lambda t,y:[y[1],-(1+2*eps*np.cos(nu*t))*y[0]-b0*y[0]**3-g*y[0]**5]
split.rhs=rhs
gams={'p=17/9':0.0,'p=1':8/15,'p=0':17/15}
for eps in [0.14,0.16,0.20,0.24,0.28]:
    W0=split.splitting('M0',eps,nph=16,u0=1e-6)['W1']; row=[]
    for lab,g in gams.items():
        W=split.splitting('G%.12f'%g,eps,nph=16,u0=1e-6)['W1']; row.append('%s: %.4e ratio %.4e'%(lab,W,W/W0))
    print('eps %.2f  M0 %.4e | '%(eps,W0)+' | '.join(row),flush=True)
