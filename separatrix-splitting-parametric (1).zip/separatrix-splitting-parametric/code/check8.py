import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
import sys, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import split
from split import nu, U
from scipy.integrate import solve_ivp
def monoM(eps):
    f=lambda t,y:(np.array([[0,1],[-(1+2*eps*np.cos(nu*t)),0]])@y.reshape(2,2)).ravel()
    M=solve_ivp(f,(0,split.Tp),np.eye(2).ravel(),rtol=1e-13,atol=1e-15,method='DOP853').y[:,-1].reshape(2,2)
    w,V=np.linalg.eig(M); i=np.argmax(abs(w)); eu=np.real(V[:,i]); es=np.real(V[:,1-i]); L=np.real(w[i])
    es=es/(eu[0]*es[1]-eu[1]*es[0]); return eu,es,L,np.log(abs(L))/split.Tp
split.monodromy=monoM
# phase-invariant H = G(n) + eps cos(nu t) q^2 ; dG/dn = omega(n)
def make(Gp):
    def f(t,y):
        q,p=y; n=0.5*(q*q+p*p); w=Gp(n)
        return [p*w, -w*q-2*eps_[0]*np.cos(nu*t)*q]
    return f
eps_=[0]
models={'M0':lambda n:1+U*n,
        'PI_rational':lambda n:1+n/(1+17*n/12),
        'PI_quadratic':lambda n:1+n-(17/12)*n*n}
def rhs(model,eps,s=0.0):
    eps_[0]=eps; return make(models[model])
split.rhs=rhs
for eps in [0.16,0.20,0.24,0.28]:
    W={m:split.splitting(m,eps,nph=16,u0=1e-6)['W1'] for m in models}
    print('eps %.2f  M0 %.4e  PI_rational %.4e (ratio %.3e, /eps^17/9 %.3f)  PI_quadratic %.4e (ratio %.3e)'%(eps,W['M0'],W['PI_rational'],W['PI_rational']/W['M0'],W['PI_rational']/W['M0']/eps**(17/9),W['PI_quadratic'],W['PI_quadratic']/W['M0']),flush=True)
