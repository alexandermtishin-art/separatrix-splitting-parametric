import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Appendix B: numerical check of omega(J) = 1 + 3 b J/4 - (51/64) b^2 J^2 for the Duffing oscillator at b = 0.1."""
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
b=0.1
V=lambda q: q*q/2+b*q**4/4
def J_om(A):
    E=V(A); f=lambda th: 2*(E-V(A*np.sin(th)))
    T=4*quad(lambda th: A*np.cos(th)/np.sqrt(f(th)),0,np.pi/2,epsabs=1e-14,epsrel=1e-13)[0]
    J=(2/np.pi)*quad(lambda th: A*np.cos(th)*np.sqrt(f(th)),0,np.pi/2,epsabs=1e-15,epsrel=1e-13)[0]
    return J,2*np.pi/T
for Jt in [0.05,0.02,0.01,0.005]:
    A=brentq(lambda A: J_om(A)[0]-Jt,1e-4,2); J,om=J_om(A)
    print('J %.3f  (omega-1-3bJ/4)/(bJ)^2 = %.4f   (-51/64 = %.4f)'%(J,(om-1-3*b*J/4)/(b*J)**2,-51/64))
