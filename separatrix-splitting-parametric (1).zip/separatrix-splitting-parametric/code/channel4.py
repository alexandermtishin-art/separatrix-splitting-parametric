import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
import sys, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import ell_h2 as H
B=H.B; C=H.C
for eps in [0.16,0.24]:
    t,x,psi=H.homoclinic(eps); e2=eps*eps
    J,om,Q0,Q,dJ,dQ0,dQ=B.funcs(x); z=2*x/B.XMAX-1
    H4=C.chebval(z,H.ch4); dH0=C.chebval(z,H.ch0d)/dJ; dH4=C.chebval(z,H.ch4d)/dJ
    K0J=om-1+e2*dH0+(eps/2)*dQ[0]*np.cos(2*psi)+e2*dH4*np.cos(4*psi)
    K0p=-eps*Q[0]*np.sin(2*psi)-4*e2*H4*np.sin(4*psi)
    t0s=np.linspace(0,np.pi,24,endpoint=False); out={}
    for name in ['Q0','Q4']:
        res=[]
        for t0 in t0s:
            T=t+t0
            if name=='Q0': Pp=0*T; PJ=eps*np.cos(2*T)*dQ0
            else: Pp=-(eps/2)*4*Q[1]*np.sin(4*psi+2*T); PJ=(eps/2)*dQ[1]*np.cos(4*psi+2*T)
            res.append(np.trapezoid(-K0J*Pp+K0p*PJ,t))
        X=np.c_[np.sin(2*t0s),np.cos(2*t0s)]; co=np.linalg.lstsq(X,np.array(res),rcond=None)[0]; out[name]=co[0]+1j*co[1]
    print('eps %.2f  |M_Q0| %.4e  |M_Q4| %.4e  ratio %.2e  |sum| %.4e'%(eps,abs(out['Q0']),abs(out['Q4']),abs(out['Q4']/out['Q0']),abs(out['Q0']+out['Q4'])),flush=True)
