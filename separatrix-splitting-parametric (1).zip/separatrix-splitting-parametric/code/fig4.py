import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Figure 4 and Table 6 rows: softening oscillators, U=-1, ratio to Eq. (5) with delta=+eps^2/16."""
import json, re, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'serif','font.serif':['DejaVu Serif'],'font.size':10,'axes.linewidth':0.8,
                     'axes.spines.top':False,'axes.spines.right':False,'legend.frameon':False,'lines.linewidth':1.4})
BLUE,ORANGE,AQUA,YELLOW,MAGENTA='#2a78d6','#eb6834','#1baf7a','#eda100','#e87ba4'; GRID='#e6e6e3'
D=DATA
def Wth(e,nu=2.0):
    g=e/2; d=+e*e/16; h=np.sqrt(g*g-d*d); a=np.arccos(d/g)
    return 2*np.pi*e*nu*np.sinh(nu*a/(2*h))/np.sinh(np.pi*nu/(2*h))
def mp(fn):
    out={}
    try:
        for l in open(D+fn):
            if l.startswith('RESULT'): x=l.split(); out[round(float(x[2]),4)]=float(x[3])
    except FileNotFoundError: pass
    return out
# control
W0={0.13:6.4871e-12,0.14:3.9126e-11,0.16:7.34128e-10,0.20:4.59536e-08,0.24:7.454997e-7,0.28:5.561e-6}
for fn in ['mp_soft.txt','mp_soft_b.txt','mp_soft_c.txt']:
    for l in open(D+fn):
        if l.startswith('RESULT M0'): x=l.split(); W0[round(float(x[2]),4)]=float(x[3])
# sextic: soft.json + diag files (u0=1e-6 runs), grids
G={'8/15':{},'17/15':{},'26/15':{}}
lab={'G0.5333':'8/15','G1.1333':'17/15','G1.7333':'26/15','G0.533':'8/15','G1.733':'26/15','G17/15':'17/15','G26':'26/15','G17':'17/15'}
osc_eps=[0.095,0.105,0.115,0.125,0.135,0.15]
for fn in ['soft_diag_small.txt','soft_diag_fail.txt','soft_diag_conv.txt','soft_diag_osc.txt','soft_diag_osc2.txt','soft_grid1.txt','soft_grid2.txt','soft_g17a.txt','soft_g17b.txt']:
    k_osc=0
    for l in open(D+fn):
        m=re.match(r'(\S+)\s+eps ([0-9.]+)\s*(\{.*?\})?\s*(?:u0=\S+ )?W1 (\S+)(?: W2/W1 (\S+) res/W (\S+))?',l)
        if not m or m.group(1) not in lab: continue
        if 'u0=3e-7' in l or ("'u0': 3e-07" in l) or 'rtol' in l: continue
        e=float(m.group(2))
        if fn=='soft_diag_osc.txt': e=osc_eps[k_osc]; k_osc+=1
        res=float(m.group(6)) if m.group(6) else 0.0
        G[lab[m.group(1)]][round(e,4)]=(float(m.group(4)),res)
for l in open(D+'soft_bisect.txt'):
    m=re.match(r'BIS gamma (\S+) eps (\S+) W1 (\S+) W2 (\S+) res/W (\S+)',l)
    if m: G[m.group(1)][round(float(m.group(2)),5)]=(float(m.group(3)),float(m.group(5)))
sj=json.load(open(D+'soft.json'))
for e,row in sj.items():
    for g in G:
        W,res=row[g]; G[g].setdefault(round(float(e),4),(W,res/W))
for e,v in mp('mp_g26_010.txt').items(): G['26/15'][e]=(v,0.0)
for e,v in mp('mp_g26_011.txt').items(): G['26/15'][e]=(v,0.0)
for e,v in mp('mp_soft.txt').items(): pass
cosW={0.10:8.1868e-11,0.11:1.1708e-09,0.12:1.0574e-08,0.13:6.7127e-08,0.14:3.2331e-07,0.16:4.03895e-06}
json.dump({'W0':{str(k):v for k,v in W0.items()},'G':{g:{str(k):v for k,v in G[g].items()} for g in G},'cos':{str(k):v for k,v in cosW.items()}},open(D+'soft_all.json','w'),indent=1)
def ok(g,e): return e in G[g] and G[g][e][1]<3e-2
# table rows
def f3(x):
    if x>=1e3: m,ex=('%.2e'%x).split('e'); return '$%s\\times10^{%d}$'%(m,int(ex))
    return ('%.3g'%x)
def sci(x): m,ex=('%.2e'%x).split('e'); return '$%s\\times10^{%d}$'%(m,int(ex))
rows=[]
for e in [0.10,0.11,0.12,0.13,0.14,0.16,0.20,0.24,0.28]:
    wt=Wth(e); c=[('%.2f'%e), sci(W0[e]) if e in W0 else '', ('%.3f'%(W0[e]/wt)) if e in W0 else '']
    for g in ['8/15','17/15','26/15']: c.append(f3(G[g][e][0]/wt) if ok(g,e) else '')
    c.append(f3(cosW[e]/wt) if e in cosW else '')
    rows.append('| '+' | '.join(c)+' |')
open(D+'table5_rows.md','w').write('\n'.join(rows)); print('\n'.join(rows))
# figure
fig,ax=plt.subplots(figsize=(5.6,3.6))
kw=dict(ms=4.5,mec='white',mew=0.6,zorder=3)
for g,c,m in [('8/15',BLUE,'o'),('17/15',ORANGE,'s'),('26/15',AQUA,'D')]:
    es=np.array(sorted(e for e in G[g] if ok(g,e))); r=np.array([G[g][e][0]/Wth(e) for e in es])
    ax.semilogy(es,r,'-',color=c,lw=1.0,zorder=2); ax.semilogy(es,r,m,color=c,label='sextic, $\\gamma=%s$'%g,**kw)
es=np.array(sorted(cosW)); ax.semilogy(es,[cosW[e]/Wth(e) for e in es],'-',color=MAGENTA,lw=1.0); ax.semilogy(es,[cosW[e]/Wth(e) for e in es],'^',color=MAGENTA,label='cosine',**kw)
es=np.array(sorted(W0)); ax.semilogy(es,[W0[e]/Wth(e) for e in es],'x',color='#555555',ms=5,label='Kerr-truncated control')
ax.axhline(1,color='#999999',lw=0.7,ls=':')
ax.set_xlabel('$\\epsilon$'); ax.set_ylabel('$W/W^{(0)}_{\\rm th}$'); ax.grid(True,which='major',color=GRID,lw=0.6)
ax.legend(fontsize=7.5,loc='upper right'); fig.tight_layout(); fig.savefig(ROOT+'figures/fig4_soft.png',dpi=300)
for gg in ['17/15','26/15']:
    g=G[gg]; es=sorted(e for e in g if ok(gg,e)); print(gg,[(e,'%.3g'%(g[e][0]/Wth(e))) for e in es])
