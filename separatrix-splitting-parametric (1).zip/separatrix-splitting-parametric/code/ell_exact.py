import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Exact (elliptic) action-angle Melnikov for Mathieu-Duffing q''+(1+2eps cos2t)q+b q^3=0, b=4/3 (U=1)."""
import numpy as np
from scipy.special import ellipk, ellipe
from scipy.integrate import solve_ivp
b=4/3; NM=30
xg,wg=np.polynomial.legendre.leggauss(80); phg=(xg+1)*np.pi/4; wg=wg*np.pi/4
def basic(A):
    A=np.atleast_1d(A).astype(float)
    w2=1+b*A*A; m=b*A*A/(2*w2)          # m=k^2
    K=ellipk(m); Kp=ellipk(1-m); E=ellipe(m); nome=np.exp(-np.pi*Kp/K)
    om=np.pi*np.sqrt(w2)/(2*K)
    n=np.arange(1,NM+1)[:,None]
    with np.errstate(divide='ignore',invalid='ignore'):
        Q2n=A*A*(2*np.pi**2/(m*K*K))*n*nome**n/(1-nome**(2*n))
        Q0=A*A*(E/K-(1-m))/m
    small=A<1e-4
    if small.any():
        Q2n[:,small]=0; Q2n[0,small]=A[small]**2/2; Q0[small]=A[small]**2/2
    J=(2/np.pi)*np.sum(wg[:,None]*A*A*np.cos(phg[:,None])**2*np.sqrt(1+b*A*A*(1+np.sin(phg[:,None])**2)/2),0)
    return J,om,Q0,Q2n
def withder(A,dA=None):
    A=np.atleast_1d(A); dA=1e-5*np.maximum(A,1e-3) if dA is None else dA
    J,om,Q0,Q=basic(A)
    Jp,_,Q0p,Qp=basic(A+dA); Jm,_,Q0m,Qm=basic(A-dA)
    Jp2,_,Q0p2,Qp2=basic(A+2*dA); Jm2,_,Q0m2,Qm2=basic(A-2*dA)
    d=lambda fp,fm,fp2,fm2:(8*(fp-fm)-(fp2-fm2))/(12*dA)
    dJ=d(Jp,Jm,Jp2,Jm2); dQ=d(Qp,Qm,Qp2,Qm2)/dJ; dQ0=d(Q0p,Q0m,Q0p2,Q0m2)/dJ
    return J,om,Q0,Q,dJ,dQ0,dQ
def homoclinic(eps,d2,span=16,N=40001):
    def rhs(t,y):
        A,psi=y; J,om,Q0,Q,dJ,dQ0,dQ=withder(np.array([A]))
        Jdot=eps*Q[0,0]*np.sin(2*psi); psidot=om[0]-1+d2+(eps/2)*dQ[0,0]*np.cos(2*psi)
        return [Jdot/dJ[0],psidot]
    ev=lambda t,y: y[1]-np.pi/2; ev.terminal=True
    h=eps/2
    s=solve_ivp(rhs,(0,200/h),[1e-7,np.pi/4],events=ev,rtol=1e-12,atol=1e-16,method='DOP853',dense_output=True)
    ttip=s.t_events[0][0]
    tl=np.linspace(-span/h,0,N); A=s.sol(ttip+tl)[0]; psi=s.sol(ttip+tl)[1]
    keep=ttip+tl>0
    tl,A,psi=tl[keep],A[keep],psi[keep]
    t=np.r_[tl,-tl[-2::-1]]; A=np.r_[A,A[-2::-1]]; psi=np.r_[psi,np.pi-psi[-2::-1]]
    return t,A,psi
def melnikov(eps,d2,nt0=24,span=16,N=40001):
    t,A,psi=homoclinic(eps,d2,span,N)
    J,om,Q0,Q,dJ,dQ0,dQ=withder(A)
    K0J=om-1+d2+(eps/2)*dQ[0]*np.cos(2*psi); K0p=-eps*Q[0]*np.sin(2*psi)
    m=2*np.arange(1,NM+1)[:,None]
    t0s=np.linspace(0,np.pi,nt0,endpoint=False); res=[]
    for t0 in t0s:
        tt=t+t0; th=psi+tt; c2=np.cos(2*tt)
        Pp=-eps*c2*np.sum(m*Q*np.sin(m*th),0)+eps*Q[0]*np.sin(2*psi)
        PJ=eps*c2*(dQ0+np.sum(dQ*np.cos(m*th),0))-(eps/2)*dQ[0]*np.cos(2*psi)
        res.append(np.trapezoid(-K0J*Pp+K0p*PJ,t))
    res=np.array(res); X=np.c_[np.sin(2*t0s),np.cos(2*t0s),np.sin(4*t0s),np.cos(4*t0s),np.ones(nt0)]
    co=np.linalg.lstsq(X,res,rcond=None)[0]
    return np.hypot(co[0],co[1]),np.hypot(co[2],co[3]),np.abs(res-X@co).max(),co[4]
if __name__=='__main__':
    J,om,Q0,Q=basic(np.array([1e-3,0.3]))
    print('check small A: J',J[0],'A^2/2',0.5e-6,' Q2',Q[0,0],'om',om)
    direct={0.14:1.4559e-12,0.16:3.4785e-11,0.20:3.2481e-09,0.24:7.2775e-08,0.28:7.1140e-07}
    for eps,Wd in direct.items():
        for d2 in [0.0,-eps**2/16]:
            W,W2,r,c0=melnikov(eps,d2)
            print('eps %.2f d2 %+.5f  ellMel %.4e  direct %.4e  ratio %.3f  (2nd %.1e res %.1e const %.1e)'%(eps,d2,W,Wd,Wd/W,W2,r,c0),flush=True)
