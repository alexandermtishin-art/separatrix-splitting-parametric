import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Table 7 flow values from 32 independent orbits per case (random phase in [0,pi) and random distance
0.5-1.5 x 1e-4 from the saddle); errors from the orbit-to-orbit scatter."""
import sys, json, numpy as np
from multiprocessing import Pool
sys.path.insert(0,HERE)
from table7_flow import run
from width import DRIFT, KICK
def job(a):
    model,eps,ph,amp=a; a0=amp*np.exp(1j*ph)
    S,NP=run(np.sqrt(2)*a0.real,np.sqrt(2)*a0.imag,eps,4/3,model,50,10,10000,40,DRIFT,KICK,0.06*eps,0.3*eps)
    return S.tolist(),NP.tolist()
if __name__=='__main__':
    rng=np.random.default_rng(12345)
    cases=[(0,0.20),(0,0.24),(0,0.28),(1,0.24),(1,0.28),(1,0.32),(2,0.24),(2,0.28)]
    jobs=[(m,e,rng.uniform(0,np.pi),1e-4*rng.uniform(0.5,1.5)) for (m,e) in cases for _ in range(32)]
    with Pool(2) as P: res=P.map(job,jobs,chunksize=1)
    out={}; Tseg=1e4*np.pi
    for (m,e,ph,am),(S,NP) in zip(jobs,res): out.setdefault('%s_%.2f'%('MDS'[m],e),[]).append((S,NP))
    json.dump(out,open(DATA+'table7_many.json','w'))
    for k,v in out.items():
        S=np.array([x[0] for x in v]); N=np.array([x[1] for x in v])
        lam=S.sum(1)/(10*Tseg); T=10*Tseg/N.sum(1); n=len(lam)
        print('%s T %.1f (%.1f) lam %.5f (%.5f) min %.5f max %.5f'%(k,T.mean(),T.std(ddof=1)/np.sqrt(n),lam.mean(),lam.std(ddof=1)/np.sqrt(n),lam.min(),lam.max()),flush=True)
