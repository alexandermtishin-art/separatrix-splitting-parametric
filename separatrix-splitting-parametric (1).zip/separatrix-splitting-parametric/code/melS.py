import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Melnikov kick for a family of lab-frame models: H = p^2/2 + Omega(t)^2 q^2/2 + beta(t) q^4/4,
beta(t) = beta0 * (Omega(t)/Omega0)^s.  s=0: Duffing (beta fixed); s=2: SQUID/transmon-like (Kerr U = 3 beta/(4 Omega^2) fixed).
RWA: g = eps nu/4, delta = Omega0 - nu/2 + eps^2 Omega0/4 (+ s-dependent RWA shift neglected), Kerr U = 3 beta0/(4 Omega0^2)."""
import numpy as np, sys
sys.path.insert(0,'.')
from melD import homoclinic
def kickS(eps, s, U=1.0, nu=2.0, O0=1.0):
    g=eps*nu/4; d=O0-nu/2+eps**2*O0/4; b0=4*U*O0**2/3
    t,c=homoclinic(g,d,abs(U)) if U>0 else homoclinic(g,d,U)
    n=abs(c)**2; grad=d*np.conj(c)+U*n*np.conj(c)+g*c
    t0s=np.linspace(0,2*np.pi/nu,24,endpoint=False); res=[]
    for t0 in t0s:
        tt=t+t0; a=c*np.exp(-1j*nu*tt/2); Om=O0*(1+eps*np.cos(nu*tt)); beta=b0*(Om/O0)**s
        mod=(O0/4)*(2*eps*np.cos(nu*tt)+eps**2*np.cos(nu*tt)**2)
        adot=-1j*O0*a-1j*mod*2*(a+np.conj(a))-1j*(beta/(16*O0**2))*4*(a+np.conj(a))**3
        cdot=(adot+1j*nu/2*a)*np.exp(1j*nu*tt/2)
        cp=cdot-(-1j*(d+U*n)*c-1j*g*np.conj(c))
        res.append(np.trapezoid(2*np.real(grad*cp),t))
    X=np.c_[np.sin(nu*t0s),np.cos(nu*t0s)]; co=np.linalg.lstsq(X,np.array(res),rcond=None)[0]
    return np.hypot(*co)
if __name__=='__main__':
    for eps in [0.20,0.24,0.28]:
        W1=np.pi*eps*2/np.cosh(np.pi/eps)
        row=[kickS(eps,s)/W1 for s in [0,1,2,3,4]]
        print('eps %.2f  W/W1 for s=0..4:'%eps,' '.join('%.4f'%x for x in row))
