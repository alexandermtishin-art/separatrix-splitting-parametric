import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Numba kernels for the canonical frequency-modulated Kerr oscillator (model C).

Model:  H = Omega(t) n + (U/2) n^2,  a = (Omega q + i p)/sqrt(2 Omega),  n = |a|^2
        da/dt = -i (Omega + U n) a + kappa a*,          kappa = Omega'/(2 Omega)
Tangent (real coordinates x = Re da, y = Im da): d/dt (x, y) = J (x, y),
        J = [[c1, A + c2], [-A + c2, -c1]],  A = Omega + 2 U n,  c1 + i c2 = kappa - i U a^2
Exact Euclidean logarithmic norm: mu = |kappa - i U a^2|.

Protocols (ptype, par):
  0  tanh ramp:     Omega = O0 + (O1-O0)(1+tanh((t-t0)/tau))/2           par = [O0, O1, t0, tau]
  1  periodic:      Omega = O0 (1 + eps cos(nu t))                         par = [O0, eps, nu, 0]
  2  smooth pulse:  Omega = O0 + (O1-O0)[S(t-t1) - S(t-t2)], S = (1+tanh(./tau))/2
                                                                           par = [O0, O1, t1, t2, tau]
"""
import numpy as np
from numba import njit


@njit(cache=True)
def proto(t, ptype, par):
    if ptype == 0:
        O0, O1, t0, tau = par[0], par[1], par[2], par[3]
        s = np.tanh((t - t0) / tau)
        return O0 + (O1 - O0) * (1.0 + s) / 2.0, (O1 - O0) / (2.0 * tau) * (1.0 - s * s)
    elif ptype == 1:
        O0, eps, nu = par[0], par[1], par[2]
        return O0 * (1.0 + eps * np.cos(nu * t)), -O0 * eps * nu * np.sin(nu * t)
    else:
        O0, O1, t1, t2, tau = par[0], par[1], par[2], par[3], par[4]
        s1 = np.tanh((t - t1) / tau)
        s2 = np.tanh((t - t2) / tau)
        Om = O0 + (O1 - O0) * ((1.0 + s1) / 2.0 - (1.0 + s2) / 2.0)
        dOm = (O1 - O0) / (2.0 * tau) * ((1.0 - s1 * s1) - (1.0 - s2 * s2))
        return Om, dOm


@njit(cache=True)
def f(t, y, ptype, par, U):
    """y = [ar, ai, M00, M01, M10, M11]."""
    Om, dOm = proto(t, ptype, par)
    k = dOm / (2.0 * Om)
    ar, ai = y[0], y[1]
    n = ar * ar + ai * ai
    w = Om + U * n
    # da = -i w a + k conj(a)
    dar = w * ai + k * ar
    dai = -w * ar - k * ai
    A = Om + 2.0 * U * n
    # C = k - i U a^2 ; a^2 = (ar^2 - ai^2) + 2 i ar ai
    c1 = k + U * 2.0 * ar * ai
    c2 = -U * (ar * ar - ai * ai)
    J00, J01, J10, J11 = c1, A + c2, -A + c2, -c1
    out = np.empty(6)
    out[0] = dar
    out[1] = dai
    out[2] = J00 * y[2] + J01 * y[4]
    out[3] = J00 * y[3] + J01 * y[5]
    out[4] = J10 * y[2] + J11 * y[4]
    out[5] = J10 * y[3] + J11 * y[5]
    return out


@njit(cache=True)
def local_rates(t, ar, ai, ptype, par, U):
    Om, dOm = proto(t, ptype, par)
    k = dOm / (2.0 * Om)
    n = ar * ar + ai * ai
    c1 = k + U * 2.0 * ar * ai
    c2 = -U * (ar * ar - ai * ai)
    mu = np.sqrt(c1 * c1 + c2 * c2)
    return mu, abs(k), abs(U) * n, n


@njit(cache=True)
def propagate(a0r, a0i, ptype, par, U, t0, T, dt):
    """RK4 from t0 to T. Returns final state (a, M) and running integrals:
    I_mu = int mu dt, I_k = int |kappa| dt, I_un = int U n dt, max ratio mu/(2|kappa|) is not
    returned (2|kappa| can vanish); instead returns max of mu - 2|kappa| and n_max."""
    nst = int(np.round((T - t0) / dt))
    y = np.zeros(6)
    y[0], y[1] = a0r, a0i
    y[2], y[5] = 1.0, 1.0
    t = t0
    I_mu = 0.0
    I_k = 0.0
    I_un = 0.0
    nmax = a0r * a0r + a0i * a0i
    exc = -1e300
    mu0, k0, un0, n0 = local_rates(t, y[0], y[1], ptype, par, U)
    for i in range(nst):
        k1 = f(t, y, ptype, par, U)
        k2 = f(t + dt / 2, y + dt / 2 * k1, ptype, par, U)
        k3 = f(t + dt / 2, y + dt / 2 * k2, ptype, par, U)
        k4 = f(t + dt, y + dt * k3, ptype, par, U)
        y = y + dt / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
        t += dt
        mu1, k1_, un1, n1 = local_rates(t, y[0], y[1], ptype, par, U)
        I_mu += 0.5 * dt * (mu0 + mu1)
        I_k += 0.5 * dt * (k0 + k1_)
        I_un += 0.5 * dt * (un0 + un1)
        if n1 > nmax:
            nmax = n1
        if mu1 - 2 * k1_ > exc:
            exc = mu1 - 2 * k1_
        mu0, k0, un0 = mu1, k1_, un1
    return y, I_mu, I_k, I_un, nmax, exc


@njit(cache=True)
def trace(a0r, a0i, ptype, par, U, t0, T, dt, every):
    """Time series: t, Re a, Im a, mu, |kappa|, U n, log ||M||_2."""
    nst = int(np.round((T - t0) / dt))
    nrec = nst // every + 1
    out = np.zeros((nrec, 7))
    y = np.zeros(6)
    y[0], y[1] = a0r, a0i
    y[2], y[5] = 1.0, 1.0
    t = t0
    j = 0
    for i in range(nst + 1):
        if i % every == 0 and j < nrec:
            mu, kk, un, n = local_rates(t, y[0], y[1], ptype, par, U)
            M = y[2:].reshape(2, 2)
            s = np.linalg.svd(M)[1][0]
            out[j, 0] = t
            out[j, 1] = y[0]
            out[j, 2] = y[1]
            out[j, 3] = mu
            out[j, 4] = kk
            out[j, 5] = un
            out[j, 6] = np.log(s)
            j += 1
        if i == nst:
            break
        k1 = f(t, y, ptype, par, U)
        k2 = f(t + dt / 2, y + dt / 2 * k1, ptype, par, U)
        k3 = f(t + dt / 2, y + dt / 2 * k2, ptype, par, U)
        k4 = f(t + dt, y + dt * k3, ptype, par, U)
        y = y + dt / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
        t += dt
    return out


@njit(cache=True)
def lyapunov(a0r, a0i, ptype, par, U, Ttrans, T, dt, renorm):
    """Benettin largest Lyapunov exponent for model C. Also returns time averages of
    mu, |kappa| and U n over the measurement window, and n_max."""
    y = np.zeros(6)
    y[0], y[1] = a0r, a0i
    y[2], y[5] = 1.0, 0.0
    y[3], y[4] = 0.0, 0.0
    # use first column as tangent vector (y[2], y[4]); y[3], y[5] unused (kept zero)
    t = 0.0
    ntr = int(np.round(Ttrans / dt))
    for i in range(ntr):
        k1 = f(t, y, ptype, par, U)
        k2 = f(t + dt / 2, y + dt / 2 * k1, ptype, par, U)
        k3 = f(t + dt / 2, y + dt / 2 * k2, ptype, par, U)
        k4 = f(t + dt, y + dt * k3, ptype, par, U)
        y = y + dt / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
        t += dt
        if i % renorm == 0:
            nr = np.sqrt(y[2] ** 2 + y[4] ** 2)
            y[2] /= nr
            y[4] /= nr
    nr = np.sqrt(y[2] ** 2 + y[4] ** 2)
    y[2] /= nr
    y[4] /= nr
    nst = int(np.round(T / dt))
    S = 0.0
    Smu = 0.0
    Sk = 0.0
    Sun = 0.0
    nmax = 0.0
    for i in range(nst):
        k1 = f(t, y, ptype, par, U)
        k2 = f(t + dt / 2, y + dt / 2 * k1, ptype, par, U)
        k3 = f(t + dt / 2, y + dt / 2 * k2, ptype, par, U)
        k4 = f(t + dt, y + dt * k3, ptype, par, U)
        y = y + dt / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
        t += dt
        mu, kk, un, n = local_rates(t, y[0], y[1], ptype, par, U)
        Smu += mu * dt
        Sk += kk * dt
        Sun += un * dt
        if n > nmax:
            nmax = n
        if (i + 1) % renorm == 0 or i == nst - 1:
            nr = np.sqrt(y[2] ** 2 + y[4] ** 2)
            S += np.log(nr)
            y[2] /= nr
            y[4] /= nr
    return S / T, Smu / T, Sk / T, Sun / T, nmax
