import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
import sys, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import ell_exact as EE
from scipy.integrate import quad
from scipy.optimize import brentq
b=EE.b; U=0.75*b
def fun(A):
    J,om,Q0,Q=EE.basic(np.array([A])); E=A*A/2+b*A**4/4
    return J[0],E-J[0],Q[0,0]
def dJdA(A):
    J,om,Q0,Q=EE.basic(np.array([A])); return (A+b*A**3)/om[0]
def imt(eps,d2,exact=True):
    if exact:
        def X(A):
            J,F,Q2=fun(A); return -2*(F+d2*J)/(eps*Q2)
        def integrand_A(A):
            J,F,Q2=fun(A); x=-2*(F+d2*J)/(eps*Q2)
            return dJdA(A)/(eps*Q2*np.sqrt(x*x-1))
        Am=brentq(lambda A: X(A)+1,1e-6,5)
        # substitution A=Am+u^2 to remove 1/sqrt singularity; tail to large A
        f=lambda u: integrand_A(Am+u*u)*2*u
        I1=quad(f,0,np.sqrt(3.0-Am) if Am<3 else 1,limit=400,epsabs=1e-13,epsrel=1e-12)[0]
        g=lambda lA: integrand_A(np.exp(lA))*np.exp(lA)
        I2=quad(g,np.log(3.0),np.log(1e6),limit=400,epsabs=1e-13,epsrel=1e-12)[0]
        return I1+I2
    else:
        # phase-invariant: F=U J^2/2, Q2=J
        Jm=2*(eps/2-d2)/U
        f=lambda J: 1/(eps*J*np.sqrt((2*(U*J*J/2+d2*J)/(eps*J))**2-1))
        fu=lambda u: f(Jm+u*u)*2*u
        return quad(fu,0,10,limit=400,epsabs=1e-14)[0]+quad(lambda lJ: f(np.exp(lJ))*np.exp(lJ),np.log(Jm+100),np.log(1e12),limit=200)[0]
for eps in [0.06,0.08,0.10,0.13,0.16,0.20,0.24,0.28]:
    d2=-eps**2/16
    te=imt(eps,d2); ti=imt(eps,d2,False)
    D=2*(te-ti)
    print('eps %.2f  nu*Imt*_exact %.4f  nu*Imt*_inv %.4f (pi/eps %.4f)  nu*Delta %.4f   nu*Delta-(17/9)ln(1/eps) %.4f'%(eps,2*te,2*ti,np.pi/eps,D,D-17/9*np.log(1/eps)),flush=True)
