import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""First-order Melnikov kick for (i) model C and (ii) lab-frame Duffing model D, by quadrature of the exact
rotating-frame perturbation along the RWA homoclinic orbit (window centred on the lobe tip)."""
import numpy as np
from scipy.integrate import solve_ivp
def homoclinic(g, d, U=1.0, span=14.0):
    h=np.sqrt(g*g-d*d)
    f=lambda t,y: (lambda c: [(-1j*(d+U*abs(c)**2)*c-1j*g*np.conj(c)).real,(-1j*(d+U*abs(c)**2)*c-1j*g*np.conj(c)).imag])(y[0]+1j*y[1])
    # start on unstable manifold, integrate until n reaches max, then use symmetry n(-t)=n(t) is not exact for phases, so integrate forward long and centre
    x0=1e-12; y0=-h*x0/(g-d)
    T=60/h; ts=np.linspace(0,T,600001)
    s=solve_ivp(f,(0,T),[x0,y0],t_eval=ts,rtol=1e-13,atol=1e-20,method='DOP853')
    c=s.y[0]+1j*s.y[1]; k=np.argmax(abs(c)); t=ts-ts[k]
    m=(t>-span/h)&(t<span/h)
    return t[m], c[m]
def kick(model, eps, nu=2.0, O0=1.0, U=1.0):
    g=eps*nu/4
    if model=='C': d=O0-nu/2
    else: d=O0-nu/2+eps**2*O0/4
    t,c=homoclinic(g,d,U); n=abs(c)**2
    grad=d*np.conj(c)+U*n*np.conj(c)+g*c
    beta=4*U*O0**2/3
    res=[]; t0s=np.linspace(0,2*np.pi/nu,24,endpoint=False)
    for t0 in t0s:
        tt=t+t0
        if model=='C':
            Om=O0*(1+eps*np.cos(nu*tt)); k=-O0*eps*nu*np.sin(nu*tt)/(2*Om)
            cdot=-1j*(Om-nu/2+U*n)*c+k*np.exp(1j*nu*tt)*np.conj(c)
        else:
            a=c*np.exp(-1j*nu*tt/2)
            mod=(O0/4)*(2*eps*np.cos(nu*tt)+eps**2*np.cos(nu*tt)**2)
            adot=-1j*O0*a-1j*mod*2*(a+np.conj(a))-1j*(beta/(16*O0**2))*4*(a+np.conj(a))**3
            cdot=(adot+1j*nu/2*a)*np.exp(1j*nu*tt/2)
        cp=cdot-(-1j*(d+U*n)*c-1j*g*np.conj(c))
        res.append(np.trapezoid(2*np.real(grad*cp),t))
    res=np.array(res); X=np.c_[np.sin(nu*t0s),np.cos(nu*t0s),np.sin(2*nu*t0s),np.cos(2*nu*t0s)]
    co=np.linalg.lstsq(X,res,rcond=None)[0]
    return np.hypot(co[0],co[1]), np.hypot(co[2],co[3]), np.abs(res-X@co).max(), g, d
if __name__=='__main__':
    for eps in [0.16,0.20,0.24,0.28]:
        WC=kick('C',eps); WD=kick('D',eps)
        W1=np.pi*eps*2/np.cosh(np.pi*2/(4*eps*0.5))
        print('eps %.2f  W1 %.3e | C: W(nu) %.3e (x%.2f) W(2nu) %.1e res %.1e | D: W(nu) %.3e  W(2nu) %.1e res %.1e  d/g %.3f  W_D/W_C %.3g'%(eps,W1,WC[0],WC[0]/W1,WC[1],WC[2],WD[0],WD[1],WD[2],WD[4]/WD[3],WD[0]/WC[0]))
