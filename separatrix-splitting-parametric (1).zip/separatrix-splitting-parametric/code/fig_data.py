import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
import sys, json, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import split
from scipy.integrate import solve_ivp
nu=2.0; U=1.0; b0=4/3
def monoM(eps):
    f=lambda t,y:(np.array([[0,1],[-(1+2*eps*np.cos(nu*t)),0]])@y.reshape(2,2)).ravel()
    M=solve_ivp(f,(0,split.Tp),np.eye(2).ravel(),rtol=1e-13,atol=1e-15,method='DOP853').y[:,-1].reshape(2,2)
    w,V=np.linalg.eig(M); i=np.argmax(abs(w)); eu=np.real(V[:,i]); es=np.real(V[:,1-i]); L=np.real(w[i])
    es=es/(eu[0]*es[1]-eu[1]*es[0]); return eu,es,L,np.log(abs(L))/split.Tp
def samples(f,eps,nph=32,u0=1e-6):
    eu,es,L,hF=monoM(eps); lnL=np.log(abs(L)); out=[]
    for j in range(nph):
        x=u0*np.exp(lnL*j/nph)*eu; t=0.0; left=False; rec=[]
        for k in range(600):
            x=solve_ivp(f,(t,t+split.Tp),x,rtol=1e-13,atol=1e-18,method='DOP853').y[:,-1]; t+=split.Tp
            r=np.hypot(*x)
            if r>0.2: left=True
            if left:
                u,s=split.coords(x,eu,es); rec.append((r,u*s))
                if len(rec)>3 and rec[-1][0]>rec[-2][0] and rec[-2][0]<0.03: break
        rec=np.array(rec); km=np.argmin(rec[:,0]); out.append(hF*rec[km,1])
    return (2*np.pi*np.arange(nph)/nph).tolist(), out
eps=0.20
fM=lambda t,y:[y[1],-(1+2*eps*np.cos(nu*t))*y[0]-b0*y[0]**3]
def fM0(t,y):
    q,p=y; n=0.5*(q*q+p*p); return [p*(1+U*n),-(1+2*eps*np.cos(nu*t))*q-U*n*q]
ph,wM=samples(fM,eps); _,wM0=samples(fM0,eps)
# Delta(eps) on a fine grid for five gammas
import imt_sextic as S
gams=[0.0,8/15,17/15,(17/9+1)*3/5,34/15]
eg=np.linspace(0.12,0.30,19); D={}
for g in gams:
    D[str(g)]=[2*(S.imt(e,g)-S.imt(e,g,False)) for e in eg]
el=np.array([0.04,0.05,0.06,0.08,0.10,0.12,0.14,0.17,0.20,0.24,0.28]); R={}
for g in gams:
    p=17/9-5*g/3; R[str(g)]=[2*(S.imt(e,g)-S.imt(e,g,False))-p*np.log(1/e) for e in el]
json.dump(dict(phase=ph,wM=wM,wM0=wM0,eps_grid=eg.tolist(),Delta=D,eps_low=el.tolist(),resid=R),open('data/fig_data.json','w'))
print('ok')
