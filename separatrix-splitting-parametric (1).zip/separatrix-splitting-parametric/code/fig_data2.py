import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
import sys, json, numpy as np
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
src=open(''+HERE+'imt_sextic.py').read().split('TAB={}')[0]
ns={}; exec(src,ns)
gams=[0.0,8/15,17/15,26/15,34/15]
ns['TAB']={g:ns['table'](g,Amax=40.0,N=800) for g in gams}
eg=np.linspace(0.05,0.30,26)
D={str(g):[2*(ns['imt'](e,g)-ns['imt'](e,g,False)) for e in eg] for g in gams}
# MD: same E(J), Q2=J
exec(open(''+HERE+'run_MD.py').read().split('out={}')[0].split('# energy-action of Duffing')[1].join(['import ell_exact as EE\nfrom scipy.integrate import quad\nfrom scipy.optimize import brentq\n','']) if False else '')
import ell_exact as EE
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.interpolate import CubicSpline
As=np.geomspace(1e-3,40,900); Jt,omt,Q0t,Qt=EE.basic(As); Et=As**2/2+EE.b*As**4/4
lJ=np.log(Jt); sF=CubicSpline(lJ,np.log(Et-Jt))
def imt_MD(eps):
    d2=-eps**2/16
    Xf=lambda x: -2*(np.exp(sF(x))+d2*np.exp(x))/(eps*np.exp(x))
    xm=brentq(lambda x: Xf(x)+1,lJ[2],lJ[-3])
    f=lambda x: 1/(eps*np.sqrt(Xf(x)**2-1))
    I=quad(lambda u: f(xm+u*u)*2*u,0,np.sqrt(lJ[-1]-xm),limit=500)[0]
    return I+Jt[-1]/(2*(Et[-1]-Jt[-1])*(4/3-1))
D['MD']=[2*(imt_MD(e)-ns['imt'](e,0.0,False)) for e in eg]
json.dump({'eps':eg.tolist(),'Delta':D},open('data/fig_data2.json','w')); print('ok')
