import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Energy width of the chaotic layer from long symplectic (Yoshida 8th order) integrations.
At every stroboscopic time t = k*pi the point is projected on symplectically normalized Floquet coordinates;
when it is close to the saddle (r < rc) we record w = h_F * u * s. The layer border is estimated from the
distribution of |w| over all passages."""
import sys, json, numpy as np
from numba import njit
from scipy.integrate import solve_ivp
from multiprocessing import Pool

# Yoshida 8th-order coefficients (solution A)
w1=-0.161582374150097E1; w2=-0.244699182370524E1; w3=-0.716989419708120E-2; w4=0.244002732616735E1
w5=0.157739928123617E0; w6=0.182020630970714E1; w7=0.104242620869991E1
ws=[w7,w6,w5,w4,w3,w2,w1]; w0=1-2*sum(ws)
D=np.array(ws[::1]+[w0]+ws[::-1])          # 15 drift weights (symmetric)
Cs=np.zeros(16); Cs[0]=D[0]/2; Cs[-1]=D[-1]/2
for i in range(1,15): Cs[i]=(D[i-1]+D[i])/2
DRIFT=Cs.copy(); KICK=D.copy()              # drift-kick-drift composition: c_i drifts, d_i kicks

@njit(cache=True)
def force(q,t,eps,b0,model):
    c=np.cos(2.0*t)
    if model==0:   # M
        return -(1.0+2.0*eps*c)*q-b0*q**3
    Om=1.0+eps*c
    if model==1:   # D
        return -Om*Om*q-b0*q**3
    return -Om*Om*q-b0*Om*Om*q**3   # S

@njit(cache=True)
def run(q,p,eps,b0,model,nper,nsub,DR,KI,eu0,eu1,es0,es1,hF,rc):
    dt=np.pi/nsub; t=0.0
    out=np.empty(nper); cnt=0
    inside=False; rmin=1.0; wbest=0.0
    for k in range(nper):
        for j in range(nsub):
            for i in range(15):
                q+=DR[i]*dt*p; t+=DR[i]*dt
                p+=KI[i]*dt*force(q,t,eps,b0,model)
            q+=DR[15]*dt*p; t+=DR[15]*dt
        t=(k+1)*np.pi
        r=np.sqrt(q*q+p*p)
        if r<rc:
            if (not inside) or r<rmin:
                u=q*es1-p*es0; s=eu0*p-eu1*q
                rmin=r; wbest=hF*u*s
            inside=True
        elif inside:
            out[cnt]=wbest; cnt+=1; inside=False
    return out[:cnt],q,p

def mono(eps,model):
    def f(t,y):
        c=np.cos(2*t); Om=1+eps*c
        a=(1+2*eps*c) if model==0 else Om*Om
        return (np.array([[0,1],[-a,0]])@y.reshape(2,2)).ravel()
    M=solve_ivp(f,(0,np.pi),np.eye(2).ravel(),rtol=1e-13,atol=1e-15,method='DOP853').y[:,-1].reshape(2,2)
    w,V=np.linalg.eig(M); i=np.argmax(abs(w)); eu=np.real(V[:,i]); es=np.real(V[:,1-i]); L=np.real(w[i])
    es=es/(eu[0]*es[1]-eu[1]*es[0]); return eu,es,np.log(abs(L))/np.pi

def job(a):
    model,eps,ph,nper=a; b0=4/3
    eu,es,hF=mono(eps,model)
    a0=1e-4*np.exp(1j*ph)
    W,q,p=run(np.sqrt(2)*a0.real,np.sqrt(2)*a0.imag,eps,b0,model,nper,40,DRIFT,KICK,eu[0],eu[1],es[0],es[1],hF,0.02)
    return W.tolist(),hF

if __name__=='__main__':
    which=sys.argv[1]; nper=int(sys.argv[2])
    cases={'M':[(0,0.20),(0,0.28)],'D':[(1,0.24),(1,0.28)],'S':[(2,0.24)],'all':[(0,0.20),(0,0.28),(1,0.24),(1,0.28),(2,0.24)]}[which]
    phis=np.linspace(0,np.pi,4,endpoint=False)+0.3
    jobs=[(m,e,ph,nper) for (m,e) in cases for ph in phis]
    with Pool(1) as P: res=P.map(job,jobs)
    out={}
    for (m,e,ph,n),(W,hF) in zip(jobs,res):
        out.setdefault('%d_%.2f'%(m,e),{'hF':hF,'w':[]})['w']+=W
    json.dump(out,open(''+DATA+'width_%s.json'%which,'w'))
    for k,v in out.items():
        a=np.abs(np.array(v['w'])); print(k,'npass',len(a),'max|w| %.3e  q99 %.3e  q999 %.3e'%(a.max(),np.quantile(a,0.99),np.quantile(a,0.999)),flush=True)
