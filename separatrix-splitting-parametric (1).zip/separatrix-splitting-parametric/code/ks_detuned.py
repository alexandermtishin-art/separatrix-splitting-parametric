import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Kerr-separatrix Melnikov estimate of model M on the separatrix with and without the second-order detuning
delta=-eps^2/16 (Sec. 4, Table 1)."""
import sys, json, numpy as np
sys.path.insert(0,HERE)
src=open(HERE+'gather.py').read().split('out={}')[0]
src=src.replace("def melRWA_M(eps,inv=False):","def melRWA_M(eps,inv=False,dd=0.0):").replace("g=eps*nu/4; d=0.0;","g=eps*nu/4; d=dd;")
ns={}; exec(src,ns)
sp=json.load(open(DATA+'splitting.json'))
out={}
for e in [0.16,0.18,0.20,0.22,0.24,0.26,0.28]:
    k=str(e); W=sp[k]['M']
    a=ns['melRWA_M'](e); b=ns['melRWA_M'](e,dd=-e*e/16); a0=ns['melRWA_M'](e,True); b0=ns['melRWA_M'](e,True,dd=-e*e/16)
    out[k]=dict(KS=a,KS_det=b,KS0=a0,KS0_det=b0)
    print('eps %.2f  KS %.4e KSdet %.4e ratio %.3f | over W: %.1f -> %.1f | M0: %.4e -> %.4e'%(e,a,b,b/a,a/W,b/W,a0,b0),flush=True)
json.dump(out,open(DATA+'ks_detuned.json','w'),indent=1)
