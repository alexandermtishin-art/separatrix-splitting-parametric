import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Separatrix-map column of Table 7: map (6) with the measured kick W and the Floquet rate h_F,
C = 8 h^4/(U g^2), g = eps/2, U = 1; mean passage time and Lyapunov exponent per unit time."""
import sys, json, numpy as np
from numba import njit
sys.path.insert(0,HERE)
from width import mono
@njit(cache=True)
def run(W,h,C,lam,n,seed):
    np.random.seed(seed)
    w=W*(np.random.rand()-0.5); tau=2*np.pi*np.random.rand(); dw=1.0; dt=0.0
    Tsum=0.0; Lsum=0.0
    for i in range(n):
        w1=w-W*np.sin(tau); dw1=dw-W*np.cos(tau)*dt
        L=np.log(C/abs(w1)); tau1=tau+lam*L; dt1=dt-lam*dw1/w1
        Tsum+=L/h
        nr=np.sqrt(dw1*dw1+(W*dt1)**2); Lsum+=np.log(nr); dw=dw1/nr; dt=dt1/nr
        w=w1; tau=tau1%(2*np.pi)
    return Tsum/n, Lsum/Tsum
cases=[('M',0,0.20,3.2481e-9),('M',0,0.24,7.2775e-8),('M',0,0.28,7.1140e-7),('D',1,0.24,1.1524e-8),('D',1,0.28,1.0794e-7),('D',1,0.32,5.96e-7),('S',2,0.24,1.91e-6),('S',2,0.28,1.80e-5)]
if __name__=='__main__':
    out={}
    for lab,m,e,W in cases:
        eu,es,h=mono(e,m); g=e/2; C=8*h**4/g**2; lam=2/h
        r=np.array([run(W,h,C,lam,1000000,s) for s in range(8)])
        T,L=r.mean(0); sT,sL=r.std(0,ddof=1)/np.sqrt(8)
        T7=np.log(np.e*C/(lam*W))/h
        out['%s_%.2f'%(lab,e)]=dict(T=T,sT=sT,lam=L,slam=sL,hF=h,T_eq7=T7)
        print('%s %.2f  h_F %.5f  <T>_map %.1f (%.1f)  eq7 %.1f  lam_map %.4f (%.4f)'%(lab,e,h,T,sT,T7,L,sL),flush=True)
    json.dump(out,open(DATA+'map_table7.json','w'),indent=1)
    