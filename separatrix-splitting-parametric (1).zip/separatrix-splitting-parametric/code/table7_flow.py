import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Table 5 with the Yoshida 8th-order symplectic composition (drift-kick) and its exact tangent map.
Models: 0 = M, 1 = D (Omega = 1+eps cos 2t, beta const), 2 = S (beta ~ Omega^2).
Per orbit: 50 transient periods, then 10 segments of 1e4 periods; passages counted when n=(q^2+p^2)/2
falls below 0.06*eps after exceeding 0.3*eps (same criterion as the RK4 runs)."""
import sys, json, numpy as np
from numba import njit
from multiprocessing import Pool
sys.path.insert(0,HERE)
from width import DRIFT, KICK
@njit(cache=True)
def frc(q,t,eps,b0,model):
    c=np.cos(2.0*t)
    if model==0:
        a=1.0+2.0*eps*c; return -a*q-b0*q**3, -a-3.0*b0*q*q
    Om2=(1.0+eps*c)**2
    if model==1: return -Om2*q-b0*q**3, -Om2-3.0*b0*q*q
    return -Om2*(q+b0*q**3), -Om2*(1.0+3.0*b0*q*q)
@njit(cache=True)
def run(q,p,eps,b0,model,ntr,nseg,per,nsub,DR,KI,nlo,nhi):
    dt=np.pi/nsub; t=0.0; dq=1.0; dp=0.0
    S=np.zeros(nseg); NP=np.zeros(nseg); armed=False
    for k in range(ntr+nseg*per):
        for j in range(nsub):
            for i in range(15):
                q+=DR[i]*dt*p; dq+=DR[i]*dt*dp; t+=DR[i]*dt
                f,fq=frc(q,t,eps,b0,model); p+=KI[i]*dt*f; dp+=KI[i]*dt*fq*dq
            q+=DR[15]*dt*p; dq+=DR[15]*dt*dp; t+=DR[15]*dt
            if k>=ntr:
                n=0.5*(q*q+p*p)
                if n>nhi: armed=True
                if armed and n<nlo:
                    NP[(k-ntr)//per]+=1; armed=False
        t=(k+1)*np.pi
        nr=np.sqrt(dq*dq+dp*dp); dq/=nr; dp/=nr
        if k>=ntr: S[(k-ntr)//per]+=np.log(nr)
    return S,NP
def job(a):
    model,eps,ph,nsub,amp=a
    a0=amp*np.exp(1j*ph); per=10000
    S,NP=run(np.sqrt(2)*a0.real,np.sqrt(2)*a0.imag,eps,4/3,model,50,10,per,nsub,DRIFT,KICK,0.06*eps,0.3*eps)
    return S.tolist(),NP.tolist()
if __name__=='__main__':
    nsub=int(sys.argv[1]); amp=float(sys.argv[2]); which=sys.argv[3] if len(sys.argv)>3 else 'all'
    cases={'all':[(0,0.20),(0,0.24),(0,0.28),(1,0.24),(1,0.28),(1,0.32),(2,0.24),(2,0.28)],'M20':[(0,0.20)],'M24':[(0,0.24)]}[which]
    phis=np.linspace(0,np.pi,8,endpoint=False)+np.pi/16
    jobs=[(m,e,ph,nsub,amp) for (m,e) in cases for ph in phis]
    with Pool(2) as P: res=P.map(job,jobs,chunksize=1)
    out={}
    for (m,e,ph,ns,am),(S,NP) in zip(jobs,res): out.setdefault('%s_%.2f'%('MDS'[m],e),[]).append((S,NP))
    Tseg=1e4*np.pi
    for k,v in out.items():
        S=np.array([x[0] for x in v]); NP=np.array([x[1] for x in v])
        lam_orb=S.sum(1)/(10*Tseg); T_orb=10*Tseg/NP.sum(1)
        lam_seg=(S/Tseg).ravel()
        print('%s  T %.1f (%.1f)  lam %.5f (orb %.5f, seg %.5f)  npass %d'%(k,T_orb.mean(),T_orb.std(ddof=1)/np.sqrt(8),
              lam_orb.mean(),lam_orb.std(ddof=1)/np.sqrt(8),lam_seg.std(ddof=1)/np.sqrt(lam_seg.size),NP.sum()),flush=True)
    json.dump(out,open(DATA+'table5_y8_%d_%g_%s.json'%(nsub,amp,which),'w'))
