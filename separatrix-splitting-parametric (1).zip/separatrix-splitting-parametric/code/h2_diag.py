import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
import sys; sys.path.insert(0,HERE)
import numpy as np
import ell_h2 as H
B=H.B; C=H.C
xs=B.xs; z0=2*xs/B.XMAX-1
J=C.chebval(z0,B.cJ)
full0,full4=H.ch0.copy(),H.ch4.copy()
lin0=B.fit(-J/16); zero4=B.fit(0*J)
def setv(c0,c4):
    H.ch0=c0; H.ch4=c4; H.ch0d=C.chebder(c0)*2/B.XMAX; H.ch4d=C.chebder(c4)*2/B.XMAX
for eps in [0.14,0.16,0.20,0.24,0.28]:
    out={}
    for name,(c0,c4) in {'lin':(lin0,zero4),'h0full':(full0,zero4),'h4only':(lin0,full4),'full':(full0,full4)}.items():
        setv(c0,c4); out[name]=H.melnikov(eps)[0]
    print('eps %.2f '%eps+'  '.join('%s %.4e'%(k,v) for k,v in out.items())+'  | full/lin %.3f h0full/lin %.3f h4only/lin %.3f'%(out['full']/out['lin'],out['h0full']/out['lin'],out['h4only']/out['lin']),flush=True)
