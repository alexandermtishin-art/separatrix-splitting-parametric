import os, os as _os; HERE=_os.path.dirname(_os.path.abspath(__file__))+'/'; ROOT=_os.path.abspath(HERE+'..')+'/'; DATA=ROOT+'data/'
"""Sec. 6.1/6.2: kappa fixed at eps=0.20 predicts the other pump depths; local exponent eta_eff (Table 4)."""
import json, numpy as np
def readmp(fn):
    out={}
    for l in open(DATA+fn):
        if l.startswith('RESULT'): x=l.split(); out[round(float(x[2]),4)]=float(x[3])
    return out
mM=readmp('mp_M.txt'); mM0=readmp('mp_M0.txt'); sp=json.load(open(DATA+'splitting.json'))
W={e:(mM[e],mM0[e]) for e in mM if e in mM0}
for k,v in sp.items():
    e=round(float(k),4)
    if 0.13<=e<=0.28 and e not in W: W[e]=(v['M'],v['M0'])
fd=json.load(open(DATA+'fig_data2.json')); eg=np.array(fd['eps']); Dg=np.array(fd['Delta']['0.0'])
e=np.array(sorted(W)); r=np.array([W[x][0]/W[x][1] for x in e]); D=np.interp(e,eg,Dg)
i=list(e).index(0.20); k=r[i]*np.exp(D[i])
print('kappa(0.20)=%.3f  max prediction error over other eps: %.1f%%'%(k,100*np.max(np.abs(np.delete(k*np.exp(-D)/r-1,i)))))
sel=[j for j,x in enumerate(e) if round(x,2) not in (0.13,0.18,0.22,0.26)]
for a,b in zip(sel[:-1],sel[1:]):
    j=a
    print('%.2f-%.2f  eta_eff %.3f  -dDelta/dln eps %.3f'%(e[a],e[b],np.log(r[b]/r[a])/np.log(e[b]/e[a]),-(D[b]-D[a])/np.log(e[b]/e[a])))
y=np.log(r); L=np.log(e); one=np.ones_like(e)
for name,cols,m in [('c+p ln e+a e',[one,L,e],e>0),('+b e^2',[one,L,e,e**2],e>0),('+b e ln e',[one,L,e,e*L],e>0),('eps<=0.14, c+p ln e+a e',[one,L,e],e<=0.14)]:
    X=np.c_[[c[m] for c in cols]].T; co=np.linalg.lstsq(X,y[m],rcond=None)[0]
    print('free fit %-25s p = %.3f  rms %.1e'%(name,co[1],np.sqrt(np.mean((y[m]-X@co)**2))))
